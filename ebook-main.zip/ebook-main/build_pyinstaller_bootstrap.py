#!/usr/bin/env python3
"""Build lightweight bootstrap installer with PyInstaller."""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.resolve()
SPEC_FILE = PROJECT_ROOT / "installer.spec"
LAUNCHER_SPEC_FILE = PROJECT_ROOT / "launcher.spec"
PYINSTALLER_OUTPUT_DIR = PROJECT_ROOT / "dist"
PYINSTALLER_BUILD_DIR = PROJECT_ROOT / "build"


def run_command(command: list[str], step_name: str) -> None:
    """Run a command and raise an error if it fails."""
    print(f"[*] {step_name}...")
    print(f"    Running: {' '.join(command)}")
    try:
        subprocess.run(command, check=True)
        print(f"[+] {step_name} completed successfully")
    except subprocess.CalledProcessError as exc:
        print(f"[-] {step_name} failed with exit code {exc.returncode}")
        raise RuntimeError(f"{step_name} failed with exit code {exc.returncode}") from exc


def clean_directories() -> None:
    """Clean build and dist directories."""
    for path in (PYINSTALLER_BUILD_DIR, PYINSTALLER_OUTPUT_DIR):
        if path.exists():
            print(f"[*] Cleaning {path}")
            shutil.rmtree(path)


def check_pyinstaller() -> None:
    """Check if PyInstaller is installed."""
    try:
        import PyInstaller
        print(f"[+] PyInstaller version: {PyInstaller.__version__}")
    except ImportError:
        print("[-] PyInstaller is not installed")
        print("[*] Installing PyInstaller...")
        subprocess.run([sys.executable, "-m", "pip", "install", "pyinstaller"], check=True)
        print("[+] PyInstaller installed successfully")


def build_launcher_exe() -> Path | None:
    """Build the desktop launcher executable (app.exe) from launcher.spec.

    The compiled exe is placed in the project root so that the bootstrap
    installer spec can include it as a deploy file.  Returns the path to the
    produced app.exe, or None when running on a non-Windows platform.
    """
    if sys.platform != "win32":
        print("[*] Skipping launcher exe build (Windows only)")
        return None

    if not LAUNCHER_SPEC_FILE.exists():
        raise FileNotFoundError(f"Launcher spec not found: {LAUNCHER_SPEC_FILE}")

    launcher_dist_dir = PYINSTALLER_BUILD_DIR / "launcher_dist"
    launcher_work_dir = PYINSTALLER_BUILD_DIR / "launcher_work"

    command = [
        sys.executable,
        "-m",
        "PyInstaller",
        str(LAUNCHER_SPEC_FILE),
        "--clean",
        "--noconfirm",
        f"--distpath={launcher_dist_dir}",
        f"--workpath={launcher_work_dir}",
    ]

    run_command(command, "Launcher exe build")

    compiled_exe = launcher_dist_dir / "app.exe"
    if not compiled_exe.exists():
        raise RuntimeError(f"Expected launcher output not found: {compiled_exe}")

    # Move to project root so installer.spec can find it as a deploy file.
    output_path = PROJECT_ROOT / "app.exe"
    if output_path.exists():
        print(f"[*] Overwriting existing launcher exe: {output_path}")
    shutil.copy2(compiled_exe, output_path)

    # Clean up intermediate build directories.
    shutil.rmtree(launcher_dist_dir, ignore_errors=True)
    shutil.rmtree(launcher_work_dir, ignore_errors=True)

    size_mb = output_path.stat().st_size / 1024 / 1024
    print(f"[+] Launcher exe built: {output_path} ({size_mb:.2f} MB)")
    return output_path


def build_with_pyinstaller() -> Path:
    """Build the installer executable with PyInstaller."""
    if not SPEC_FILE.exists():
        raise FileNotFoundError(f"Spec file not found: {SPEC_FILE}")

    command = [
        sys.executable,
        "-m",
        "PyInstaller",
        str(SPEC_FILE),
        "--clean",
        "--noconfirm",
    ]

    run_command(command, "PyInstaller build")

    # PyInstaller creates .exe on Windows, no extension on Linux/Mac
    exe_path = PYINSTALLER_OUTPUT_DIR / "WebToEbookInstaller.exe"
    if not exe_path.exists():
        exe_path = PYINSTALLER_OUTPUT_DIR / "WebToEbookInstaller"

    if not exe_path.exists():
        raise RuntimeError(f"Expected output not found: {exe_path}")

    return exe_path


def parse_args() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Build lightweight bootstrap installer with PyInstaller."
    )
    parser.add_argument(
        "--skip-clean",
        action="store_true",
        help="Skip cleaning build directories",
    )
    return parser.parse_args()


def main() -> int:
    """Main entry point."""
    print("=" * 60)
    print("Building Web to Ebook Converter Bootstrap Installer")
    print("=" * 60)

    args = parse_args()

    if not args.skip_clean:
        clean_directories()

    check_pyinstaller()
    # Build the desktop launcher exe and commit it alongside the installer so
    # it is available in the repository (and therefore in GitHub release source
    # zips) without requiring a rebuild on every release.
    launcher_exe = build_launcher_exe()
    exe_path = build_with_pyinstaller()

    file_size_mb = exe_path.stat().st_size / (1024 * 1024)
    print("\n" + "=" * 60)
    print("Build Complete!")
    print("=" * 60)
    print(f"Installer: {exe_path}")
    print(f"Size: {file_size_mb:.2f} MB")
    if launcher_exe:
        launcher_size_mb = launcher_exe.stat().st_size / (1024 * 1024)
        print(f"Launcher:  {launcher_exe} ({launcher_size_mb:.2f} MB)")
    print()
    print("The installer downloads application files and the Python runtime")
    print("from the internet at install time – no large payload is bundled.")
    print()
    print("Commit WebToEbookInstaller.exe (and app.exe if it changed) to the")
    print("repository so they are included in future GitHub release source zips.")
    print("=" * 60)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
