# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller spec for the Web to Ebook Converter portable Windows bundle.

Produces a one-folder distribution in dist/app/ containing:
  app.exe         – windowed launcher (no console flash)
  _internal/      – Python runtime, stdlib, and all bundled packages
  config.yaml     – default configuration
  kokoro_tts/     – bundled Kokoro TTS engine source

Users extract the zip and run app.exe directly.  No installation step needed.
"""

from PyInstaller.utils.hooks import collect_submodules, collect_data_files

# ── Data files ────────────────────────────────────────────────────────────────
# config.yaml lives at the project root; land it next to app.exe.
datas = [
    ("config.yaml", "."),
    # kokoro_tts is a local package – include its source tree as data so the
    # bundled Python can still import it from the _internal directory.
    ("kokoro_tts", "kokoro_tts"),
]

# ── Hidden imports ─────────────────────────────────────────────────────────────
# PyInstaller cannot always detect dynamic imports; list them explicitly.
hidden_imports = [
    "tkinter",
    "tkinter.ttk",
    "tkinter.messagebox",
    "tkinter.filedialog",
    "tkinter.scrolledtext",
    "tkinter.simpledialog",
    # Kokoro TTS runtime deps
    "soundfile",
    "numpy",
    "huggingface_hub",
    "loguru",
    "misaki",
    "transformers",
    # Scraper / web
    "playwright.sync_api",
    "playwright.async_api",
    # YAML
    "yaml",
    # Stdlib extras that are sometimes missed
    "email.mime.multipart",
    "email.mime.text",
    "urllib.request",
    "urllib.parse",
    "urllib.error",
    "http.cookiejar",
    "xml.etree.ElementTree",
    "zipfile",
    "shutil",
    "threading",
    "queue",
    "json",
    "re",
    "pathlib",
    "subprocess",
    "tempfile",
    "importlib.util",
]

a = Analysis(
    ["app.py"],
    pathex=[],
    binaries=[],
    datas=datas,
    hiddenimports=hidden_imports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # Nuitka is only needed for the old build method – omit from the bundle.
        "nuitka",
        # PyInstaller itself should not be bundled.
        "PyInstaller",
        # Heavy optional packages that are not required at runtime.
        "matplotlib",
        "pandas",
        "scipy",
        "cv2",
        "tensorflow",
        "keras",
        "PIL",
        "IPython",
        "jupyter",
        "notebook",
    ],
    noarchive=False,
    optimize=0,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,  # one-folder mode: binaries go into COLLECT
    name="app",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    console=False,          # no console window on Windows launch
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    coerce_macros_file=None,
    entitlements_file=None,
    icon=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="app",             # dist/app/ is the portable bundle root
)
