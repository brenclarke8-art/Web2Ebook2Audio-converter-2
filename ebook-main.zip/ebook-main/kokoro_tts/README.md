# Kokoro TTS - Bundled Source

This directory contains the Kokoro TTS source code, bundled directly into this project for stable, reproducible setup.

## About Kokoro

Kokoro is an open-weight, lightweight text-to-speech system with 82 million parameters that delivers high-quality, natural-sounding speech.

- **Official Repository**: https://github.com/hexgrad/kokoro
- **Version**: 0.9.4
- **License**: Apache 2.0 (see LICENSE_KOKORO)

## Why Bundled?

Kokoro is not available on PyPI and cannot be installed via `pip install kokoro`. By bundling the source code directly in our project:

1. **Stability**: No dependency on external package managers
2. **Reproducibility**: Same version across all installations
3. **Reliability**: No installer failures due to missing packages
4. **Simplicity**: Works out of the box with the project

## Dependencies

The following packages are required and installed via pip:
- torch
- soundfile
- numpy
- huggingface_hub
- loguru
- misaki[en]
- transformers

## Model Files

Model files are automatically downloaded from HuggingFace on first use and cached locally. The bundled source code handles all model loading and caching automatically.

## Usage

The bundled Kokoro is imported by `tts_engine.py`:

```python
from kokoro_tts.kokoro import KPipeline
```

No additional configuration is required - it works transparently as if Kokoro were installed as a regular package.

## Updates

To update the bundled Kokoro version:

1. Clone the latest version from https://github.com/hexgrad/kokoro
2. Copy the `kokoro/` directory to `kokoro_tts/kokoro/`
3. Update the LICENSE_KOKORO file
4. Test the installation with `python voice_preview.py`

## Credits

Kokoro TTS is developed by hexgrad (https://github.com/hexgrad/kokoro).
All credit for the TTS engine goes to the original authors.
