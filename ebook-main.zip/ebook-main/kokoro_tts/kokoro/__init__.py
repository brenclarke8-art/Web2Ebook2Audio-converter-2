__version__ = '0.9.4'

import os
import sys

# Force the compatible eager Transformers attention path before any Transformers imports occur.
# This is process-wide because Transformers reads these switches during import/init.
# Set both env vars because different Transformers releases honor different switches.
os.environ.setdefault("TRANSFORMERS_ATTENTION_IMPLEMENTATION", "eager")
os.environ.setdefault("USE_SLOW_ATTENTION", "1")

from loguru import logger


def _get_log_sink():
    for candidate in (sys.stderr, sys.__stderr__, sys.stdout, sys.__stdout__):
        if candidate is not None and hasattr(candidate, "write"):
            return candidate
    def _noop_sink(*args, **kwargs):
        pass
    return _noop_sink


def _configure_safe_cuda_attention_backends():
    """Disable fused CUDA SDP kernels during import when eager attention is requested."""
    requested_impl = os.environ.get("TRANSFORMERS_ATTENTION_IMPLEMENTATION", "eager").strip().lower()
    if requested_impl != "eager":
        return

    try:
        import torch
    except (ImportError, ModuleNotFoundError):
        return

    cuda_backends = getattr(torch.backends, "cuda", None)
    if cuda_backends is None:
        return

    try:
        if hasattr(cuda_backends, "enable_flash_sdp"):
            cuda_backends.enable_flash_sdp(False)
        if hasattr(cuda_backends, "enable_mem_efficient_sdp"):
            cuda_backends.enable_mem_efficient_sdp(False)
        if hasattr(cuda_backends, "enable_math_sdp"):
            cuda_backends.enable_math_sdp(True)
    except (AttributeError, RuntimeError):
        return


_configure_safe_cuda_attention_backends()

# Remove default handler
logger.remove()

# Add custom handler with clean format including module and line number
logger.add(
    _get_log_sink(),
    format="<green>{time:HH:mm:ss}</green> | <cyan>{module:>16}:{line}</cyan> | <level>{level: >8}</level> | <level>{message}</level>",
    colorize=True,
    level="INFO" # "DEBUG" to enable logger.debug("message") and up prints 
                 # "ERROR" to enable only logger.error("message") prints
                 # etc
)

# Disable before release or as needed
logger.disable("kokoro")

from .model import KModel
from .pipeline import KPipeline
