"""Shared manifest of files bundled and deployed by the bootstrap installer."""

from pathlib import Path

_HERE = Path(__file__).parent

PYINSTALLER_DEPLOY_FILES = [
    # Requirements and configuration
    "requirements.txt",
    "config.yaml",

    # Core application modules
    "app.py",
    "config.py",
    "main.py",
    "gui.py",
    "scraper.py",
    "ebook_generator.py",
    "tts_engine.py",
    "multispeaker_debug.py",
    "sync_text_generator.py",
    "translator.py",
    "updater.py",
    "installer_manifest.py",
    "voice_preview.py",
    "character_voice_manager.py",
    "dialogue_detector.py",
    "pronoun_analyzer.py",
    "character_database.py",
    "book_library.py",
    "installer.py",

    # Launcher and maintenance scripts
    "run_app.sh",
    "run_app.bat",
    "update_app.sh",
    "update_app.bat",
    "install_app.sh",
    "install_espeak_ng.ps1",
    "uninstall.sh",
    "uninstall.bat",
    "uninstaller.py",

    # Documentation
    "README.md",
    "USER_GUIDE.md",
    "TRANSLATION_GUIDE.md",
    "INSTANT_PREVIEW_GUIDE.md",
]

# Include the pre-built desktop launcher when it exists.  app.exe is committed
# to the repository and therefore present in GitHub release source zips; the
# frozen installer no longer bundles it but downloads it as part of the release
# source archive.  This entry keeps the PYINSTALLER_DEPLOY_FILES list accurate
# for updater validation and documentation purposes.
if (_HERE / "app.exe").exists():
    PYINSTALLER_DEPLOY_FILES.append("app.exe")

PYINSTALLER_DEPLOY_DIRECTORIES = [
    "kokoro_tts",
]

INSTALLATION_VALIDATION_FILES = [
    "gui.py",
    "main.py",
    "config.py",
    "config.yaml",
    "scraper.py",
    "ebook_generator.py",
    "tts_engine.py",
    "multispeaker_debug.py",
    "character_database.py",
    "installer.py",
]

INSTALLATION_VALIDATION_DIRECTORIES = [
    "kokoro_tts",
]

UPDATER_REQUIRED_FILES = [
    "installer.py",
    "main.py",
    "gui.py",
    "scraper.py",
    "character_database.py",
    "multispeaker_debug.py",
    "installer_manifest.py",
]
