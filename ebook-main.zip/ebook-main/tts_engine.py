import logging
from pathlib import Path
import torch
import soundfile as sf
import numpy as np
from typing import List, Optional, Dict
from concurrent.futures import ThreadPoolExecutor
import threading
from multispeaker_debug import build_normalized_voice_lookup, resolve_voice_mapping
from kokoro_voice_catalog import KOKORO_VOICE_CATALOG

logger = logging.getLogger(__name__)


class TTSEngine:
    """Handle text-to-speech conversion using Kokoro TTS

    Uses the Kokoro-82M model: https://github.com/hexgrad/kokoro
    Model is automatically downloaded on first use and cached locally.
    Kokoro is bundled directly in this project for stable, reproducible setup.

    Features:
    - GPU acceleration support (CUDA, MPS, or CPU)
    - Parallel voice loading for multi-speaker audiobooks
    - Automatic device selection
    """

    def __init__(self, output_dir: str = 'output', device: str = 'auto',
                 preload_voices: Optional[List[str]] = None,
                 default_lang_code: str = 'a'):
        """Initialize TTS Engine with GPU support and voice preloading.

        Args:
            output_dir: Directory for output audio files
            device: Device for TTS processing ('auto', 'cuda', 'cpu', or 'mps')
            preload_voices: List of voice names to preload at startup
            default_lang_code: Default language code for the pipeline
        """
        logger.debug(f"Initializing TTSEngine with Kokoro TTS: output_dir='{output_dir}', device='{device}'")
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)

        # Store configuration
        self.device_config = device
        self.default_lang_code = default_lang_code
        self.preload_voices = preload_voices or []

        # Determine actual device
        self.device = self._select_device(device)
        logger.info(f"TTSEngine using device: {self.device}")

        # Initialize Kokoro TTS from bundled module
        self.pipeline = None
        self.preloaded_voices = {}
        self._voice_load_lock = threading.Lock()

        try:
            from kokoro_tts.kokoro import KPipeline
            logger.debug("Kokoro TTS module imported successfully from bundled source")
            self.KPipeline = KPipeline
        except ImportError as e:
            logger.error(f"Failed to import bundled Kokoro TTS: {e}")
            logger.error("Ensure the kokoro_tts directory is present in the project")
            raise ImportError(f"Failed to import bundled Kokoro TTS: {e}")

        # Preload voices if specified
        if self.preload_voices:
            logger.info(f"Preloading {len(self.preload_voices)} voices for multi-speaker support...")
            self._preload_voices_parallel()
            logger.info(f"Voice preloading complete: {list(self.preloaded_voices.keys())}")

        logger.debug(f"TTSEngine initialized with Kokoro TTS")

    def _select_device(self, device: str) -> str:
        """Select the appropriate device for TTS processing.

        Args:
            device: Requested device ('auto', 'cuda', 'cpu', or 'mps')

        Returns:
            The actual device to use

        Raises:
            RuntimeError: If a specific device is requested but not available
        """
        if device == 'auto':
            if torch.cuda.is_available():
                logger.info("CUDA detected, enabling GPU acceleration")
                return 'cuda'
            elif torch.backends.mps.is_available():
                import os
                if os.environ.get('PYTORCH_ENABLE_MPS_FALLBACK') == '1':
                    logger.info("MPS (Apple Silicon) detected, enabling GPU acceleration")
                    return 'mps'
                else:
                    logger.warning("MPS available but fallback not enabled, using CPU")
                    return 'cpu'
            else:
                logger.info("No GPU detected, using CPU")
                return 'cpu'
        elif device == 'cuda':
            if not torch.cuda.is_available():
                raise RuntimeError("CUDA requested but not available. Install CUDA-enabled PyTorch or use device='auto'")
            return 'cuda'
        elif device == 'mps':
            if not torch.backends.mps.is_available():
                raise RuntimeError("MPS requested but not available. Use device='auto' or 'cpu'")
            return 'mps'
        elif device == 'cpu':
            return 'cpu'
        else:
            logger.warning(f"Unknown device '{device}', falling back to 'auto'")
            return self._select_device('auto')

    def _preload_voices_parallel(self):
        """Preload multiple voices in parallel using threading.

        This speeds up initialization for multi-speaker audiobooks by loading
        all required voices concurrently.
        """
        if not self.preload_voices:
            return

        # Initialize pipeline first if needed
        if self.pipeline is None:
            logger.info(f"Loading Kokoro TTS model for language '{self.default_lang_code}'...")
            self.pipeline = self.KPipeline(lang_code=self.default_lang_code, device=self.device)
            logger.debug("Kokoro TTS model loaded successfully")

        def load_voice(voice_name):
            try:
                logger.debug(f"Preloading voice: {voice_name}")
                voice_data = self.pipeline.load_voice(voice_name)
                with self._voice_load_lock:
                    self.preloaded_voices[voice_name] = voice_data
                logger.debug(f"Voice preloaded: {voice_name}")
            except Exception as e:
                logger.error(f"Failed to preload voice '{voice_name}': {e}")

        # Load voices in parallel using ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=min(4, len(self.preload_voices))) as executor:
            executor.map(load_voice, self.preload_voices)

    def generate_audio(self, text: str, output_filename: str, **kwargs) -> Path:
        """Generate audio from text using Kokoro TTS

        Args:
            text: Text to convert to speech
            output_filename: Output filename for the audio
            **kwargs: Additional parameters
                - voice: Voice name (default: 'af_heart')
                - lang_code: Language code (default: 'a' for American English)
                - speed: Speaking speed multiplier (default: 1.0)
                - progress_callback: Optional callback function for progress updates

        Returns:
            Path to the generated audio file
        """
        logger.debug(f"generate_audio called: filename='{output_filename}', text_length={len(text)}")
        logger.debug(f"kwargs: {kwargs}")

        voice = kwargs.get('voice', 'af_heart')
        lang_code = kwargs.get('lang_code', 'a')
        speed = kwargs.get('speed', 1.0)
        progress_callback = kwargs.get('progress_callback', None)

        logger.debug(f"Using Kokoro TTS: voice={voice}, lang_code={lang_code}, speed={speed}")
        return self._generate_kokoro(text, output_filename, voice=voice, lang_code=lang_code, speed=speed, progress_callback=progress_callback)

    def generate_preview(self, voice: str = 'af_heart', lang_code: str = 'a', speed: float = 1.0) -> Path:
        """Generate a quick preview audio sample with specified settings

        Args:
            voice: Voice name from available Kokoro voices
            lang_code: Language code
            speed: Speaking speed multiplier

        Returns:
            Path to the generated preview audio file
        """
        preview_text = "This is a preview of the selected voice at the current speed setting. Listen carefully to determine if this suits your needs."
        preview_filename = f"preview_{voice}_{speed}.wav"

        logger.info(f"Generating preview with voice={voice}, speed={speed}")
        return self._generate_kokoro(preview_text, preview_filename, voice=voice, lang_code=lang_code, speed=speed)

    def generate_multi_voice_audio(self, dialogue_segments: List, output_filename: str,
                                     voice_mappings: Dict[str, str], dialogue_pause: float = 0.3,
                                     **kwargs) -> Path:
        """Generate audio with multiple voices for different characters

        Args:
            dialogue_segments: List of DialogueSegment objects with text and speaker info
            output_filename: Output filename for the combined audio
            voice_mappings: Dictionary mapping character names to voice names
            dialogue_pause: Pause duration between speakers in seconds
            **kwargs: Additional parameters (lang_code, speed, progress_callback)

        Returns:
            Path to the generated audio file
        """
        logger.info(f"Starting multi-voice audio generation with {len(dialogue_segments)} segments")
        logger.debug(f"Voice mappings: {voice_mappings}")

        lang_code = kwargs.get('lang_code', 'a')
        speed = kwargs.get('speed', 1.0)
        progress_callback = kwargs.get('progress_callback', None)

        all_audio_segments = []
        silence_samples = int(24000 * dialogue_pause)  # Kokoro uses 24kHz sample rate
        silence = np.zeros(silence_samples, dtype=np.float32)

        # Initialize pipeline if needed
        if self.pipeline is None:
            logger.info(f"Loading Kokoro TTS model for language '{lang_code}'...")
            if progress_callback:
                progress_callback("Loading TTS model...")
            self.pipeline = self.KPipeline(lang_code=lang_code, device=self.device)
            logger.debug("Kokoro TTS model loaded successfully")

        previous_speaker = None
        warned_non_exact = set()
        normalized_lookup = build_normalized_voice_lookup(voice_mappings)

        for i, segment in enumerate(dialogue_segments):
            if i % 10 == 0:
                logger.debug(f"Processing segment {i+1}/{len(dialogue_segments)}")
                if progress_callback:
                    progress_callback(f"Processing segment {i+1}/{len(dialogue_segments)}...")

            # Skip empty segments
            if not segment.text or not segment.text.strip():
                continue

            # Get voice for this segment's speaker
            speaker = segment.speaker or 'narrator'
            resolution = resolve_voice_mapping(
                speaker,
                voice_mappings,
                narrator_voice=voice_mappings.get('narrator', 'af_heart'),
                normalized_lookup=normalized_lookup,
            )
            voice = resolution.voice

            logger.debug(
                "Segment %d: requested_speaker='%s', matched_speaker='%s', voice='%s', "
                "resolution=%s, is_dialogue=%s",
                i + 1,
                resolution.requested_speaker,
                resolution.matched_speaker,
                voice,
                resolution.resolution,
                segment.is_dialogue,
            )
            if resolution.resolution != 'exact' and resolution.requested_speaker not in warned_non_exact:
                logger.warning(
                    "Non-exact voice resolution for speaker '%s': matched '%s' -> '%s' (%s)",
                    resolution.requested_speaker,
                    resolution.matched_speaker,
                    voice,
                    resolution.resolution,
                )
                warned_non_exact.add(resolution.requested_speaker)

            # Add pause between different speakers (but not at the start)
            if previous_speaker is not None and previous_speaker != speaker and len(all_audio_segments) > 0:
                logger.debug(f"Adding {dialogue_pause}s pause between {previous_speaker} and {speaker}")
                all_audio_segments.append(silence)

            # Generate audio for this segment
            try:
                generator = self.pipeline(segment.text, voice=voice, speed=speed, split_pattern=r'\n+')

                # Collect audio for this segment
                segment_audio = []
                for gs, ps, audio in generator:
                    segment_audio.append(audio)

                if segment_audio:
                    combined_segment = np.concatenate(segment_audio)
                    all_audio_segments.append(combined_segment)
                    logger.debug(f"Segment {i+1} generated: {len(combined_segment)} samples")
                else:
                    logger.warning(f"Segment {i+1} generated no audio")

            except Exception as e:
                logger.error(f"Error generating audio for segment {i+1}: {e}")
                # Continue with next segment rather than failing completely
                continue

            previous_speaker = speaker

        # Validate we have audio
        if not all_audio_segments:
            error_msg = "No audio segments were generated"
            logger.error(error_msg)
            raise ValueError(error_msg)

        # Concatenate all segments
        logger.info("Concatenating all audio segments...")
        if progress_callback:
            progress_callback("Combining audio segments...")

        combined_audio = np.concatenate(all_audio_segments)

        # Save audio file
        output_path = self.output_dir / output_filename
        logger.info(f"Saving multi-voice audio to {output_path}")
        if progress_callback:
            progress_callback("Saving audio file...")

        sf.write(str(output_path), combined_audio, 24000)

        logger.info(f"✓ Generated multi-voice audio: {output_path}")
        if progress_callback:
            progress_callback("Audio generation complete")

        return output_path


    def _generate_kokoro(self, text: str, output_filename: str,
                      voice: str = 'af_heart',
                      lang_code: str = 'a',
                      speed: float = 1.0,
                      progress_callback=None) -> Path:
        """Generate audio using Kokoro TTS

        Args:
            text: Text to convert to speech
            output_filename: Output filename
            voice: Voice name from available Kokoro voices
            lang_code: Language code ('a'=American English, 'b'=British English, 'e'=Spanish,
                       'f'=French, 'h'=Hindi, 'i'=Italian, 'j'=Japanese, 'p'=Brazilian Portuguese, 'z'=Mandarin)
            speed: Speaking speed multiplier
            progress_callback: Optional callback function for progress updates

        Returns:
            Path to the generated audio file
        """
        try:
            logger.debug(f"Starting Kokoro TTS audio generation: voice='{voice}', lang_code='{lang_code}', speed={speed}")
            output_path = self.output_dir / output_filename
            logger.debug(f"Output path: {output_path}")

            # Validate input text
            if not text or not text.strip():
                error_msg = "Cannot generate audio: text is empty"
                logger.error(error_msg)
                raise ValueError(error_msg)

            # Initialize Kokoro pipeline if not already loaded
            if self.pipeline is None:
                logger.info(f"Loading Kokoro TTS model for language '{lang_code}' on device '{self.device}' (this may take a minute on first run)...")
                if progress_callback:
                    progress_callback("Loading TTS model...")
                self.pipeline = self.KPipeline(lang_code=lang_code, device=self.device)
                logger.debug(f"Kokoro TTS model loaded successfully on {self.device}")

            logger.info(f"Generating audio with Kokoro TTS: voice={voice}, lang_code={lang_code}")
            if progress_callback:
                progress_callback("Generating audio...")

            # Generate audio
            logger.debug("Generating audio for text segment")
            generator = self.pipeline(text, voice=voice, speed=speed, split_pattern=r'\n+')

            # Collect all audio segments
            audio_segments = []
            for i, (gs, ps, audio) in enumerate(generator):
                logger.debug(f"Generated audio segment {i}")
                if progress_callback:
                    progress_callback(f"Processing segment {i+1}...")
                audio_segments.append(audio)

            # Validate that we have audio segments
            if not audio_segments:
                error_msg = "No audio segments were generated. The text may be empty or invalid."
                logger.error(error_msg)
                raise ValueError(error_msg)

            # Concatenate all segments
            import numpy as np
            combined_audio = np.concatenate(audio_segments)

            # Save audio file
            if progress_callback:
                progress_callback("Saving audio file...")
            sf.write(str(output_path), combined_audio, 24000)

            logger.debug("Audio saved successfully")
            logger.info(f"✓ Generated audio: {output_path}")
            if progress_callback:
                progress_callback("Audio generation complete")
            return output_path

        except ImportError as e:
            logger.error("✗ Failed to import bundled Kokoro TTS")
            logger.error("   Ensure the kokoro_tts directory is present in the project")
            logger.error("   Also ensure you have espeak-ng installed")
            raise
        except Exception as e:
            logger.error(f"✗ Kokoro TTS error: {e}")
            logger.debug(f"Exception type: {type(e).__name__}")
            raise



    @staticmethod
    def list_kokoro_voices():
        """List available Kokoro TTS voices"""
        print("\nKokoro TTS - Available Voices:")

        for voice_name, meta in KOKORO_VOICE_CATALOG.items():
            description = f"{meta['gender'].title()} voice - {meta['description']}"
            print(f"  {voice_name:25} - {description}")

        print("\nYou can also pass a local .pt filename or an absolute path to a .pt voice file.")

        print("\nSupported Languages:")
        print("  a    - American English")
        print("  b    - British English")
        print("  e    - Spanish")
        print("  f    - French")
        print("  h    - Hindi")
        print("  i    - Italian")
        print("  j    - Japanese")
        print("  p    - Brazilian Portuguese")
        print("  z    - Mandarin Chinese")

        print("\nSpeed Control:")
        print("  0.5 - 2.0  - Speaking speed multiplier (1.0 = normal)")

        print("\nFor more info: https://github.com/hexgrad/kokoro")
