@echo off
setlocal
python updater.py
set EXITCODE=%errorlevel%
exit /b %EXITCODE%
