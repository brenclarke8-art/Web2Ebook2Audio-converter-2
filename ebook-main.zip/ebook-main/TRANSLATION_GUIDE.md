# Translation Setup Guide

This guide explains how to set up and use the translation feature in the Web to Ebook Converter.

## Overview

The translation feature allows you to:
- Automatically translate non-English web content to English (or any target language)
- Use AI-powered translation for natural, context-aware translations
- Apply custom rules to ensure consistent translation of character names, pronouns, and terminology
- Support multiple language pairs

## Requirements

To use translation, you need:
1. A translation API endpoint (local or remote)
2. Python with the `requests` library installed

## Translation API Options

### Option 1: LibreTranslate (Recommended for Local)

LibreTranslate is a free, open-source translation API that can run locally.

**Installation:**
```bash
pip install libretranslate
libretranslate
```

This starts a local server at `http://localhost:5000`

**Docker Installation:**
```bash
docker run -ti --rm -p 5000:5000 libretranslate/libretranslate
```

**Configuration:**
- API URL: `http://localhost:5000/translate`
- API Key: Not required for local instance

### Option 2: Argos Translate

Another open-source option that can run locally.

```bash
pip install argostranslate
```

You'll need to set up a simple API wrapper or use it through Python directly.

### Option 3: DeepL API

High-quality commercial translation service with a free tier.

**Setup:**
1. Sign up at https://www.deepl.com/pro-api
2. Get your API key
3. Use API URL: `https://api-free.deepl.com/v2/translate`

### Option 4: Google Translate API

Commercial service from Google.

**Setup:**
1. Set up Google Cloud project
2. Enable Translation API
3. Get API credentials
4. Configure accordingly

## Configuration

### Using the GUI

1. Launch the GUI: `python gui.py`
2. Go to the **Translation** tab
3. Enable translation with the checkbox
4. Configure settings:
   - **Source Language**: Select the language of your content (or "auto" for auto-detection)
   - **Target Language**: Usually "en" for English
   - **API URL**: Your translation API endpoint
   - **API Key**: If required by your service
5. Add custom rules (optional - see below)

### Using config.yaml

Edit `config.yaml`:

```yaml
# Translation Settings
enable_translation: true
source_language: "auto"  # or "ja", "zh", "ko", etc.
target_language: "en"
translation_api_url: "http://localhost:5000/translate"
translation_api_key: null  # or your API key

# Custom Translation Rules (optional)
translation_rules:
  - pattern: "Naruto"
    replacement: "Naruto"
    is_regex: false
    case_sensitive: true
  - pattern: '\bhe\b'
    replacement: "she"
    is_regex: true
    case_sensitive: false
```

## Language Codes

Common language codes:
- `en` - English
- `ja` - Japanese
- `zh` - Chinese
- `ko` - Korean
- `ru` - Russian
- `es` - Spanish
- `fr` - French
- `de` - German
- `it` - Italian
- `pt` - Portuguese
- `ar` - Arabic
- `hi` - Hindi

## Custom Translation Rules

Custom rules allow you to override the AI translator's output for specific patterns. This is useful for:

### Context-Aware Pronoun Analysis (NEW!)

The system now includes **intelligent pronoun analysis** that automatically:
- Detects character names in your content
- Tracks which pronouns are used with each character
- Analyzes context to link pronouns to characters
- Infers character gender based on pronoun patterns
- Generates automatic corrections when gender is specified

**Using Character-Pronoun Mapping (Recommended Method):**

Instead of manually creating pronoun rules, simply specify character genders:

```yaml
# In config.yaml or GUI Character-Pronoun Mapping section
character_genders:
  Alice: female
  Bob: male
  Sam: neutral
```

The system will:
1. Analyze the translated text
2. Detect when these characters are mentioned
3. Track pronoun usage patterns
4. Automatically correct any misgendered pronouns

**How it works:**
- Looks at sentence context (previous 3 sentences)
- Links pronouns to the most recently mentioned character
- Generates correction rules automatically
- Applies corrections consistently throughout the text

**Example:**

Original (mistranslated): "Alice entered the room. He was tired."
After analysis: "Alice entered the room. She was tired."

### Manual Translation Rules (Advanced)

For more control, you can still create manual rules:

### Use Case 1: Character Names

Keep character names consistent and unchanged:

```yaml
- pattern: "Protagonist"
  replacement: "Protagonist"
  is_regex: false
  case_sensitive: true
```

### Use Case 2: Manual Pronoun Correction

Fix incorrect pronoun translations manually:

```yaml
# Change all instances of "he" to "she"
- pattern: '\bhe\b'
  replacement: "she"
  is_regex: true
  case_sensitive: false

# Change "his" to "her"
- pattern: '\bhis\b'
  replacement: "her"
  is_regex: true
  case_sensitive: false
```

### Use Case 3: Terminology Consistency

Ensure specific terms are translated consistently:

```yaml
- pattern: "cultivation"
  replacement: "cultivation"
  is_regex: false
  case_sensitive: false

- pattern: "dao"
  replacement: "Dao"
  is_regex: false
  case_sensitive: false
```

### Use Case 4: Honorifics

Preserve cultural honorifics:

```yaml
- pattern: "-san"
  replacement: "-san"
  is_regex: false
  case_sensitive: true

- pattern: "-sama"
  replacement: "-sama"
  is_regex: false
  case_sensitive: true
```

## Rule Syntax

Each rule has four properties:

1. **pattern**: Text to find
   - Plain text: `"character name"`
   - Regex: `"\bhe\b"` (matches "he" as a whole word)

2. **replacement**: Text to replace with

3. **is_regex**: `true` or `false`
   - `true`: Use regex pattern matching (more powerful)
   - `false`: Simple string replacement

4. **case_sensitive**: `true` or `false`
   - `true`: "Character" won't match "character"
   - `false`: Case-insensitive matching

### Regex Tips

- `\b`: Word boundary (matches start/end of words)
- `.*`: Match any characters
- `[aeiou]`: Match any vowel
- `(option1|option2)`: Match either option

Example regex patterns:
```yaml
# Match "he", "He", "HE" as whole words only
- pattern: '\b[Hh][Ee]\b'
  replacement: "she"
  is_regex: true
  case_sensitive: false
```

## Workflow Example

### Translating Japanese Web Novels with Smart Pronoun Handling

1. **Enable Translation**:
   ```yaml
   enable_translation: true
   source_language: "ja"
   target_language: "en"
   ```

2. **Define Character Genders** (NEW - Automatic Pronoun Correction):
   ```yaml
   character_genders:
     Naruto: male
     Sakura: female
     Hinata: female
     Sasuke: male
   ```

3. **The system automatically**:
   - Translates the content using AI
   - Analyzes character mentions and pronoun usage
   - Detects when pronouns don't match specified genders
   - Generates and applies correction rules
   - Ensures consistency throughout all chapters

4. **Add Manual Rules** (optional for other corrections):
   ```yaml
   translation_rules:
     # Keep specific terms untranslated
     - pattern: "chakra"
       replacement: "chakra"
       is_regex: false
       case_sensitive: false
   ```

5. **Run Conversion**:
   - Through GUI: Enable translation, add character genders, click "Start Conversion"
   - Through CLI: Configure `config.yaml` and run

### Understanding Pronoun Analysis

**Before Translation:**
```
太郎が部屋に入った。彼は疲れていた。花子が彼に話しかけた。
```

**After AI Translation (may have errors):**
```
Tarou entered the room. He was tired. Hanako spoke to him.
```

**With Character Gender Mapping:**
```yaml
character_genders:
  Tarou: male   # Correct
  Hanako: female # Correct
```

**System Analysis:**
- Detects "Tarou" mentioned, followed by "he/him" → Links correctly
- Detects "Hanako" mentioned, tracks pronoun usage
- Generates report of character-pronoun relationships

**Result:**
Pronouns are automatically corrected if the AI translator made mistakes!

### Translating Japanese Web Novels (Legacy Example)

1. **Enable Translation**:
   ```yaml
   enable_translation: true
   source_language: "ja"
   target_language: "en"
   ```

2. **Add Character Name Rules**:
   ```yaml
   translation_rules:
     - pattern: "太郎"
       replacement: "Tarou"
       is_regex: false
       case_sensitive: true
     - pattern: "花子"
       replacement: "Hanako"
       is_regex: false
       case_sensitive: true
   ```

3. **Add Pronoun Rules** (if the AI makes mistakes):
   ```yaml
     - pattern: '\bhe\b'
       replacement: "she"
       is_regex: true
       case_sensitive: false
   ```

4. **Run Conversion**:
   - Through GUI: Click "Start Conversion"
   - Through CLI: `python main.py`

## Testing Translation

To test your translation setup:

1. Use a single URL first:
   ```yaml
   max_chapters: 1
   ```

2. Check the output EPUB to verify:
   - Translation quality
   - Character names are consistent
   - Pronouns are correct

3. Adjust rules as needed

4. Process the full content

## Troubleshooting

### Translation API Not Responding

**Error**: Connection refused or timeout

**Solutions**:
- Check if the API server is running
- Verify the API URL is correct
- Check firewall settings
- For local services, ensure they're bound to the correct port

### Language Detection Fails

**Error**: Language detected as "unknown"

**Solutions**:
- Manually specify the source language instead of "auto"
- Ensure the content has enough text for detection (needs 50+ characters)

### Poor Translation Quality

**Solutions**:
- Try a different translation service
- Use custom rules to fix common errors
- Consider using a commercial API like DeepL for better quality

### Custom Rules Not Applied

**Solutions**:
- Check YAML syntax (proper indentation, quotes)
- Verify regex patterns are correct
- Ensure rules are in the correct format
- Check that translation is enabled

### Slow Translation

Translation can be slow for large content:
- Use chapter limits for testing: `max_chapters: 3`
- Consider using a faster API service
- For very long content, process in batches

## Performance Tips

1. **Batch Processing**: Process chapters in smaller batches
2. **Local API**: Use LibreTranslate locally for faster processing
3. **Caching**: Some APIs support caching for repeated translations
4. **Chapter Limits**: Test with `max_chapters` first

## Privacy Considerations

- **Local APIs** (LibreTranslate, Argos): Your content stays on your machine
- **Cloud APIs** (DeepL, Google): Your content is sent to their servers
- For sensitive content, use local translation services

## Advanced: Creating Custom API Wrapper

If you have a translation library but no API, create a simple Flask wrapper:

```python
from flask import Flask, request, jsonify
import your_translation_library

app = Flask(__name__)

@app.route('/translate', methods=['POST'])
def translate():
    data = request.json
    text = data['text']
    source = data['source']
    target = data['target']

    translated = your_translation_library.translate(
        text, source_lang=source, target_lang=target
    )

    return jsonify({'translated_text': translated})

if __name__ == '__main__':
    app.run(port=5000)
```

Save as `translation_server.py` and run:
```bash
python translation_server.py
```

## Support

For translation-specific issues:
- Check the translation API's documentation
- Verify network connectivity
- Review custom rule syntax
- Test with simple content first

For application issues:
- Check application logs in the GUI
- Verify config.yaml syntax
- Report issues on GitHub

## Summary

The translation feature provides powerful, customizable translation with:
- **Auto-detection**: Automatically detect source language
- **AI Translation**: Natural, context-aware translations
- **Custom Rules**: Override AI for consistent character names and terminology
- **Flexible API Support**: Works with local or cloud services

Start with LibreTranslate for a free, local solution, then explore other options based on your quality and speed requirements.
