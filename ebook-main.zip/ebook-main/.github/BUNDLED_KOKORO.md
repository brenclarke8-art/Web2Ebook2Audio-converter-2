# Bundled Kokoro TTS Implementation

## Overview

This project now bundles Kokoro TTS source code directly instead of relying on pip installation. This change provides:

1. **Stability** - No dependency on PyPI availability
2. **Reproducibility** - Same version across all installations
3. **Reliability** - Eliminates pip install failures
4. **Simplicity** - Works out-of-the-box with the project

## What Changed

### Before
- `pip install kokoro` in installer
- Import: `from kokoro import KPipeline`
- Relied on Kokoro being available on PyPI (it's not)
- Frequent installation failures

### After
- Kokoro source bundled in `kokoro_tts/` directory
- Import: `from kokoro_tts.kokoro import KPipeline`
- Dependencies installed: `huggingface_hub`, `loguru`, `misaki[en]`, `transformers`
- Clean, stable installation process

## Directory Structure

```
ebook/
├── kokoro_tts/
│   ├── LICENSE_KOKORO          # Apache 2.0 license from Kokoro
│   ├── README.md               # Documentation about the bundling
│   └── kokoro/                 # Kokoro source code (v0.9.4)
│       ├── __init__.py
│       ├── __main__.py
│       ├── custom_stft.py
│       ├── istftnet.py
│       ├── model.py
│       ├── modules.py
│       └── pipeline.py
├── tts_engine.py               # Updated to import from kokoro_tts.kokoro
├── installer.py                # Updated package list
└── README.md                   # Updated documentation
```

## Files Modified

1. **installer.py**
   - Removed `"kokoro"` from `KOKORO_PACKAGES`
   - Added: `huggingface_hub`, `loguru`, `misaki[en]`, `transformers`
   - Updated installation messages

2. **tts_engine.py**
   - Changed import from `from kokoro import KPipeline` to `from kokoro_tts.kokoro import KPipeline`
   - Updated error messages

3. **voice_preview.py**
   - Updated error messages to reflect bundled setup

4. **README.md**
   - Updated installation instructions
   - Added note about bundled Kokoro
   - Updated requirements list

5. **USER_GUIDE.md**
   - Updated manual installation instructions
   - Added note about bundled setup

6. **kokoro_tts/** (new directory)
   - Added Kokoro v0.9.4 source code
   - Added LICENSE_KOKORO (Apache 2.0)
   - Added README.md explaining the bundling

## Installation Process

### User Perspective

Nothing changes for the user! They still run:
```bash
python installer.py
```

The installer now:
1. Installs core dependencies
2. Installs Kokoro's dependencies (but not Kokoro itself, since it's bundled)
3. On first run, models download automatically from HuggingFace

### Developer Perspective

When updating the bundled Kokoro version:
1. Clone latest Kokoro: `git clone https://github.com/hexgrad/kokoro`
2. Copy source: `cp -r kokoro/kokoro kokoro_tts/kokoro`
3. Update LICENSE: `cp kokoro/LICENSE kokoro_tts/LICENSE_KOKORO`
4. Fix imports if needed (use relative imports within Kokoro)
5. Test with: `python voice_preview.py`

## Benefits

1. **No pip failures** - Kokoro is not on PyPI, eliminating the #1 cause of installation failures
2. **Version control** - Exact Kokoro version is tracked in git
3. **Offline support** - After first model download, works without internet
4. **Consistent behavior** - Same code runs everywhere
5. **Easy troubleshooting** - Source code is visible and editable

## Testing

To verify the bundled setup works:

```bash
# After installing dependencies
python3 -c "from kokoro_tts.kokoro import KPipeline; print('Success!')"

# Full test with voice preview
python voice_preview.py
```

## Credits

- Kokoro TTS: https://github.com/hexgrad/kokoro
- License: Apache 2.0
- Developer: hexgrad (hello@hexgrad.com)

All credit for the TTS engine goes to the original Kokoro authors. This project simply bundles their open-source code for easier distribution.
