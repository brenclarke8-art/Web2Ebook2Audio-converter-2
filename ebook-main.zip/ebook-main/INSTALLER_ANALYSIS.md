# Installer Architecture Analysis & Issues

**Date**: 2026-05-19
**Status**: CRITICAL - Installer is fundamentally broken

## Executive Summary

The bootstrap installer (PyInstaller method) is **fundamentally broken** and cannot work as currently designed. The installer successfully installs Python dependencies but fails to provide any way for the application source files to be deployed, resulting in a successful installation that produces a non-functional application.

## Critical Issues

### 1. ❌ CRITICAL: Bootstrap Installer Missing Application Source Files

**Severity**: CRITICAL
**Impact**: Application cannot launch after installation

The PyInstaller bootstrap installer (`installer.spec`) only bundles `requirements.txt`:

```python
# installer.spec line 11
datas=[('requirements.txt', '.')]
```

It does NOT include:
- `gui.py` (required for GUI launch)
- `main.py`, `config.py`, `scraper.py` (core application files)
- `kokoro_tts/` directory (bundled TTS engine)
- `assets/`, `models/` directories
- Configuration files

The installer then attempts to launch the GUI:
```python
# installer.py line 652
gui_path = project_dir / "gui.py"  # This file doesn't exist!
launch_cmd = [str(python_executable), str(gui_path)]
```

**Result**: Installation completes successfully, but attempting to launch the application fails with "file not found".

### 2. ❌ CRITICAL: Installation Directory Mismatch

**Severity**: CRITICAL
**Impact**: GUI launch fails

When running as a frozen executable, `get_install_directory()` asks the user where to install and returns a user-selected directory (e.g., `C:\Program Files\Web to Ebook Converter`). However:

1. The installer installs Python packages to this directory
2. The installer then tries to launch `gui.py` from this directory
3. **Problem**: `gui.py` was never copied to this directory!

```python
# installer.py lines 86-121
if getattr(sys, 'frozen', False):
    # Prompts user for installation directory
    install_dir = Path(os.environ.get("PROGRAMFILES")) / "Web to Ebook Converter"
    # ... user can customize ...
    return install_dir  # Returns user's choice
else:
    # When running as script, uses project directory (has all files)
    return Path(__file__).parent.resolve()
```

This creates two completely different behaviors:
- **From source** (`python installer.py`): Works because files are in project directory
- **From bootstrap** (`WebToEbookInstaller.exe`): Fails because no files in install directory

### 3. ❌ HIGH: No Application Deployment Mechanism

**Severity**: HIGH
**Impact**: Application files never deployed

The `installer.py` script has **NO code** to:
- Clone application source from GitHub
- Download a source archive
- Copy bundled application files to installation directory
- Extract application files from the installer

The installer only installs:
1. Python packages via pip
2. Playwright browsers
3. espeak-ng (Windows only)

It **never** installs the actual application code.

### 4. ❌ HIGH: Python Not Bundled

**Severity**: HIGH
**Impact**: Application won't launch if Python not in PATH

The bootstrap installer assumes Python is already installed and available in PATH. It uses `sys.executable` to install packages but doesn't:
- Bundle Python with the installer
- Download Python during installation
- Verify Python will be available after installation completes

The launcher scripts (`run_app.bat`, `run_app.sh`) look for Python in:
1. `python/` subdirectory (which won't exist)
2. System PATH (may not be available)

### 5. ❌ MEDIUM: No File Validation

**Severity**: MEDIUM
**Impact**: Silent failures, poor error messages

Before launching the GUI, the installer doesn't verify required files exist:

```python
# installer.py line 652 - Should check if file exists first
gui_path = project_dir / "gui.py"
launch_cmd = [str(python_executable), str(gui_path)]
# Missing: if not gui_path.exists(): raise FileNotFoundError
```

## Working Components

✅ **Python package installation** - Works correctly via pip
✅ **Playwright browser installation** - Works correctly
✅ **espeak-ng installation** - Works on Windows
✅ **Logging and error handling** - Comprehensive logging exists
✅ **Build scripts** - PyInstaller and Nuitka build scripts work
✅ **GitHub Actions workflow** - CI/CD pipeline is configured correctly

## Architectural Flaws

### Current (Broken) Flow

```
User runs WebToEbookInstaller.exe
    ↓
Asks where to install
    ↓
Installs Python packages to install directory
    ↓
Tries to launch gui.py from install directory
    ↓
❌ FAILS: gui.py doesn't exist
```

### Expected Flow (Not Implemented)

```
User runs WebToEbookInstaller.exe
    ↓
Asks where to install
    ↓
[MISSING] Extracts/downloads application files
    ↓
Installs Python packages
    ↓
[MISSING] Copies application files to install directory
    ↓
Validates all required files exist
    ↓
Launches gui.py
    ↓
✅ SUCCESS: Application runs
```

## Root Cause Analysis

The installer was designed for **source installation** (`python installer.py` from a git clone) but was incorrectly adapted for **binary distribution** (frozen executable). The key assumptions that break:

1. **Assumption**: Application files are in the current directory
   **Reality**: Frozen executable has no application files

2. **Assumption**: `project_dir` contains source files
   **Reality**: `project_dir` is an empty installation directory

3. **Assumption**: User has Python in PATH
   **Reality**: Not guaranteed, especially on Windows

## Comparison: Nuitka vs PyInstaller Methods

| Aspect | Nuitka Method | PyInstaller Bootstrap Method |
|--------|---------------|------------------------------|
| Build time | 6+ hours | 3-5 minutes |
| Installer size | 500+ MB | ~8 MB |
| Application files | ✅ Bundled in executable | ❌ Not bundled |
| Python runtime | ✅ Bundled | ❌ Not bundled |
| Dependencies | ✅ Bundled | ❌ Downloaded at install time |
| Works? | ✅ YES | ❌ NO |

**The Nuitka method works** because it bundles everything. The PyInstaller bootstrap method is broken because it bundles nothing.

## Recommendations for Rebuild

### Option 1: Fix Bootstrap Installer (Recommended)

1. **Bundle application source files** in `installer.spec`:
   ```python
   datas=[
       ('requirements.txt', '.'),
       ('gui.py', '.'),
       ('main.py', '.'),
       ('config.py', '.'),
       ('scraper.py', '.'),
       ('kokoro_tts', 'kokoro_tts'),
       ('config.yaml', '.'),
       # ... all required files
   ]
   ```

2. **Extract bundled files** during installation:
   - Create a new function `deploy_application_files()`
   - Copy files from PyInstaller temp directory (`sys._MEIPASS`) to install directory
   - Validate all required files were copied

3. **Bundle Python** or clearly document Python requirement:
   - Either: Use `python-embeddable` package
   - Or: Check Python availability and fail with clear error if missing

4. **Add comprehensive validation**:
   - Before launching GUI, verify all required files exist
   - Provide clear error messages if files are missing

### Option 2: Simplify to Nuitka Only

1. Remove PyInstaller bootstrap method entirely
2. Use only Nuitka method (slow but works)
3. Update documentation to reflect longer build times

### Option 3: Hybrid Approach

1. Create a **true bootstrap** that:
   - Downloads source archive from GitHub releases
   - Extracts to installation directory
   - Installs Python (if needed)
   - Runs the source installer

2. Keep the bootstrap small (~1-2 MB)
3. Download everything during installation

## Testing Requirements

Any rebuild must be tested with:

1. ✅ **Clean Windows VM** - No Python, no dependencies
2. ✅ **Clean Linux VM** - Minimal system
3. ✅ **macOS** - Fresh install
4. ✅ **Custom install paths** - Test with spaces, special characters
5. ✅ **Limited permissions** - Test without admin rights
6. ✅ **No internet** - Test offline scenarios (should fail gracefully)

## Conclusion

The current bootstrap installer is **fundamentally broken** and cannot be fixed with small patches. It requires a complete architectural redesign to:

1. Bundle or download application source files
2. Deploy files to the installation directory
3. Validate all requirements before attempting to launch
4. Handle Python runtime availability

**Recommended Action**: Implement Option 1 (Fix Bootstrap Installer) with comprehensive testing before any release.
