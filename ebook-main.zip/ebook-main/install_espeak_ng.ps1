$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$downloadPath = $null

try {
    Write-Host "Fetching latest espeak-ng release metadata..."
    $release = Invoke-RestMethod -Uri "https://api.github.com/repos/espeak-ng/espeak-ng/releases/latest"

    $asset = $release.assets |
        Where-Object { $_.name -like "*.msi" -and $_.name -match "(?i)win|windows|x64|amd64" } |
        Select-Object -First 1

    if (-not $asset) {
        throw "No compatible espeak-ng MSI asset found in latest release."
    }

    $downloadPath = Join-Path $env:TEMP $asset.name
    Write-Host "Downloading $($asset.name)..."
    Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $downloadPath

    Write-Host "Installing espeak-ng..."
    $install = Start-Process -FilePath "msiexec.exe" -ArgumentList "/i", $downloadPath, "/qn", "/norestart" -Wait -PassThru
    if ($install.ExitCode -ne 0) {
        throw "msiexec failed with exit code $($install.ExitCode)."
    }

    Write-Host "espeak-ng installed successfully."
}
catch {
    Write-Error "espeak-ng installation failed: $($_.Exception.Message)"
    exit 1
}
finally {
    if ($downloadPath -and (Test-Path $downloadPath)) {
        Remove-Item $downloadPath -Force -ErrorAction SilentlyContinue
    }
}
