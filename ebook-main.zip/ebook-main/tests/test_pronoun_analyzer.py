import unittest

from pronoun_analyzer import PronounAnalyzer


class PronounAnalyzerExtractionTests(unittest.TestCase):
    def test_filters_common_false_positive_non_character_tokens(self):
        text = """
        Thump. Thump. Thump.
        Mom! Dad! I'm home!
        Roman is a Platinum Adventurer.
        Alice traveled to Edelman with Roman.
        Roman greeted Dorian and Jane.
        "No. Alice is doing wonderfully."
        It was quiet. That was strange. If needed, Roman would help.
        """
        analyzer = PronounAnalyzer()

        extracted = analyzer.extract_characters_from_text(text)

        self.assertIn("Roman", extracted)
        self.assertIn("Dorian", extracted)
        self.assertIn("Jane", extracted)
        self.assertIn("Alice", extracted)
        self.assertNotIn("Thump", extracted)
        self.assertNotIn("Mom", extracted)
        self.assertNotIn("Dad", extracted)
        self.assertNotIn("No", extracted)
        self.assertNotIn("It", extracted)
        self.assertNotIn("That", extracted)
        self.assertNotIn("If", extracted)
        self.assertNotIn("Platinum", extracted)
        self.assertNotIn("Edelman", extracted)

    # ------------------------------------------------------------------
    # Step 1 – Honorific-based name-pattern filtering
    # ------------------------------------------------------------------

    def test_honorific_preceded_names_are_extracted(self):
        text = "Dr. Smith examined the patient. Mr. Jones arrived late."
        analyzer = PronounAnalyzer()

        extracted = analyzer.extract_characters_from_text(text)

        self.assertIn("Smith", extracted)
        self.assertIn("Jones", extracted)

    def test_honorific_names_bypass_location_filter(self):
        # "Baker" after "Mr." should be treated as a name even if it also
        # appears in a sentence-initial position that might be filtered.
        text = "Mr. Baker arrived at the station. Baker greeted everyone."
        analyzer = PronounAnalyzer()

        extracted = analyzer.extract_characters_from_text(text)

        self.assertIn("Baker", extracted)

    def test_multiple_honorific_styles_recognised(self):
        text = (
            "Captain Reynolds gave the order. "
            "Professor Moriarty was waiting. "
            "Lady Pemberton refused."
        )
        analyzer = PronounAnalyzer()

        extracted = analyzer.extract_characters_from_text(text)

        self.assertIn("Reynolds", extracted)
        self.assertIn("Moriarty", extracted)
        self.assertIn("Pemberton", extracted)


if __name__ == "__main__":
    unittest.main()
