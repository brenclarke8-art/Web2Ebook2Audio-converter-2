import unittest

from dialogue_detector import DialogueDetector


class _CorpusLLM:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []
        self.disabled = False

    def ask_json(self, system, user):
        self.calls.append({"system": system, "user": user})
        if self.responses:
            return self.responses.pop(0)
        return {}


class DialogueRegressionCorpusTests(unittest.TestCase):
    def test_regex_corpus_known_speaker_attribution(self):
        text = 'Alice said, "Hello Bob." Bob replied, "Hi Alice."'
        detector = DialogueDetector(llm_mode="off")

        segments = detector.detect_dialogue_in_text(text, known_characters=["Alice", "Bob"])
        dialogue = [s for s in segments if s.is_dialogue]

        self.assertEqual([s.speaker for s in dialogue], ["Alice", "Bob"])
        self.assertTrue(all(s.confidence >= 0.8 for s in dialogue))

    def test_db_only_corpus_filters_unknown_speaker_dialogue(self):
        text = 'Alice said, "Hello." Bob said, "Hey there."'
        detector = DialogueDetector(llm_mode="db_only")

        segments = detector.detect_dialogue_in_text(text, known_characters=["Alice"])
        dialogue = [s for s in segments if s.is_dialogue]

        self.assertEqual(len(dialogue), 1)
        self.assertEqual(dialogue[0].speaker, "Alice")

    def test_full_mode_corpus_single_pass_with_character_database_hints(self):
        text = '"I should leave," Alice said. Bob watched quietly.'
        llm = _CorpusLLM(
            responses=[
                {
                    "characters": ["Alice", "Bob"],
                    "segments": [
                        {"text": '"I should leave,"', "type": "dialogue", "speaker": "Alice"},
                        {"text": " Alice said. ", "type": "narration", "speaker": None},
                        {"text": "Bob watched quietly.", "type": "narration", "speaker": None},
                    ],
                },
            ]
        )
        detector = DialogueDetector(llm_mode="full", llm_client=llm)

        segments = detector.detect_dialogue_in_text(
            text,
            known_character_records=[{"name": "Alice", "gender": "female"}],
        )

        self.assertEqual(detector.get_last_mode_path(), ["full"])
        self.assertEqual(len(llm.calls), 1)
        self.assertEqual(len([s for s in segments if s.is_dialogue]), 1)


if __name__ == "__main__":
    unittest.main()
