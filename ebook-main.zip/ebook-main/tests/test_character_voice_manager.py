import unittest

from character_voice_manager import CharacterVoiceManager


class CharacterVoiceManagerTests(unittest.TestCase):
    def test_unknown_gender_auto_assign_avoids_narrator_voice(self):
        manager = CharacterVoiceManager(
            narrator_voice="am_adam",
            default_male_voice="am_adam",
            default_female_voice="af_sarah",
            auto_assign=True,
            dialogue_llm_mode="off",
        )

        assignments = manager.analyze_and_assign_voices(
            'Alice said, "Hello." Bob replied, "Hi."',
            known_characters=["Alice", "Bob"],
        )

        self.assertEqual(assignments["narrator"].voice_name, "am_adam")
        self.assertNotEqual(assignments["Alice"].voice_name, "am_adam")
        self.assertNotEqual(assignments["Bob"].voice_name, "am_adam")
        self.assertNotEqual(assignments["Alice"].voice_name, assignments["Bob"].voice_name)

    def test_auto_assign_avoids_narrator_voice_when_narrator_is_female(self):
        manager = CharacterVoiceManager(
            narrator_voice="af_sarah",
            default_male_voice="am_adam",
            default_female_voice="af_sarah",
            auto_assign=True,
            dialogue_llm_mode="off",
        )

        assignments = manager.analyze_and_assign_voices(
            'Alice said, "Hello."',
            known_characters=["Alice"],
        )

        self.assertEqual(assignments["narrator"].voice_name, "af_sarah")
        self.assertNotEqual(assignments["Alice"].voice_name, "af_sarah")

    def test_known_character_records_gender_overrides_drive_voice_gender(self):
        manager = CharacterVoiceManager(
            narrator_voice="af_heart",
            default_male_voice="am_adam",
            default_female_voice="af_sarah",
            auto_assign=True,
            dialogue_llm_mode="full",
        )

        assignments = manager.analyze_and_assign_voices(
            '"Hi," said Alex. "Hello," Chris replied.',
            known_characters=["Alex", "Chris"],
            known_character_records=[
                {"name": "Alex", "gender": "male"},
                {"name": "Chris", "gender": "female"},
            ],
        )

        male_voice = assignments["Alex"].voice_name
        female_voice = assignments["Chris"].voice_name
        self.assertEqual(manager.AVAILABLE_VOICES[male_voice]["gender"], "male")
        self.assertEqual(manager.AVAILABLE_VOICES[female_voice]["gender"], "female")


if __name__ == "__main__":
    unittest.main()
