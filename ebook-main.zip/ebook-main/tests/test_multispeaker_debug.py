import unittest

from character_voice_manager import CharacterVoiceAssignment
from dialogue_detector import DialogueSegment
from multispeaker_debug import build_multispeaker_debug_report, resolve_voice_mapping


class MultispeakerDebugTests(unittest.TestCase):
    def test_resolve_voice_mapping_supports_case_insensitive_speakers(self):
        resolution = resolve_voice_mapping(
            " alice ",
            {"Alice": "af_sarah", "narrator": "am_adam"},
            narrator_voice="am_adam",
        )

        self.assertEqual(resolution.matched_speaker, "Alice")
        self.assertEqual(resolution.voice, "af_sarah")
        self.assertEqual(resolution.resolution, "normalized-speaker")

    def test_resolve_voice_mapping_falls_back_to_narrator(self):
        resolution = resolve_voice_mapping(
            "Unknown",
            {"Alice": "af_sarah", "narrator": "am_adam"},
            narrator_voice="af_heart",
        )

        self.assertEqual(resolution.matched_speaker, "narrator")
        self.assertEqual(resolution.voice, "am_adam")
        self.assertEqual(resolution.resolution, "fallback-to-narrator")

    def test_build_multispeaker_debug_report_lists_non_exact_resolutions(self):
        report = build_multispeaker_debug_report(
            output_name="sample_book",
            assignments={
                "narrator": CharacterVoiceAssignment("narrator", "am_adam", dialogue_count=0),
                "Alice": CharacterVoiceAssignment("Alice", "af_sarah", gender="female", dialogue_count=1, auto_assigned=True),
            },
            voice_mappings={"narrator": "am_adam", "Alice": "af_sarah"},
            chapter_segments=[[
                DialogueSegment(text='"Hello."', speaker=" alice ", type="dialogue"),
                DialogueSegment(text='"??"', speaker="Unknown", type="dialogue"),
            ]],
            chapter_titles=["Chapter 1"],
            manual_mappings={"Bob": "bm_george"},
            narrator_voice="am_adam",
        )

        self.assertIn("Unused Manual Mappings", report)
        self.assertIn("Bob: configured_voice=bm_george", report)
        self.assertIn("normalized-speaker=1", report)
        self.assertIn("fallback-to-narrator=1", report)


if __name__ == "__main__":
    unittest.main()
