import unittest

from dialogue_detector import DialogueDetector, DialogueSegment


class FakeLLMClient:
    def __init__(self, responses):
        self._responses = list(responses)
        self.calls = []
        self.disabled = False

    def ask_json(self, system, user):
        self.calls.append({"system": system, "user": user})
        if self._responses:
            return self._responses.pop(0)
        return {}


class DialogueDetectorTests(unittest.TestCase):
    def test_regex_detects_dialogue_and_speakers(self):
        text = 'Alice said, "Hi Bob." Bob replied, "Hi Alice."'
        detector = DialogueDetector(use_llm=False)

        segments = detector.detect_dialogue_in_text(text, known_characters=["Alice", "Bob"])
        dialogue_segments = [segment for segment in segments if segment.is_dialogue]

        self.assertEqual(len(dialogue_segments), 2)
        self.assertEqual(dialogue_segments[0].text, "Hi Bob.")
        self.assertEqual(dialogue_segments[0].speaker, "Alice")
        self.assertEqual(dialogue_segments[1].text, "Hi Alice.")
        self.assertEqual(dialogue_segments[1].speaker, "Bob")

    def test_regex_maps_lowercase_speaker_to_known_character(self):
        text = 'alice said, "Hi Bob."'
        detector = DialogueDetector(use_llm=False)

        segments = detector.detect_dialogue_in_text(text, known_characters=["Alice"])
        dialogue_segments = [segment for segment in segments if segment.is_dialogue]

        self.assertEqual(len(dialogue_segments), 1)
        self.assertEqual(dialogue_segments[0].speaker, "Alice")

    def test_no_quotes_is_single_narration_segment(self):
        text = "Alice walked quietly through the hallway."
        detector = DialogueDetector(use_llm=False)

        segments = detector.detect_dialogue_in_text(text, known_characters=["Alice"])

        self.assertEqual(len(segments), 1)
        self.assertEqual(segments[0].type, "narration")
        self.assertEqual(segments[0].speaker, "narrator")
        self.assertFalse(segments[0].is_dialogue)

    def test_llm_refines_to_thought_and_infers_speaker(self):
        text = '"I should leave now."'
        fake_llm = FakeLLMClient(
            responses=[
                {"type": "thought", "speaker": None},
                {"speaker": "alice"},
            ]
        )
        detector = DialogueDetector(use_llm=True, llm_client=fake_llm)

        segments = detector.detect_dialogue_in_text(text, known_characters=["Alice"])

        self.assertEqual(len(segments), 1)
        self.assertEqual(segments[0].type, "thought")
        self.assertEqual(segments[0].speaker, "Alice")
        self.assertTrue(segments[0].is_dialogue)
        self.assertEqual(len(fake_llm.calls), 2)

    # ------------------------------------------------------------------
    # Step 3 – Confidence scoring
    # ------------------------------------------------------------------

    def test_attributed_known_character_has_high_confidence(self):
        text = 'Alice said, "Hello."'
        detector = DialogueDetector(use_llm=False)

        segments = detector.detect_dialogue_in_text(text, known_characters=["Alice"])
        dialogue = [s for s in segments if s.is_dialogue]

        self.assertEqual(len(dialogue), 1)
        self.assertGreater(dialogue[0].confidence, 0.8)

    def test_unattributed_dialogue_has_lower_confidence(self):
        text = '"Hello there."'
        detector = DialogueDetector(use_llm=False)

        segments = detector.detect_dialogue_in_text(text, known_characters=[])
        dialogue = [s for s in segments if s.is_dialogue]

        self.assertEqual(len(dialogue), 1)
        self.assertLess(dialogue[0].confidence, 0.8)

    def test_narration_segment_has_full_confidence(self):
        text = "She walked in silence."
        detector = DialogueDetector(use_llm=False)

        segments = detector.detect_dialogue_in_text(text, known_characters=[])

        self.assertEqual(len(segments), 1)
        self.assertEqual(segments[0].confidence, 1.0)

    def test_confidence_field_exists_on_segment(self):
        seg = DialogueSegment(text="hello")
        self.assertEqual(seg.confidence, 1.0)

    # ------------------------------------------------------------------
    # Step 2 – Multi-line quote support
    # ------------------------------------------------------------------

    def test_multi_line_quote_within_paragraph_detected(self):
        text = '"Hello there,\nhow are you?" Alice asked.'
        detector = DialogueDetector(use_llm=False)

        segments = detector.detect_dialogue_in_text(text, known_characters=["Alice"])
        dialogue = [s for s in segments if s.is_dialogue]

        self.assertEqual(len(dialogue), 1)
        self.assertIn("Hello there,", dialogue[0].text)
        self.assertIn("how are you?", dialogue[0].text)

    def test_paragraph_break_stops_quote_match(self):
        # A double newline (paragraph break) should not be consumed by a quote.
        text = '"First line\n\nSecond paragraph." Alice said.'
        detector = DialogueDetector(use_llm=False)

        segments = detector.detect_dialogue_in_text(text, known_characters=["Alice"])
        # The pattern should NOT match across the paragraph break, so the text
        # is treated as narration (no dialogue with Alice spanning paragraphs).
        dialogue = [s for s in segments if s.is_dialogue]
        for d in dialogue:
            self.assertNotIn("\n\n", d.text)
        # There must be at least one narration segment covering the remainder.
        narration = [s for s in segments if s.type == "narration"]
        self.assertGreaterEqual(len(narration), 1)

    # ------------------------------------------------------------------
    # Step 2 – LLM fallback for broken segments
    # ------------------------------------------------------------------

    def test_llm_fallback_called_for_broken_narration(self):
        # Narration containing an unclosed double-quote triggers the fallback.
        text = 'The narrator described: "hello world'
        fake_llm = FakeLLMClient(
            responses=[
                # Classification for the narration segment
                {"type": "narration", "speaker": None},
                # Broken segment fallback
                {"segments": [
                    {"text": "The narrator described: ", "type": "narration", "speaker": None},
                    {"text": "hello world", "type": "dialogue", "speaker": None},
                ]},
            ]
        )
        detector = DialogueDetector(use_llm=True, llm_client=fake_llm)

        segments = detector.detect_dialogue_in_text(text, known_characters=[])

        self.assertIsInstance(segments, list)
        # At least: classification call + broken-segment fallback call
        self.assertEqual(len(fake_llm.calls), 2)

    # ------------------------------------------------------------------
    # Step 1 – LLM character validation
    # ------------------------------------------------------------------

    def test_llm_character_validation_filters_non_persons(self):
        fake_llm = FakeLLMClient(responses=[{"characters": ["Alice"]}])
        detector = DialogueDetector(use_llm=True, llm_client=fake_llm)

        result = detector._validate_characters_with_llm(["Alice", "London", "Monday"])

        self.assertEqual(result, ["Alice"])
        self.assertEqual(len(fake_llm.calls), 1)

    def test_llm_character_validation_falls_back_on_empty_response(self):
        fake_llm = FakeLLMClient(responses=[{}])
        detector = DialogueDetector(use_llm=True, llm_client=fake_llm)
        candidates = ["Alice", "Bob"]

        result = detector._validate_characters_with_llm(candidates)

        self.assertEqual(result, candidates)

    # ------------------------------------------------------------------
    # LLM mode parameter
    # ------------------------------------------------------------------

    def test_llm_mode_off_sets_use_llm_false(self):
        detector = DialogueDetector(llm_mode="off")
        self.assertEqual(detector.llm_mode, "off")
        self.assertFalse(detector.use_llm)

    def test_llm_mode_half_sets_use_llm_true(self):
        detector = DialogueDetector(llm_mode="half")
        self.assertEqual(detector.llm_mode, "half")
        self.assertTrue(detector.use_llm)

    def test_llm_mode_full_sets_use_llm_true(self):
        detector = DialogueDetector(llm_mode="full")
        self.assertEqual(detector.llm_mode, "full")
        self.assertTrue(detector.use_llm)

    def test_llm_mode_db_only_sets_use_llm_false(self):
        detector = DialogueDetector(llm_mode="db_only")
        self.assertEqual(detector.llm_mode, "db_only")
        self.assertFalse(detector.use_llm)

    def test_use_llm_true_maps_to_half_mode(self):
        detector = DialogueDetector(use_llm=True)
        self.assertEqual(detector.llm_mode, "half")

    def test_use_llm_false_maps_to_off_mode(self):
        detector = DialogueDetector(use_llm=False)
        self.assertEqual(detector.llm_mode, "off")

    def test_explicit_llm_mode_overrides_use_llm(self):
        # llm_mode="full" should win even when use_llm=False is also passed.
        detector = DialogueDetector(use_llm=False, llm_mode="full")
        self.assertEqual(detector.llm_mode, "full")
        self.assertTrue(detector.use_llm)

    def test_db_only_keeps_only_known_character_dialogue(self):
        text = 'Alice said, "Hello." Bob said, "Hi." "Unattributed quote."'
        detector = DialogueDetector(llm_mode="db_only")

        segments = detector.detect_dialogue_in_text(text, known_characters=["Alice"])
        dialogue = [s for s in segments if s.is_dialogue]

        self.assertEqual(len(dialogue), 1)
        self.assertEqual(dialogue[0].speaker, "Alice")

    def test_db_only_without_known_characters_treats_all_as_narration(self):
        text = 'Alice said, "Hello there."'
        detector = DialogueDetector(llm_mode="db_only")

        segments = detector.detect_dialogue_in_text(text, known_characters=[])

        self.assertEqual(len([s for s in segments if s.is_dialogue]), 0)
        self.assertGreaterEqual(len([s for s in segments if s.type == "narration"]), 1)

    def test_full_mode_records_mode_path_without_fallback(self):
        text = 'Alice said, "Hello."'
        fake_llm = FakeLLMClient(
            responses=[
                {
                    "characters": ["Alice"],
                    "segments": [{"text": 'Alice said, "Hello."', "type": "dialogue", "speaker": "Alice"}],
                },
            ]
        )
        detector = DialogueDetector(llm_mode="full", llm_client=fake_llm)

        detector.detect_dialogue_in_text(text)

        self.assertEqual(detector.get_last_mode_path(), ["full"])

    def test_full_mode_returns_narration_when_llm_unavailable(self):
        text = 'Alice said, "Hello."'
        fake_llm = FakeLLMClient(responses=[])

        def failing_call(system, user):
            fake_llm.calls.append({"system": system, "user": user})
            fake_llm.disabled = True
            return {}

        fake_llm.ask_json = failing_call
        detector = DialogueDetector(llm_mode="full", llm_client=fake_llm)

        segments = detector.detect_dialogue_in_text(text, known_characters=["Alice"])

        self.assertGreaterEqual(len(segments), 1)
        self.assertEqual(detector.get_last_mode_path(), ["full"])
        self.assertEqual(len([s for s in segments if s.is_dialogue]), 0)
        self.assertEqual(segments[0].speaker, "narrator")

    def test_half_mode_strict_quotes_blocks_non_quoted_llm_dialogue(self):
        text = "Alice walked quietly through the hallway."
        fake_llm = FakeLLMClient(
            responses=[
                {"type": "dialogue", "speaker": "Alice"},
            ]
        )
        detector = DialogueDetector(
            use_llm=True,
            llm_client=fake_llm,
            llm_strict_quotes=True,
        )

        segments = detector.detect_dialogue_in_text(text, known_characters=["Alice"])

        self.assertEqual(len(segments), 1)
        self.assertEqual(segments[0].type, "narration")
        self.assertEqual(segments[0].speaker, "narrator")
        self.assertFalse(segments[0].is_dialogue)

    def test_full_mode_strict_quotes_forces_unquoted_llm_dialogue_to_narration(self):
        text = "Alice said hello."
        segmentation_response = {
            "characters": ["Alice"],
            "segments": [
                {"text": "Alice said hello.", "type": "dialogue", "speaker": "Alice"},
            ],
        }
        fake_llm = FakeLLMClient(responses=[segmentation_response])
        detector = DialogueDetector(
            llm_mode="full",
            llm_client=fake_llm,
            llm_strict_quotes=True,
        )

        segments = detector.detect_dialogue_in_text(text)

        self.assertEqual(len(segments), 1)
        self.assertEqual(segments[0].type, "narration")
        self.assertEqual(segments[0].speaker, "narrator")
        self.assertFalse(segments[0].is_dialogue)

    def test_full_mode_strict_quotes_keeps_embedded_double_quotes(self):
        text = 'Alice said, "Hello there."'
        segmentation_response = {
            "characters": ["Alice"],
            "segments": [
                {"text": 'Alice said, "Hello there."', "type": "dialogue", "speaker": "Alice"},
            ],
        }
        fake_llm = FakeLLMClient(responses=[segmentation_response])
        detector = DialogueDetector(
            llm_mode="full",
            llm_client=fake_llm,
            llm_strict_quotes=True,
        )

        segments = detector.detect_dialogue_in_text(text)

        self.assertEqual(len(segments), 1)
        self.assertEqual(segments[0].type, "dialogue")
        self.assertEqual(segments[0].speaker, "Alice")
        self.assertTrue(segments[0].is_dialogue)

    def test_full_mode_strict_quotes_accepts_smart_quotes(self):
        text = "Alice said, “Hello there.”"
        segmentation_response = {
            "characters": ["Alice"],
            "segments": [
                {"text": "Alice said, “Hello there.”", "type": "dialogue", "speaker": "Alice"},
            ],
        }
        fake_llm = FakeLLMClient(responses=[segmentation_response])
        detector = DialogueDetector(
            llm_mode="full",
            llm_client=fake_llm,
            llm_strict_quotes=True,
        )

        segments = detector.detect_dialogue_in_text(text)

        self.assertEqual(len(segments), 1)
        self.assertEqual(segments[0].type, "dialogue")
        self.assertEqual(segments[0].speaker, "Alice")
        self.assertTrue(segments[0].is_dialogue)

    # ------------------------------------------------------------------
    # Full mode – chapter-level LLM analysis
    # ------------------------------------------------------------------

    def test_full_mode_uses_single_llm_call(self):
        text = 'Alice said, "Hello." Bob walked in.'
        segmentation_response = {
            "characters": ["Alice", "Bob"],
            "segments": [
                {"text": 'Alice said, "Hello."', "type": "dialogue", "speaker": "Alice"},
                {"text": " Bob walked in.", "type": "narration", "speaker": None},
            ],
        }
        fake_llm = FakeLLMClient(responses=[segmentation_response])
        detector = DialogueDetector(llm_mode="full", llm_client=fake_llm)

        segments = detector.detect_dialogue_in_text(text)

        self.assertEqual(len(fake_llm.calls), 1)
        self.assertEqual(len(segments), 2)

    def test_full_mode_populates_characters_from_llm(self):
        text = 'Alice said, "Hello." Bob walked in.'
        fake_llm = FakeLLMClient(
            responses=[
                {
                    "characters": ["Alice", "Bob"],
                    "segments": [
                        {"text": 'Alice said, "Hello."', "type": "dialogue", "speaker": "Alice"},
                        {"text": " Bob walked in.", "type": "narration", "speaker": None},
                    ],
                },
            ]
        )
        detector = DialogueDetector(llm_mode="full", llm_client=fake_llm)
        detector.detect_dialogue_in_text(text)

        self.assertIn("Alice", detector.characters)
        self.assertIn("Bob", detector.characters)

    def test_full_mode_segment_types_and_speakers(self):
        text = '"I wonder," Alice thought. Bob said, "Indeed."'
        fake_llm = FakeLLMClient(
            responses=[
                {
                    "characters": ["Alice", "Bob"],
                    "segments": [
                        {"text": '"I wonder,"', "type": "thought", "speaker": "Alice"},
                        {"text": " Alice thought. ", "type": "narration", "speaker": None},
                        {"text": 'Bob said, "Indeed."', "type": "dialogue", "speaker": "Bob"},
                    ],
                }
            ]
        )
        detector = DialogueDetector(llm_mode="full", llm_client=fake_llm)

        segments = detector.detect_dialogue_in_text(text)

        self.assertEqual(segments[0].type, "thought")
        self.assertEqual(segments[0].speaker, "Alice")
        self.assertEqual(segments[1].type, "narration")
        self.assertEqual(segments[1].speaker, "narrator")
        self.assertEqual(segments[2].type, "dialogue")
        self.assertEqual(segments[2].speaker, "Bob")

    def test_full_mode_falls_back_to_regex_on_empty_llm_response(self):
        text = 'Alice said, "Hi Bob."'
        fake_llm = FakeLLMClient(responses=[{}])
        detector = DialogueDetector(llm_mode="full", llm_client=fake_llm)

        segments = detector.detect_dialogue_in_text(text, known_characters=["Alice", "Bob"])

        self.assertEqual(len(fake_llm.calls), 1)
        self.assertEqual(len([s for s in segments if s.is_dialogue]), 0)
        self.assertEqual(segments[0].speaker, "narrator")

    def test_full_mode_payload_structure(self):
        """Payload must include cleaned text and character hints."""
        text = 'Alice said, "Hello."'
        char_records = [{"name": "Alice", "gender": "female", "dialogue_count": 5, "mention_count": 10}]
        segmentation_response = {
            "characters": ["Alice"],
            "segments": [{"text": 'Alice said, "Hello."', "type": "dialogue", "speaker": "Alice"}],
        }
        fake_llm = FakeLLMClient(responses=[segmentation_response])
        detector = DialogueDetector(llm_mode="full", llm_client=fake_llm)

        detector.detect_dialogue_in_text(text, known_character_records=char_records)

        self.assertEqual(len(fake_llm.calls), 1)
        payload = fake_llm.calls[0]["user"]
        self.assertIsInstance(payload, dict)
        self.assertIn("text", payload)
        self.assertIn("characters", payload)
        self.assertIn("new_character_candidates", payload)
        self.assertEqual(payload["text"], text)
        self.assertEqual(payload["characters"], ["Alice"])

    def test_full_mode_preprocesses_ui_noise_before_pass1(self):
        text = (
            "Sign in\n"
            "FUCKNOVELPIA\n"
            "← Back to novel\n"
            "Chapter 488\n"
            '"I have come to ask for your permission," Alice said.'
        )
        response = {
            "characters": ["Alice"],
            "segments": [{"text": '"I have come to ask for your permission,"', "type": "dialogue", "speaker": "Alice"}],
        }
        fake_llm = FakeLLMClient(responses=[response])
        detector = DialogueDetector(llm_mode="full", llm_client=fake_llm)

        detector.detect_dialogue_in_text(text, known_characters=["Alice"])

        pass1_user = fake_llm.calls[0]["user"]
        cleaned = pass1_user["text"]
        self.assertNotIn("Sign in", cleaned)
        self.assertNotIn("FUCKNOVELPIA", cleaned)
        self.assertNotIn("Back to novel", cleaned)
        self.assertNotIn("Chapter 488", cleaned)
        self.assertIn("permission", cleaned)

    def test_preprocess_story_text_matches_llm_cleanup_rules(self):
        text = (
            "Sign in\n"
            "ADVERTISEMENT\n"
            "← Back to novel\n"
            "Chapter 12\n"
            'Alice said, "Hello there."\n'
            "She sat down."
        )
        detector = DialogueDetector(llm_mode="off")

        cleaned = detector.preprocess_story_text(text)

        self.assertNotIn("Sign in", cleaned)
        self.assertNotIn("ADVERTISEMENT", cleaned)
        self.assertNotIn("Back to novel", cleaned)
        self.assertNotIn("Chapter 12", cleaned)
        self.assertIn('Alice said, "Hello there."', cleaned)
        self.assertIn("She sat down.", cleaned)

    def test_full_mode_drops_hallucinated_speaker_with_authoritative_list(self):
        text = '"Hello."'
        first_pass = {
            "characters": ["Alice"],
            "segments": [{"text": '"Hello."', "type": "dialogue", "speaker": "Ghost"}],
        }
        fake_llm = FakeLLMClient(responses=[first_pass])
        detector = DialogueDetector(llm_mode="full", llm_client=fake_llm)

        segments = detector.detect_dialogue_in_text(text, known_characters=["Alice"])

        self.assertEqual(len(segments), 1)
        self.assertEqual(segments[0].type, "dialogue")
        self.assertIsNone(segments[0].speaker)

    def test_full_mode_allows_new_speaker_not_in_db_when_present_in_text(self):
        text = 'Bob said, "Hello."'
        first_pass = {
            "characters": ["Alice", "Bob"],
            "segments": [{"text": '"Hello."', "type": "dialogue", "speaker": "Bob"}],
        }
        fake_llm = FakeLLMClient(responses=[first_pass])
        detector = DialogueDetector(llm_mode="full", llm_client=fake_llm)

        segments = detector.detect_dialogue_in_text(text, known_characters=["Alice"])

        self.assertEqual(len(segments), 1)
        self.assertEqual(segments[0].speaker, "Bob")
        self.assertIn("Bob", detector.characters)

    def test_full_mode_keeps_extracted_character_when_no_authoritative_list(self):
        text = '"Hello."'
        first_pass = {
            "characters": ["Alice"],
            "segments": [{"text": '"Hello."', "type": "dialogue", "speaker": "Alice"}],
        }
        fake_llm = FakeLLMClient(responses=[first_pass])
        detector = DialogueDetector(llm_mode="full", llm_client=fake_llm)

        segments = detector.detect_dialogue_in_text(text)

        self.assertEqual(len(segments), 1)
        self.assertEqual(segments[0].speaker, "Alice")

    def test_full_mode_maps_general_type_to_narration(self):
        text = "Alice walked in."
        fake_llm = FakeLLMClient(
            responses=[
                {
                    "characters": ["Alice"],
                    "segments": [{"text": "Alice walked in.", "type": "general", "speaker": "narrator"}],
                }
            ]
        )
        detector = DialogueDetector(llm_mode="full", llm_client=fake_llm)

        segments = detector.detect_dialogue_in_text(text)

        self.assertEqual(len(segments), 1)
        self.assertEqual(segments[0].type, "narration")
        self.assertEqual(segments[0].speaker, "narrator")


if __name__ == "__main__":
    unittest.main()
