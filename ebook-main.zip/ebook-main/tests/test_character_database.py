import json
import tempfile
import unittest
from pathlib import Path

from character_database import BookCharacterDatabase


class BookCharacterDatabaseTests(unittest.TestCase):
    def test_save_and_load_per_book_characters(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            db = BookCharacterDatabase(temp_dir)

            path = db.save_characters(
                "My Test Book",
                [{"name": "Alice", "gender": "female", "dialogue_count": 4, "mention_count": 7}],
            )

            self.assertTrue(path.exists())
            self.assertIn("character_db", str(path))
            self.assertEqual(db.load_character_names("My Test Book"), ["Alice"])
            self.assertEqual(db.load_character_names("Other Book"), [])

    def test_save_merges_records_and_upgrades_unknown_gender(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            db = BookCharacterDatabase(temp_dir)
            book = "Merge Book"

            db.save_characters(
                book,
                [{"name": "Alice", "gender": "unknown", "dialogue_count": 1, "mention_count": 3}],
            )
            db.save_characters(
                book,
                [{"name": "alice", "gender": "female", "dialogue_count": 5, "mention_count": 2}],
            )

            records = db.load_records(book)
            self.assertEqual(len(records), 1)
            self.assertEqual(records[0]["gender"], "female")
            self.assertEqual(records[0]["dialogue_count"], 5)
            self.assertEqual(records[0]["mention_count"], 3)

    def test_load_handles_invalid_json(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            db = BookCharacterDatabase(temp_dir)
            path = Path(temp_dir) / "character_db" / "bad_book.json"
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("{not-json", encoding="utf-8")

            self.assertEqual(db.load_records("bad book"), [])
            self.assertEqual(db.load_character_names("bad book"), [])

    def test_save_persists_review_decisions(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            db = BookCharacterDatabase(temp_dir)
            book = "Decision Book"

            db.save_characters(
                book,
                [{"name": "Alice", "gender": "unknown", "dialogue_count": 1, "mention_count": 1}],
                review_decisions={
                    "rename_aliases": [{"from": "Alyce", "to": "Alice"}],
                    "gender_overrides": [{"name": "Alice", "gender": "female"}],
                },
            )

            decisions = db.load_review_decisions(book)
            self.assertEqual(decisions["rename_aliases"], [{"from": "Alyce", "to": "Alice"}])
            self.assertEqual(decisions["gender_overrides"], [{"name": "Alice", "gender": "female"}])

    def test_save_merges_review_decisions(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            db = BookCharacterDatabase(temp_dir)
            book = "Decision Merge"

            db.save_characters(
                book,
                [{"name": "Alice", "gender": "unknown", "dialogue_count": 1, "mention_count": 1}],
                review_decisions={"rename_aliases": [{"from": "Alyce", "to": "Alice"}]},
            )
            db.save_characters(
                book,
                [{"name": "Bob", "gender": "male", "dialogue_count": 1, "mention_count": 1}],
                review_decisions={"gender_overrides": [{"name": "Bob", "gender": "male"}]},
            )

            decisions = db.load_review_decisions(book)
            self.assertIn({"from": "Alyce", "to": "Alice"}, decisions["rename_aliases"])
            self.assertIn({"name": "Bob", "gender": "male"}, decisions["gender_overrides"])


if __name__ == "__main__":
    unittest.main()
