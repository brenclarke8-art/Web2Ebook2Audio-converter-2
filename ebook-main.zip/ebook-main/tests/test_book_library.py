"""Tests for book_library.BookLibrary and book_library.FillerChapterFilter."""

import json
import os
import tempfile
import unittest

from book_library import BookLibrary, FillerChapterFilter


class TestBookLibrary(unittest.TestCase):
    def setUp(self):
        self._tmpdir = tempfile.TemporaryDirectory()
        self.lib = BookLibrary(output_dir=self._tmpdir.name)

    def tearDown(self):
        self._tmpdir.cleanup()

    # ── add_book ──────────────────────────────────────────────────────────────

    def test_add_book_creates_entry(self):
        book_id = self.lib.add_book(
            title="My Novel", author="Author A", index_url="https://example.com/book"
        )
        self.assertIsNotNone(book_id)
        entry = self.lib.get_book(book_id)
        self.assertIsNotNone(entry)
        self.assertEqual(entry["title"], "My Novel")
        self.assertEqual(entry["author"], "Author A")
        self.assertEqual(entry["index_url"], "https://example.com/book")
        self.assertEqual(entry["last_processed_chapter"], 0)
        self.assertEqual(entry["last_chapter_count"], 0)
        self.assertEqual(entry["last_settings"], {})

    def test_add_book_with_initial_settings(self):
        settings = {"kokoro_voice": "af_sky", "kokoro_speed": 1.2}
        book_id = self.lib.add_book(
            title="Novel B", author="B", index_url="https://b.com/",
            settings=settings,
        )
        entry = self.lib.get_book(book_id)
        self.assertEqual(entry["last_settings"]["kokoro_voice"], "af_sky")

    def test_add_book_returns_unique_id_for_same_title(self):
        id1 = self.lib.add_book("Same Title", "A", "https://a.com/")
        id2 = self.lib.add_book("Same Title", "B", "https://b.com/")
        self.assertNotEqual(id1, id2)

    # ── remove_book ───────────────────────────────────────────────────────────

    def test_remove_book(self):
        book_id = self.lib.add_book("Novel C", "C", "https://c.com/")
        self.lib.remove_book(book_id)
        self.assertIsNone(self.lib.get_book(book_id))

    def test_remove_nonexistent_book_is_noop(self):
        self.lib.remove_book("does-not-exist")  # should not raise

    # ── update_after_run ──────────────────────────────────────────────────────

    def test_update_after_run_persists_chapter_progress(self):
        settings = {"kokoro_voice": "af_sky"}
        book_id = self.lib.add_book("Novel D", "D", "https://d.com/")
        self.lib.update_after_run(
            book_id,
            last_processed_chapter=5,
            last_chapter_count=10,
            settings=settings,
        )
        entry = self.lib.get_book(book_id)
        self.assertEqual(entry["last_processed_chapter"], 5)
        self.assertEqual(entry["last_chapter_count"], 10)
        self.assertEqual(entry["last_settings"]["kokoro_voice"], "af_sky")
        self.assertIsNotNone(entry["last_converted"])

    def test_update_after_run_partial_settings_round_trip(self):
        book_id = self.lib.add_book("Novel E", "E", "https://e.com/")
        snap = {"kokoro_speed": 0.9, "_lib_audio_batch_size": 5}
        self.lib.update_after_run(book_id, 3, 20, snap)
        entry = self.lib.get_book(book_id)
        self.assertEqual(entry["last_settings"]["kokoro_speed"], 0.9)
        self.assertEqual(entry["last_settings"]["_lib_audio_batch_size"], 5)

    # ── update_checked ────────────────────────────────────────────────────────

    def test_update_checked_sets_chapter_count(self):
        book_id = self.lib.add_book("Novel F", "F", "https://f.com/")
        self.lib.update_checked(book_id, last_chapter_count=7)
        entry = self.lib.get_book(book_id)
        self.assertEqual(entry["last_chapter_count"], 7)
        self.assertIsNotNone(entry["last_checked"])

    # ── list_books ────────────────────────────────────────────────────────────

    def test_list_books_returns_all(self):
        self.lib.add_book("A", "a", "https://a.com/")
        self.lib.add_book("B", "b", "https://b.com/")
        books = self.lib.list_books()
        self.assertEqual(len(books), 2)

    # ── persistence across reload ─────────────────────────────────────────────

    def test_persistence_across_reload(self):
        book_id = self.lib.add_book("Persist Me", "P", "https://p.com/")
        self.lib.update_after_run(book_id, 3, 10, {"kokoro_voice": "am_adam"})

        # Reload from disk
        lib2 = BookLibrary(output_dir=self._tmpdir.name)
        entry = lib2.get_book(book_id)
        self.assertIsNotNone(entry)
        self.assertEqual(entry["title"], "Persist Me")
        self.assertEqual(entry["last_processed_chapter"], 3)
        self.assertEqual(entry["last_settings"]["kokoro_voice"], "am_adam")

    def test_library_file_is_valid_json(self):
        self.lib.add_book("JSON Check", "J", "https://j.com/")
        lib_path = os.path.join(self._tmpdir.name, "library.json")
        with open(lib_path) as fh:
            data = json.load(fh)
        self.assertIsInstance(data, dict)
        self.assertEqual(len(data), 1)

    # ── update_book (edit) ────────────────────────────────────────────────────

    def test_update_book_changes_metadata(self):
        book_id = self.lib.add_book("Old Title", "Old Author", "https://old.com/")
        self.lib.update_book(book_id, title="New Title", author="New Author",
                             index_url="https://new.com/")
        entry = self.lib.get_book(book_id)
        self.assertEqual(entry["title"], "New Title")
        self.assertEqual(entry["author"], "New Author")
        self.assertEqual(entry["index_url"], "https://new.com/")

    def test_update_nonexistent_book_raises(self):
        with self.assertRaises(KeyError):
            self.lib.update_book("ghost-id", title="X")


class TestFillerChapterFilter(unittest.TestCase):
    def setUp(self):
        self.f = FillerChapterFilter(min_words=10)

    # ── URL filtering ─────────────────────────────────────────────────────────

    def test_coming_soon_url_is_filler(self):
        self.assertTrue(self.f.is_filler_url("https://site.com/book/coming-soon"))

    def test_locked_chapter_url_is_filler(self):
        self.assertTrue(self.f.is_filler_url("https://site.com/book/locked-chapter-5"))

    def test_advance_chapter_url_is_filler(self):
        self.assertTrue(self.f.is_filler_url("https://site.com/book/advance-chapter"))

    def test_normal_chapter_url_is_not_filler(self):
        self.assertFalse(self.f.is_filler_url("https://site.com/book/chapter-42"))
        self.assertFalse(self.f.is_filler_url("https://site.com/novel/ch-1"))

    def test_filter_urls_splits_correctly(self):
        urls = [
            "https://site.com/book/chapter-1",
            "https://site.com/book/coming-soon",
            "https://site.com/book/chapter-2",
            "https://site.com/book/locked-chapter",
        ]
        clean, filler = self.f.filter_urls(urls)
        self.assertEqual(len(clean), 2)
        self.assertEqual(len(filler), 2)
        self.assertIn("https://site.com/book/chapter-1", clean)
        self.assertIn("https://site.com/book/chapter-2", clean)

    # ── Content filtering ─────────────────────────────────────────────────────

    def test_short_content_is_filler(self):
        self.assertTrue(self.f.is_filler_content("Too short."))

    def test_subscribe_phrase_is_filler(self):
        long_content = (
            "Some preamble text. " * 20
            + "Subscribe to read the full chapter."
        )
        self.assertTrue(self.f.is_filler_content(long_content))

    def test_locked_chapter_phrase_is_filler(self):
        long_content = (
            "Some preamble. " * 20
            + "This is a locked chapter. Please subscribe."
        )
        self.assertTrue(self.f.is_filler_content(long_content))

    def test_filler_title_is_caught(self):
        long_content = "Word " * 50
        self.assertTrue(self.f.is_filler_content(long_content, title="Coming Soon"))

    def test_normal_chapter_content_passes(self):
        long_content = (
            "The hero drew his sword and faced the dragon. "
            "The battle was fierce and long. " * 20
        )
        self.assertFalse(self.f.is_filler_content(long_content, title="Chapter 5"))

    def test_filter_chapters_splits_correctly(self):
        chapters = [
            {"title": "Chapter 1", "content": "Good content. " * 20},
            {"title": "Coming Soon", "content": "Tiny"},
            {"title": "Chapter 2", "content": "More good content. " * 20},
        ]
        clean, filler = self.f.filter_chapters(chapters)
        self.assertEqual(len(clean), 2)
        self.assertEqual(len(filler), 1)
        self.assertEqual(filler[0]["title"], "Coming Soon")


if __name__ == "__main__":
    unittest.main()
