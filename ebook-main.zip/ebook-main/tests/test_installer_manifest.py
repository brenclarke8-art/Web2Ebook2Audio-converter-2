import ast
import unittest
from pathlib import Path

from installer_manifest import (
    INSTALLATION_VALIDATION_FILES,
    PYINSTALLER_DEPLOY_DIRECTORIES,
    PYINSTALLER_DEPLOY_FILES,
    UPDATER_REQUIRED_FILES,
)


REPO_ROOT = Path(__file__).resolve().parent.parent


class InstallerManifestTests(unittest.TestCase):
    def test_main_local_imports_are_deployed(self):
        deployed_files = set(PYINSTALLER_DEPLOY_FILES)
        main_source = (REPO_ROOT / "main.py").read_text(encoding="utf-8")
        tree = ast.parse(main_source)

        imported_files = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                module_names = [alias.name for alias in node.names]
            elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                module_names = [node.module]
            else:
                continue

            for module_name in module_names:
                root_module = module_name.split(".")[0]
                local_module_path = REPO_ROOT / f"{root_module}.py"
                if local_module_path.exists():
                    imported_files.add(local_module_path.name)

        self.assertTrue(imported_files)
        for filename in imported_files:
            self.assertIn(filename, deployed_files)

    def test_updater_required_files_are_deployed(self):
        deployed_files = set(PYINSTALLER_DEPLOY_FILES)
        for filename in UPDATER_REQUIRED_FILES:
            self.assertIn(filename, deployed_files)

    def test_validation_includes_critical_files(self):
        validated_files = set(INSTALLATION_VALIDATION_FILES)
        self.assertIn("character_database.py", validated_files)
        self.assertIn("installer.py", validated_files)
        self.assertIn("kokoro_tts", set(PYINSTALLER_DEPLOY_DIRECTORIES))


if __name__ == "__main__":
    unittest.main()
