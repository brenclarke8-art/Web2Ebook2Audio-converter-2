#!/usr/bin/env bash
set -euo pipefail
python3 updater.py
exit $?
