# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller spec file for Web to Ebook Converter Bootstrap Installer.

The installer exe produced here is intentionally small and version-stable.
Application source files and the Python runtime are NOT bundled; the installer
downloads them from the latest GitHub release and from the Python NuGet feed at
install time.  This means the same installer.exe can be committed to the
repository and reused across releases without being rebuilt.
"""

a = Analysis(
    ['installer.py'],
    pathex=[],
    binaries=[],
    datas=[],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # Exclude heavy dependencies - they will be installed at runtime
        'torch',
        'transformers',
        'playwright',
        'numpy',
        'scipy',
        'pandas',
        'matplotlib',
        'PIL',
        'cv2',
        'tensorflow',
        'keras',
    ],
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='WebToEbookInstaller',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    coerce_macros_file=None,
    entitlements_file=None,
    icon=None,
)
