#!/usr/bin/env python3
"""
Uninstaller for Web to Ebook Converter.

Removes the application, its Python runtime, virtual environment, and
optionally backs up user data before deletion.

Usage:
    python uninstaller.py                           # interactive, detects dir
    python uninstaller.py --install-dir <path>      # explicit install path
"""

import argparse
import os
import platform
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

APP_NAME = "Web to Ebook Converter"

# User-generated content that may be worth backing up before removal
USER_DATA_DIRS = ["output"]
USER_DATA_FILES = ["config.yaml"]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def prompt_yes_no(message: str, default: bool = True) -> bool:
    """Prompt for a yes/no answer, returning *default* on empty input."""
    suffix = "[Y/n]" if default else "[y/N]"
    while True:
        answer = input(f"{message} {suffix}: ").strip().lower()
        if not answer:
            return default
        if answer in ("y", "yes"):
            return True
        if answer in ("n", "no"):
            return False
        print("Please enter 'y' or 'n'.")


def get_install_dir(arg_path: str | None) -> Path:
    """Return the installation directory to uninstall.

    Priority: explicit --install-dir arg → directory of this script.
    """
    if arg_path:
        return Path(arg_path).resolve()
    return Path(__file__).parent.resolve()


def _dir_size_mb(path: Path) -> float:
    """Return the total size of *path* in megabytes (best-effort)."""
    try:
        return sum(
            f.stat().st_size
            for f in path.rglob("*")
            if f.is_file()
        ) / (1024 * 1024)
    except Exception:
        return 0.0


# ---------------------------------------------------------------------------
# User-data backup
# ---------------------------------------------------------------------------

def backup_user_data(install_dir: Path) -> Path | None:
    """Copy user data (config, output/) to ~/Web to Ebook Converter Backup.

    Returns the backup directory path, or None if nothing was backed up.
    """
    backup_dir = Path.home() / f"{APP_NAME} Backup"
    backed_up: list[str] = []

    for dirname in USER_DATA_DIRS:
        src = install_dir / dirname
        if src.exists() and src.is_dir():
            dest = backup_dir / dirname
            try:
                if dest.exists():
                    shutil.rmtree(dest)
                shutil.copytree(src, dest)
                backed_up.append(dirname)
            except Exception as e:
                print(f"[!] Could not back up {dirname}/: {e}")

    for filename in USER_DATA_FILES:
        src = install_dir / filename
        if src.exists():
            try:
                backup_dir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, backup_dir / filename)
                backed_up.append(filename)
            except Exception as e:
                print(f"[!] Could not back up {filename}: {e}")

    if backed_up:
        print(f"[+] Backed up to: {backup_dir}")
        print(f"    Items: {', '.join(backed_up)}")
        return backup_dir

    return None


# ---------------------------------------------------------------------------
# Directory removal
# ---------------------------------------------------------------------------

def _rmtree_onerror(func, path: str, exc_info) -> None:
    """onerror callback for shutil.rmtree – try chmod then retry."""
    try:
        os.chmod(path, 0o700)
        func(path)
    except Exception:
        pass  # locked / permission denied – uninstall.bat cleans up the rest


def remove_directory_tree(path: Path) -> tuple[bool, list[str]]:
    """Remove *path* recursively.

    Returns ``(all_removed, list_of_skipped_paths)``.
    """
    failed: list[str] = []

    def on_error(func, p, exc_info):
        _rmtree_onerror(func, p, exc_info)
        if Path(p).exists():
            failed.append(str(p))

    shutil.rmtree(path, onerror=on_error)
    return (not Path(path).exists()), failed


# ---------------------------------------------------------------------------
# Windows-specific: espeak-ng uninstall
# ---------------------------------------------------------------------------

def _find_espeak_uninstall_string() -> str | None:
    """Return the MSI uninstall string for espeak-ng from the registry."""
    try:
        import winreg  # type: ignore[import]
    except ImportError:
        return None

    search_roots = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
    ]
    for hive, key_path in search_roots:
        try:
            with winreg.OpenKey(hive, key_path) as parent:
                count = winreg.QueryInfoKey(parent)[0]
                for i in range(count):
                    try:
                        subkey_name = winreg.EnumKey(parent, i)
                        with winreg.OpenKey(parent, subkey_name) as subkey:
                            display_name = winreg.QueryValueEx(subkey, "DisplayName")[0]
                            if "espeak" in display_name.lower():
                                uninstall_str = winreg.QueryValueEx(subkey, "UninstallString")[0]
                                return uninstall_str
                    except (FileNotFoundError, OSError):
                        continue
        except (FileNotFoundError, PermissionError, OSError):
            continue
    return None


def uninstall_espeak_ng_windows() -> None:
    """Attempt to silently uninstall espeak-ng via its MSI uninstall string."""
    uninstall_str = _find_espeak_uninstall_string()
    if not uninstall_str:
        print("[*] espeak-ng system installation not found in registry.")
        return

    print(f"[*] Found espeak-ng uninstall entry.")
    # msiexec uninstall strings look like: MsiExec.exe /I{GUID} or /X{GUID}
    # Convert /I to /X for proper uninstall, add silent flags
    cmd = uninstall_str.replace("/I{", "/X{").replace("/i{", "/X{")
    if "/quiet" not in cmd.lower() and "/qn" not in cmd.lower():
        cmd += " /qn /norestart"
    try:
        result = subprocess.run(cmd, shell=True, check=False)
        if result.returncode == 0:
            print("[+] espeak-ng uninstalled successfully.")
        else:
            print(f"[!] espeak-ng uninstall exited with code {result.returncode}.")
            print("    You can uninstall it manually via Windows Settings > Apps.")
    except Exception as e:
        print(f"[!] Failed to uninstall espeak-ng: {e}")
        print("    You can uninstall it manually via Windows Settings > Apps.")


# ---------------------------------------------------------------------------
# Main uninstall logic
# ---------------------------------------------------------------------------

def run_uninstaller(install_dir: Path, skip_confirm: bool = False) -> int:
    """Interactive uninstall workflow.

    Returns 0 on success, 1 on cancellation or error.
    """
    print("=" * 60)
    print(f"Uninstaller – {APP_NAME}")
    print("=" * 60)

    if not install_dir.exists():
        print(f"\n[!] Installation directory not found: {install_dir}")
        print("    Nothing to uninstall.")
        if platform.system() == "Windows":
            input("\nPress Enter to exit...")
        return 0

    size_mb = _dir_size_mb(install_dir)
    print(f"\n[*] Installation directory: {install_dir}")
    print(f"    Approximate size: {size_mb:.1f} MB")

    print("\n[!] The following will be PERMANENTLY REMOVED:")
    print("    - All application files and source code")
    print("    - Bundled Python runtime and virtual environment")
    print("    - Kokoro TTS engine files")
    print("    - Cached Kokoro model weights (if stored inside the install dir)")
    print("    - Log files inside the install directory")

    print("\n[*] The following are NOT removed automatically:")
    print("    - espeak-ng (installed system-wide; you will be asked separately)")
    if platform.system() == "Windows":
        hf_cache_path = r"%USERPROFILE%\.cache\huggingface"
    else:
        hf_cache_path = "~/.cache/huggingface"
    print(f"    - Hugging Face model cache ({hf_cache_path})")
    print("    - Output files outside the install directory")

    # Offer to back up user data
    has_user_data = any(
        (install_dir / item).exists()
        for item in USER_DATA_DIRS + USER_DATA_FILES
    )
    backup_dir: Path | None = None
    if has_user_data and not skip_confirm:
        print("\n[*] User data found (config.yaml and/or output/ directory).")
        if prompt_yes_no("Back up user data before removing?", True):
            backup_dir = backup_user_data(install_dir)

    # Final confirmation
    print()
    if not skip_confirm:
        if not prompt_yes_no(f"Are you sure you want to uninstall {APP_NAME}?", False):
            print("\nUninstall cancelled.")
            if platform.system() == "Windows":
                input("\nPress Enter to exit...")
            return 0

    # Remove the installation directory
    print(f"\n[*] Removing: {install_dir}")
    success, failed = remove_directory_tree(install_dir)

    if success:
        print(f"[+] Successfully removed installation directory.")
    else:
        if failed:
            print(f"[!] Some files could not be deleted (may still be in use):")
            for item in failed[:8]:
                print(f"    - {item}")
            if len(failed) > 8:
                print(f"    ... and {len(failed) - 8} more")
            if platform.system() == "Windows":
                print("[*] uninstall.bat will attempt a final cleanup after this script exits.")
            else:
                print("[*] You may need to manually delete the remaining files.")

    # Optional espeak-ng removal
    if platform.system() == "Windows":
        print()
        if not skip_confirm:
            if prompt_yes_no("Uninstall espeak-ng from Windows?", False):
                uninstall_espeak_ng_windows()
        else:
            print("[*] Skipping espeak-ng removal (--yes mode). "
                  "Remove it manually via Windows Settings > Apps if desired.")

    print()
    print("=" * 60)
    print("Uninstall complete!")
    if backup_dir:
        print(f"Your data was backed up to:")
        print(f"    {backup_dir}")
    print("=" * 60)

    if platform.system() == "Windows":
        input("\nPress Enter to exit...")

    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        description=f"Uninstaller for {APP_NAME}",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--install-dir",
        metavar="PATH",
        help=(
            "Path to the installation directory to remove. "
            "Defaults to the directory containing this script."
        ),
    )
    parser.add_argument(
        "--yes",
        action="store_true",
        help="Skip interactive confirmation prompts and proceed immediately.",
    )
    args = parser.parse_args()

    install_dir = get_install_dir(args.install_dir)
    return run_uninstaller(install_dir, skip_confirm=args.yes)


if __name__ == "__main__":
    raise SystemExit(main())
