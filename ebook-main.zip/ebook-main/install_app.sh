#!/usr/bin/env bash

echo "============================================================"
echo "Web to Ebook Converter - Bootstrap Installer"
echo "============================================================"
echo ""

# Check if Python 3 is installed
if command -v python3 &> /dev/null; then
    echo "[*] Python 3 found. Checking version..."
    python3 --version
    echo ""

    # Check if version is 3.8 or higher
    PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
    REQUIRED_VERSION="3.8"

    if [ "$(printf '%s\n' "$REQUIRED_VERSION" "$PYTHON_VERSION" | sort -V | head -n1)" = "$REQUIRED_VERSION" ]; then
        echo "[*] Python $PYTHON_VERSION is compatible (3.8+ required)."
        echo ""

        SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

        echo "============================================================"
        echo "Starting Installer"
        echo "============================================================"
        echo ""
        echo "[*] Launching guided installer..."
        echo ""
        exec python3 "$SCRIPT_DIR/installer.py"
    else
        echo "[!] Python version $PYTHON_VERSION is too old. Python 3.8 or higher required."
        echo ""
    fi
fi

echo "[!] Python 3 not found or incompatible version detected."
echo ""
echo "This application requires Python 3.8 or higher to run."
echo ""
echo "============================================================"
echo "Python Installation Instructions"
echo "============================================================"
echo ""

# Detect OS
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    echo "For Ubuntu/Debian:"
    echo "  sudo apt update"
    echo "  sudo apt install python3 python3-pip python3-venv"
    echo ""
    echo "For Fedora/RHEL:"
    echo "  sudo dnf install python3 python3-pip"
    echo ""
    echo "For Arch Linux:"
    echo "  sudo pacman -S python python-pip"
    echo ""
elif [[ "$OSTYPE" == "darwin"* ]]; then
    echo "For macOS:"
    echo ""
    if command -v brew &> /dev/null; then
        echo "  Using Homebrew (recommended):"
        echo "    brew install python@3.11"
        echo ""
        read -p "Install Python 3.11 via Homebrew now? (y/N): " INSTALL_PYTHON
        if [[ "$INSTALL_PYTHON" =~ ^[Yy]$ ]]; then
            echo ""
            echo "[*] Installing Python 3.11..."
            brew install python@3.11

            if [ $? -eq 0 ]; then
                echo ""
                echo "[*] Python installed successfully!"
                echo "[*] Starting application installer..."
                echo ""
                exec python3 installer.py
            else
                echo ""
                echo "[!] Failed to install Python via Homebrew."
                exit 1
            fi
        fi
    else
        echo "  Option 1 - Homebrew (recommended):"
        echo "    First install Homebrew:"
        echo "      /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
        echo "    Then install Python:"
        echo "      brew install python@3.11"
        echo ""
    fi
    echo "  Option 2 - Official installer:"
    echo "    Download from: https://www.python.org/downloads/"
    echo ""
else
    echo "Please install Python 3.8 or higher from:"
    echo "  https://www.python.org/downloads/"
    echo ""
fi

echo "After installing Python, run this installer again:"
echo "  ./install_app.sh"
echo ""

exit 1
