import logging
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Optional
from config import Config
from scraper import WebScraper
from ebook_generator import EbookGenerator
from tts_engine import TTSEngine
from translator import Translator, TranslationConfig, TranslationRule
from sync_text_generator import SyncTextGenerator
from character_voice_manager import CharacterVoiceManager
from dialogue_detector import DialogueDetector
from character_database import BookCharacterDatabase
from multispeaker_debug import build_normalized_voice_lookup, resolve_voice_mapping

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)


class WebToEbookApp:
    """Main application"""

    def __init__(self, config: Config = None):
        logging.debug("Initializing WebToEbookApp")
        self.config = config or Config()
        logging.debug(f"Config loaded: output_dir={self.config.output_dir}")

        logging.debug("Initializing WebScraper")
        self.scraper = self.create_fresh_scraper()
        logging.debug(f"WebScraper initialized with {len(self.config.css_selectors)} CSS selectors, "
                     f"visual_order={self.config.use_visual_order}, browser mode")

        logging.debug("Initializing EbookGenerator")
        self.ebook_gen = EbookGenerator(self.config.output_dir)
        logging.debug(f"EbookGenerator initialized with output_dir={self.config.output_dir}")

        logging.debug("Initializing TTSEngine")
        self.tts = TTSEngine(
            self.config.output_dir,
            device=self.config.tts_device,
            preload_voices=self.config.preload_voices,
            default_lang_code=self.config.kokoro_lang_code
        )
        logging.debug(f"TTSEngine initialized with Kokoro TTS")

        logging.debug("Initializing SyncTextGenerator")
        self.sync_text_gen = SyncTextGenerator(self.config.output_dir)
        logging.debug("SyncTextGenerator initialized")
        self.character_db = BookCharacterDatabase(self.config.output_dir)

        # Initialize translator if enabled
        if self.config.enable_translation:
            logging.debug("Translation is enabled, initializing Translator")
            translation_config = TranslationConfig(
                enabled=True,
                source_language=self.config.source_language,
                target_language=self.config.target_language,
                api_url=self.config.translation_api_url,
                api_key=self.config.translation_api_key,
                custom_rules=self._load_translation_rules()
            )
            self.translator = Translator(translation_config)
            logging.debug(f"Translator initialized: source={self.config.source_language}, target={self.config.target_language}")
        else:
            logging.debug("Translation is disabled")
            self.translator = None

        # Initialize character voice manager if enabled
        if self.config.enable_character_voices:
            logging.debug("Character voices enabled, initializing CharacterVoiceManager")
            self.character_voice_manager = CharacterVoiceManager(
                narrator_voice=self.config.narrator_voice,
                default_male_voice=self.config.default_male_voice,
                default_female_voice=self.config.default_female_voice,
                auto_assign=self.config.auto_assign_character_voices,
                dialogue_llm_mode="full",
                dialogue_llm_model=self.config.dialogue_llm_model,
                dialogue_llm_url=self.config.dialogue_llm_url,
                dialogue_llm_timeout=self.config.dialogue_llm_timeout,
                dialogue_llm_strict_quotes=self.config.dialogue_llm_strict_quotes,
            )
            logging.debug("CharacterVoiceManager initialized")
        else:
            logging.debug("Character voices disabled")
            self.character_voice_manager = None

    def _create_dialogue_detector(self, llm_mode_override: Optional[str] = None) -> DialogueDetector:
        """Create a DialogueDetector using current config options."""
        llm_mode = self.config.dialogue_llm_mode if llm_mode_override is None else llm_mode_override
        llm_log_path = None
        if llm_mode != "off":
            llm_log_path = str(Path(self.config.output_dir) / "llm_communication.log")
        return DialogueDetector(
            llm_mode=llm_mode,
            llm_model=self.config.dialogue_llm_model,
            llm_url=self.config.dialogue_llm_url,
            llm_timeout=self.config.dialogue_llm_timeout,
            llm_log_path=llm_log_path,
            llm_strict_quotes=self.config.dialogue_llm_strict_quotes,
        )

    def _get_known_characters_for_book(self, output_name: str) -> List[str]:
        """Load known characters for a book from config and persisted character DB."""
        known = set(self.config.character_voice_mappings.keys()) if self.config.character_voice_mappings else set()
        persisted = self.character_db.load_character_names(output_name)
        known.update(persisted)
        known.discard('narrator')
        combined = sorted(name for name in known if name)
        if combined:
            logging.debug(
                "Loaded %d known characters for '%s' from config/character DB",
                len(combined),
                output_name,
            )
        return combined

    def create_fresh_scraper(self) -> WebScraper:
        """Create a new scraper instance with the current app configuration."""
        return WebScraper(
            self.config.css_selectors,
            self.config.use_visual_order,
            wait_for_js=self.config.wait_for_js,
            use_existing_browser=self.config.use_existing_browser,
            browser_cdp_url=self.config.browser_cdp_url,
            remove_overlays=self.config.remove_overlays,
            browser_timeout=self.config.browser_timeout,
            exclude_selectors=self.config.exclude_selectors
        )

    def _prepare_chapters_for_audio(self, chapters: list) -> list:
        """Return chapter copies with content cleaned for audio/sync output."""
        detector = self._create_dialogue_detector()
        prepared = []
        cleaned_count = 0

        for chapter in chapters:
            raw_content = chapter.get('content', '')
            cleaned_content = detector.preprocess_story_text(raw_content)
            if cleaned_content != raw_content:
                cleaned_count += 1
            prepared.append({
                **chapter,
                'content': cleaned_content,
            })

        if cleaned_count:
            logging.info(
                "Stripped UI/boilerplate text from %d chapter(s) during audio/sync preparation",
                cleaned_count,
            )

        return prepared

    def _load_translation_rules(self):
        """Load translation rules from config"""
        logging.debug("Loading translation rules from config")
        if not self.config.translation_rules:
            logging.debug("No translation rules configured")
            return []

        rules = []
        logging.debug(f"Processing {len(self.config.translation_rules)} translation rules")
        for rule_data in self.config.translation_rules:
            rules.append(TranslationRule(
                pattern=rule_data.get('pattern', ''),
                replacement=rule_data.get('replacement', ''),
                is_regex=rule_data.get('is_regex', False),
                case_sensitive=rule_data.get('case_sensitive', True)
            ))
        logging.debug(f"Loaded {len(rules)} translation rules")
        return rules

    def _log_multispeaker_debug_summary(
        self,
        output_name: str,
        assignments: Dict[str, Any],
        voice_mappings: Dict[str, str],
        dialogue_segments_by_chapter: List[List[Any]],
        audio_chapters: List[dict],
    ) -> None:
        """Emit privacy-safe summary logs for multi-speaker voice resolution."""
        total_segments = sum(len(segments) for segments in dialogue_segments_by_chapter)
        dialogue_segments = sum(
            1
            for segments in dialogue_segments_by_chapter
            for segment in segments
            if segment.is_dialogue
        )
        normalized_lookup = build_normalized_voice_lookup(voice_mappings)
        non_exact_counts = Counter()
        for segments in dialogue_segments_by_chapter:
            for segment in segments:
                if not segment.is_dialogue:
                    continue
                resolution = resolve_voice_mapping(
                    segment.speaker,
                    voice_mappings,
                    narrator_voice=self.config.narrator_voice,
                    normalized_lookup=normalized_lookup,
                )
                if resolution.resolution != "exact":
                    non_exact_counts[resolution.resolution] += 1

        logging.info(
            "Multi-speaker summary for '%s': assignments=%d, mapped_voices=%d, chapters=%d, "
            "total_segments=%d, dialogue_segments=%d",
            output_name,
            len(assignments),
            len(set(voice_mappings.values())),
            len(audio_chapters),
            total_segments,
            dialogue_segments,
        )
        if non_exact_counts:
            logging.warning(
                "Multi-speaker non-exact voice resolutions: %s",
                dict(sorted(non_exact_counts.items())),
            )
        else:
            logging.info("Multi-speaker voice resolution matched exact speaker names for all dialogue segments")

    def _write_multispeaker_debug_report(
        self,
        output_name: str,
        assignments: Optional[Dict[str, Any]] = None,
        voice_mappings: Optional[Dict[str, str]] = None,
        dialogue_segments_by_chapter: Optional[List[List[Any]]] = None,
        audio_chapters: Optional[List[dict]] = None,
    ) -> str:
        """Write a multi-speaker debug report file to the configured output directory."""
        output_dir = Path(self.config.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        report_path = output_dir / f"{output_name}_multispeaker_debug.txt"

        if not self.config.enable_character_voices:
            report = (
                "Multi-Speaker Debug Report\n"
                + "=" * 60
                + "\n"
                + f"Book: {output_name}\n"
                + "Status: Character voices are disabled (enable_character_voices=false).\n"
            )
        elif not assignments or not dialogue_segments_by_chapter or not audio_chapters:
            report = (
                "Multi-Speaker Debug Report\n"
                + "=" * 60
                + "\n"
                + f"Book: {output_name}\n"
                + "Status: No multi-speaker assignments/segments available for report generation.\n"
            )
        else:
            safe_mappings = voice_mappings or {}
            total_segments = sum(len(segments) for segments in dialogue_segments_by_chapter)
            dialogue_segments = sum(
                1
                for segments in dialogue_segments_by_chapter
                for segment in segments
                if getattr(segment, "is_dialogue", False)
            )
            normalized_lookup = build_normalized_voice_lookup(safe_mappings)
            non_exact_counts = Counter()
            for segments in dialogue_segments_by_chapter:
                for segment in segments:
                    if not getattr(segment, "is_dialogue", False):
                        continue
                    resolution = resolve_voice_mapping(
                        getattr(segment, "speaker", None),
                        safe_mappings,
                        narrator_voice=self.config.narrator_voice,
                        normalized_lookup=normalized_lookup,
                    )
                    if resolution.resolution != "exact":
                        non_exact_counts[resolution.resolution] += 1

            report = "\n".join(
                [
                    "Multi-Speaker Debug Report",
                    "=" * 60,
                    f"Book: {output_name}",
                    "Status: Character voices enabled",
                    f"Assignments: {len(assignments)}",
                    f"Unique voices: {len(set(safe_mappings.values()))}",
                    f"Chapters: {len(audio_chapters)}",
                    f"Total segments: {total_segments}",
                    f"Dialogue segments: {dialogue_segments}",
                    f"Non-exact resolutions: {dict(sorted(non_exact_counts.items())) if non_exact_counts else 'none'}",
                ]
            ) + "\n"

        try:
            with open(report_path, 'w', encoding='utf-8') as handle:
                handle.write(report)
            logging.info("Wrote multi-speaker debug report: %s", report_path)
        except Exception as exc:
            logging.error("Failed to write multi-speaker debug report %s: %s", report_path, exc)
        return str(report_path)

    def _generate_character_artifacts(self, chapters: list, output_name: str) -> dict:
        """Generate character checklist and color-coded dialogue preview artifacts."""
        logging.info("Generating character checklist and dialogue preview")
        combined_text = '\n\n'.join(ch.get('content', '') for ch in chapters if ch.get('content'))

        detector = self._create_dialogue_detector(llm_mode_override="full")
        known_character_records = self.character_db.load_records(output_name) or []
        review_decisions = self.character_db.load_review_decisions(output_name)
        segments = detector.detect_dialogue_in_text(
            combined_text,
            # Always run extraction here so we can detect unknown/new characters.
            known_characters=None,
            known_character_records=known_character_records,
        )
        mode_path = detector.get_last_mode_path()

        characters_with_gender = detector.get_characters_with_gender()
        mention_counts = {
            name: profile.mention_count
            for name, profile in detector.characters.items()
        }
        dialogue_counts = Counter(
            (segment.speaker or 'narrator')
            for segment in segments
            if segment.is_dialogue
        )

        checklist = []
        dialogue_confidence_totals: Dict[str, float] = {}
        dialogue_confidence_counts: Dict[str, int] = {}
        for segment in segments:
            if not segment.is_dialogue or not segment.speaker:
                continue
            key = segment.speaker
            dialogue_confidence_totals[key] = dialogue_confidence_totals.get(key, 0.0) + segment.confidence
            dialogue_confidence_counts[key] = dialogue_confidence_counts.get(key, 0) + 1

        for name, gender in characters_with_gender.items():
            count = dialogue_confidence_counts.get(name, 0)
            avg_confidence = (
                dialogue_confidence_totals.get(name, 0.0) / count
                if count > 0 else 0.0
            )
            checklist.append({
                'name': name,
                'gender': gender or 'unknown',
                'dialogue_count': dialogue_counts.get(name, 0),
                'mention_count': mention_counts.get(name, 0),
                'avg_dialogue_confidence': round(avg_confidence, 3),
            })

        checklist = [
            dict(
                entry,
                source_name=entry.get('name', ''),
                source_gender=entry.get('gender', 'unknown'),
            )
            for entry in checklist
        ]
        raw_checklist = [dict(entry) for entry in checklist]
        checklist = self._apply_review_decisions_to_checklist(checklist, review_decisions)
        checklist.sort(key=lambda item: (item['dialogue_count'], item['mention_count'], item['name']), reverse=True)
        delta_summary = self._compute_character_delta_summary(checklist, known_character_records)
        low_conf_threshold = max(0.0, min(1.0, float(self.config.character_review_low_confidence_threshold)))
        low_confidence_new_characters = [
            entry['name']
            for entry in checklist
            if entry.get('name')
            and entry['name'] in delta_summary['new_characters']
            and float(entry.get('avg_dialogue_confidence', 0.0)) < low_conf_threshold
        ]
        delta_summary['low_confidence_new_characters'] = low_confidence_new_characters

        checklist_lines = [
            "Character Checklist",
            "=" * 60,
            f"Book: {output_name}",
            "",
        ]
        if checklist:
            for entry in checklist:
                checklist_lines.append(
                    f"- {entry['name']}: gender={entry['gender']}, dialogue_segments={entry['dialogue_count']}, mentions={entry['mention_count']}, avg_confidence={entry.get('avg_dialogue_confidence', 1.0):.2f}"
                )
        else:
            checklist_lines.append("- No characters were identified.")
        checklist_lines.extend([
            "",
            "Delta Summary",
            "-" * 60,
            f"New characters: {len(delta_summary['new_characters'])}",
            f"Gender changes: {len(delta_summary['gender_changes'])}",
            f"Low-confidence new characters (< {low_conf_threshold:.2f}): {len(low_confidence_new_characters)}",
            f"LLM mode path: {' -> '.join(mode_path) if mode_path else 'full'}",
        ])

        checklist_path = Path(self.config.output_dir) / f"{output_name}_character_checklist.txt"
        checklist_path.parent.mkdir(parents=True, exist_ok=True)
        checklist_path.write_text("\n".join(checklist_lines), encoding="utf-8")

        preview_path = self.sync_text_gen.generate_character_dialogue_preview(
            segments,
            checklist,
            f"{output_name}_character_preview.html",
            title=f"{output_name} - Character Dialogue Preview",
        )
        print("  ✓ Character checklist created")
        print(f"    {checklist_path}")
        print("  ✓ Character dialogue preview created")
        print(f"    {preview_path}")
        if delta_summary['new_characters']:
            print(f"  ⚠️  New characters detected: {len(delta_summary['new_characters'])}")
        if delta_summary['gender_changes']:
            print(f"  ⚠️  Character gender changes detected: {len(delta_summary['gender_changes'])}")
        if mode_path and len(mode_path) > 1:
            print(f"  ⚠️  LLM fallback path used: {' -> '.join(mode_path)}")
        new_characters = list(delta_summary['new_characters'])

        return {
            'character_checklist': checklist,
            'raw_character_checklist': raw_checklist,
            'character_checklist_file': str(checklist_path),
            'character_preview_html': str(preview_path),
            'new_characters': new_characters,
            'new_characters_detected': bool(new_characters),
            'character_delta_summary': delta_summary,
            'llm_mode_path': mode_path,
        }

    def _should_prompt_character_review(self, character_artifacts: dict) -> bool:
        delta_summary = character_artifacts.get('character_delta_summary', {})
        return bool(
            self.config.character_manual_review
            or delta_summary.get('low_confidence_new_characters')
            or delta_summary.get('gender_changes')
        )

    def _review_characters_cli(
        self, checklist: list, output_name: str, new_characters: list, character_artifacts: dict
    ) -> Optional[List[dict]]:
        """Prompt user to confirm extracted characters in CLI mode."""
        separator_width = 60
        print("\n" + "-" * separator_width)
        print(f"🧑‍🤝‍🧑 Character Review — {output_name}")
        delta_summary = character_artifacts.get('character_delta_summary', {})
        low_conf = delta_summary.get('low_confidence_new_characters', [])
        if new_characters:
            print(f"New characters not yet in DB: {len(new_characters)}")
            if low_conf:
                print(f"Low-confidence new characters: {len(low_conf)}")
        elif self.config.character_manual_review:
            print("Manual character review is enabled.")
        if delta_summary.get('gender_changes'):
            print(f"Gender changes vs DB: {len(delta_summary['gender_changes'])}")
        if delta_summary.get('renamed_candidates'):
            print(f"Renamed candidates: {len(delta_summary['renamed_candidates'])}")

        if checklist:
            print(f"\nDetected characters: {len(checklist)}")
        else:
            print("\nNo characters were detected.")

        while True:
            response = input(
                "Continue with this character list? (selecting 'no' cancels conversion) [Y/n]: "
            ).strip().lower()
            if response in ("", "y", "yes"):
                return checklist
            if response in ("n", "no"):
                return None
            print("Please enter 'y' or 'n'.")

    def _persist_character_checklist(self, output_name: str, character_artifacts: dict) -> str:
        checklist = character_artifacts.get('character_checklist', [])
        review_decisions = self._collect_review_decisions(character_artifacts)
        db_path = self.character_db.save_characters(
            output_name,
            checklist,
            review_decisions=review_decisions,
        )
        print("  ✓ Character database updated")
        print(f"    {db_path}")
        return str(db_path)

    def _compute_character_delta_summary(self, checklist: List[Dict], known_records: List[Dict]) -> Dict:
        existing_by_key = {}
        for record in known_records or []:
            if not isinstance(record, dict):
                continue
            name = str(record.get('name', '')).strip()
            if not name:
                continue
            existing_by_key[name.casefold()] = record

        new_characters: List[str] = []
        gender_changes: List[Dict] = []
        renamed_candidates: List[Dict] = []
        for entry in checklist:
            name = str(entry.get('name', '')).strip()
            if not name:
                continue
            key = name.casefold()
            existing = existing_by_key.get(key)
            if not existing:
                new_characters.append(name)
                continue
            existing_name = str(existing.get('name', '')).strip()
            if existing_name and existing_name != name:
                renamed_candidates.append({'from': existing_name, 'to': name})
            old_gender = str(existing.get('gender', 'unknown')).strip().lower() or 'unknown'
            new_gender = str(entry.get('gender', 'unknown')).strip().lower() or 'unknown'
            if old_gender != new_gender and new_gender != 'unknown':
                gender_changes.append({'name': name, 'from': old_gender, 'to': new_gender})

        return {
            'new_characters': sorted(new_characters),
            'gender_changes': gender_changes,
            'renamed_candidates': renamed_candidates,
        }

    def _apply_review_decisions_to_checklist(self, checklist: List[Dict], review_decisions: Dict) -> List[Dict]:
        rename_lookup = {}
        for decision in review_decisions.get('rename_aliases', []):
            src = str(decision.get('from', '')).strip()
            dest = str(decision.get('to', '')).strip()
            if src and dest and src.casefold() != dest.casefold():
                rename_lookup[src.casefold()] = dest

        gender_lookup = {}
        for decision in review_decisions.get('gender_overrides', []):
            name = str(decision.get('name', '')).strip()
            gender = str(decision.get('gender', 'unknown')).strip().lower() or 'unknown'
            if name and gender in {"male", "female", "neutral", "unknown"}:
                gender_lookup[name.casefold()] = gender

        merged: Dict[str, Dict] = {}
        for entry in checklist:
            if not isinstance(entry, dict):
                continue
            name = str(entry.get('name', '')).strip()
            if not name:
                continue
            effective_name = rename_lookup.get(name.casefold(), name)
            effective_gender = gender_lookup.get(
                effective_name.casefold(),
                str(entry.get('gender', 'unknown')).strip().lower() or 'unknown'
            )
            row = dict(entry)
            row['name'] = effective_name
            row['gender'] = effective_gender
            key = effective_name.casefold()
            if key not in merged:
                merged[key] = row
                continue
            merged[key]['dialogue_count'] = max(
                int(merged[key].get('dialogue_count', 0)),
                int(row.get('dialogue_count', 0)),
            )
            merged[key]['mention_count'] = max(
                int(merged[key].get('mention_count', 0)),
                int(row.get('mention_count', 0)),
            )
            merged[key]['avg_dialogue_confidence'] = max(
                float(merged[key].get('avg_dialogue_confidence', 0.0)),
                float(row.get('avg_dialogue_confidence', 0.0)),
            )
            if merged[key].get('gender', 'unknown') == 'unknown' and effective_gender != 'unknown':
                merged[key]['gender'] = effective_gender

        return list(merged.values())

    def _collect_review_decisions(self, character_artifacts: Dict) -> Dict:
        checklist = character_artifacts.get('character_checklist', [])
        original = character_artifacts.get('raw_character_checklist', [])
        original_by_source = {}
        for row in original:
            source = str(row.get('source_name', row.get('name', ''))).strip()
            if source:
                original_by_source[source.casefold()] = row

        rename_aliases = []
        gender_overrides = []
        for row in checklist:
            if not isinstance(row, dict):
                continue
            name = str(row.get('name', '')).strip()
            if not name:
                continue
            source = str(row.get('source_name', name)).strip() or name
            if source.casefold() != name.casefold():
                rename_aliases.append({'from': source, 'to': name})
            source_row = original_by_source.get(source.casefold())
            new_gender = str(row.get('gender', 'unknown')).strip().lower() or 'unknown'
            old_gender = (
                str(source_row.get('gender', 'unknown')).strip().lower()
                if isinstance(source_row, dict) else 'unknown'
            ) or 'unknown'
            if new_gender in {"male", "female", "neutral", "unknown"} and new_gender != old_gender:
                gender_overrides.append({'name': name, 'gender': new_gender})

        return {
            'rename_aliases': rename_aliases,
            'gender_overrides': gender_overrides,
        }

    def process(self, urls: list, output_name: str = None) -> dict:
        """Process URLs into EPUB and audio"""
        logging.debug("Starting process method")
        logging.debug(f"Input: {len(urls)} URLs")
        output_name = output_name or self.config.epub_title
        logging.debug(f"Output name: {output_name}")

        print("\n" + "="*50)
        print("🌐 WEB TO EBOOK CONVERTER")
        print("="*50)

        # Apply chapter range if configured
        logging.debug("Applying chapter range configuration")
        original_url_count = len(urls)
        start_idx = max(0, self.config.start_chapter - 1)  # Convert to 0-based
        end_idx = self.config.end_chapter if self.config.end_chapter > 0 else len(urls)
        logging.debug(f"Chapter range: start_idx={start_idx}, end_idx={end_idx}, original_count={original_url_count}")

        if start_idx > 0 or end_idx < len(urls):
            urls = urls[start_idx:end_idx]
            logging.debug(f"Chapter range applied: reduced from {original_url_count} to {len(urls)} URLs")
            print(f"\n⚠️  Chapter range applied: Processing chapters {start_idx + 1} to {min(end_idx, original_url_count)} ({len(urls)} chapters)")

        # Apply chapter limit if configured (applies after range selection)
        logging.debug(f"Checking chapter limit: max_chapters={self.config.max_chapters}")
        if self.config.max_chapters > 0 and len(urls) > self.config.max_chapters:
            logging.debug(f"Applying chapter limit: reducing from {len(urls)} to {self.config.max_chapters}")
            urls = urls[:self.config.max_chapters]
            print(f"\n⚠️  Chapter limit applied: Processing {len(urls)} of {original_url_count} chapters")

        # Step 1: Scrape
        logging.debug("="*50)
        logging.debug("STEP 1: SCRAPING")
        logging.debug("="*50)
        print(f"\n📖 Step 1: Scraping {len(urls)} chapters...")
        logging.debug(f"Starting scraping of {len(urls)} URLs")
        chapters = self.scraper.scrape_chapters(urls)
        logging.debug(f"Scraping complete: {len(chapters)} chapters scraped")

        # Validate that we have chapters with content
        if not chapters:
            error_msg = "No chapters were successfully scraped. Cannot proceed with EPUB or audio generation."
            logging.error(error_msg)
            raise ValueError(error_msg)

        # Check if any chapters have content
        chapters_with_content = [ch for ch in chapters if ch.get('content', '').strip()]
        if not chapters_with_content:
            error_msg = f"All {len(chapters)} chapters are empty. Cannot proceed with EPUB or audio generation."
            logging.error(error_msg)
            raise ValueError(error_msg)

        if len(chapters_with_content) < len(chapters):
            empty_count = len(chapters) - len(chapters_with_content)
            logging.warning(f"⚠️  {empty_count} chapters had no content and will be skipped")
            print(f"⚠️  Warning: {empty_count} chapters had no content and will be skipped")
            chapters = chapters_with_content

        # Preview: Show first 3 chapters for user verification
        if not self._preview_chapters(chapters):
            print("\n❌ Conversion cancelled by user")
            logging.info("User cancelled conversion after preview")
            return {'status': 'cancelled', 'message': 'User cancelled after preview'}

        # Step 2: Translate (if enabled)
        if self.translator:
            logging.debug("="*50)
            logging.debug("STEP 2: TRANSLATION")
            logging.debug("="*50)
            print(f"\n🌐 Step 2: Translating content...")
            logging.debug(f"Starting translation of {len(chapters)} chapters")
            chapters = self.translator.translate_chapters(chapters)
            logging.debug("Translation complete")
            step_num = 3
        else:
            logging.debug("Skipping translation step (translator not enabled)")
            step_num = 2

        # Step 3/2: Create EPUB
        logging.debug("="*50)
        logging.debug(f"STEP {step_num}: EPUB CREATION")
        logging.debug("="*50)
        print(f"\n📄 Step {step_num}: Creating EPUB...")
        logging.debug(f"Creating EPUB with {len(chapters)} chapters, title='{output_name}', author='{self.config.epub_author}'")
        epub_path = self.ebook_gen.create_epub(
            chapters,
            output_name,
            self.config.epub_author
        )
        logging.debug(f"EPUB created: {epub_path}")

        step_num += 1
        print(f"\n🧭 Step {step_num}: Building character checklist and preview...")
        character_artifacts = self._generate_character_artifacts(chapters, output_name)
        raw_checklist = character_artifacts.get('character_checklist', [])
        if self._should_prompt_character_review(character_artifacts):
            confirmed_characters = self._review_characters_cli(
                raw_checklist,
                output_name,
                character_artifacts.get('new_characters', []),
                character_artifacts,
            )
            if confirmed_characters is None:
                print("\n❌ Conversion cancelled by user at character review")
                logging.info("User cancelled conversion at character review")
                return {'status': 'cancelled', 'message': 'User cancelled at character review'}
            character_artifacts['character_checklist'] = confirmed_characters
        character_artifacts['character_database_file'] = self._persist_character_checklist(
            output_name,
            character_artifacts,
        )

        # Next step: Generate Audio
        audio_chapters = self._prepare_chapters_for_audio(chapters)
        step_num += 1
        logging.debug("="*50)
        logging.debug(f"STEP {step_num}: AUDIO GENERATION")
        logging.debug("="*50)
        print(f"\n🔊 Step {step_num}: Generating audio...")

        # Character voice setup if enabled
        dialogue_segments_by_chapter = []
        voice_mappings = {}

        if self.character_voice_manager:
            logging.info("Character voices enabled - analyzing text for characters and dialogue")
            print("  📝 Analyzing characters and dialogue...")

            # Analyze all chapter text for characters
            combined_text = '\n\n'.join([ch['content'] for ch in audio_chapters])
            known_character_records = self.character_db.load_records(output_name) or None

            # Analyze and assign voices
            known_characters = self._get_known_characters_for_book(output_name) or None
            assignments = self.character_voice_manager.analyze_and_assign_voices(
                combined_text,
                known_characters=known_characters,
                manual_mappings=self.config.character_voice_mappings,
                known_character_records=known_character_records,
            )

            # Build voice mappings dictionary
            voice_mappings = {char_name: assignment.voice_name
                             for char_name, assignment in assignments.items()}

            # Display assignment report
            print("\n  Character Voice Assignments:")
            print("  " + "="*50)
            for char_name, assignment in sorted(assignments.items(),
                                               key=lambda x: x[1].dialogue_count,
                                               reverse=True):
                auto_tag = " (auto)" if assignment.auto_assigned else " (manual)"
                gender_tag = f" [{assignment.gender}]" if assignment.gender else ""
                print(f"    {char_name}{gender_tag}: {assignment.voice_name}{auto_tag}")
            print("  " + "="*50)

            # Detect dialogue in each chapter
            print("  🗣️  Detecting dialogue segments...")
            detector = self._create_dialogue_detector(llm_mode_override="full")
            for chapter in audio_chapters:
                segments = detector.detect_dialogue_in_text(
                    chapter['content'],
                    known_characters=list(assignments.keys()),
                    known_character_records=known_character_records,
                )
                dialogue_segments_by_chapter.append(segments)
                logging.debug(f"Chapter '{chapter.get('title', 'Untitled')}': {len(segments)} segments detected")

            self._log_multispeaker_debug_summary(
                output_name,
                assignments,
                voice_mappings,
                dialogue_segments_by_chapter,
                audio_chapters,
            )
            debug_report_path = self._write_multispeaker_debug_report(
                output_name,
                assignments=assignments,
                voice_mappings=voice_mappings,
                dialogue_segments_by_chapter=dialogue_segments_by_chapter,
                audio_chapters=audio_chapters,
            )
            print(f"  [debug] Multi-speaker summary emitted to application log")
            print(f"  [debug] Multi-speaker report: {debug_report_path}")

            # Get all assigned voices for preloading
            all_voices = self.character_voice_manager.get_all_assigned_voices()
            if all_voices and all_voices not in self.config.preload_voices:
                logging.info(f"Preloading {len(all_voices)} voices for character voices: {all_voices}")
                # Note: Voices will be loaded on-demand during generation

        if not self.character_voice_manager:
            self._write_multispeaker_debug_report(output_name)

        kwargs = {
            'voice': self.config.kokoro_voice,
            'lang_code': self.config.kokoro_lang_code,
            'speed': self.config.kokoro_speed
        }
        logging.debug(f"Using Kokoro TTS with voice={self.config.kokoro_voice}, lang_code={self.config.kokoro_lang_code}, speed={self.config.kokoro_speed}")

        audio_files = []
        chapter_info = []

        if self.config.generate_per_chapter_audio:
            logging.debug("Per-chapter audio generation mode enabled")
            # Generate separate audio file for each chapter
            print("  Generating per-chapter audio files...")
            logging.debug(f"Generating {len(audio_chapters)} separate audio files")
            for i, chapter in enumerate(audio_chapters, 1):
                logging.debug(f"Processing chapter {i}/{len(audio_chapters)}: {chapter.get('title', 'Untitled')}")
                chapter_text = chapter['content']
                logging.debug(f"Chapter {i} content length: {len(chapter_text)} characters")

                # Apply duration limit if configured
                if self.config.max_duration > 0:
                    logging.debug(f"Applying duration limit: {self.config.max_duration} minutes")
                    chapter_text = self._apply_duration_limit(chapter_text, self.config.max_duration)
                    logging.debug(f"Chapter {i} text after duration limit: {len(chapter_text)} characters")

                chapter_filename = f'{output_name}_chapter_{i:03d}.wav'
                logging.debug(f"Generating audio for chapter {i}: {chapter_filename}")

                # Use multi-voice generation if character voices enabled
                if self.character_voice_manager and dialogue_segments_by_chapter:
                    segments = dialogue_segments_by_chapter[i-1]
                    audio_path = self.tts.generate_multi_voice_audio(
                        segments,
                        chapter_filename,
                        voice_mappings,
                        dialogue_pause=self.config.dialogue_pause,
                        **kwargs
                    )
                else:
                    audio_path = self.tts.generate_audio(
                        chapter_text,
                        chapter_filename,
                        **kwargs
                    )

                audio_files.append(str(audio_path))
                chapter_info.append({
                    'number': i,
                    'title': chapter.get('title', f'Chapter {i}'),
                    'audio': str(audio_path),
                    'text': chapter_text
                })
                logging.debug(f"Chapter {i} audio complete: {audio_path}")
                print(f"  ✓ Chapter {i}: {audio_path}")

            # Create combined audio as well for convenience
            logging.debug("Creating combined audio file")
            combined_text = '\n\n'.join([ch['content'] for ch in audio_chapters])
            logging.debug(f"Combined text length: {len(combined_text)} characters")
            if self.config.max_duration > 0:
                logging.debug(f"Applying duration limit to combined audio: {self.config.max_duration} minutes")
                combined_text = self._apply_duration_limit(combined_text, self.config.max_duration)

            logging.debug("Generating combined audio file")

            # Use multi-voice if enabled
            if self.character_voice_manager and dialogue_segments_by_chapter:
                # Flatten all dialogue segments from all chapters
                all_segments = []
                for segments in dialogue_segments_by_chapter:
                    all_segments.extend(segments)
                combined_audio_path = self.tts.generate_multi_voice_audio(
                    all_segments,
                    f'{output_name}_complete.wav',
                    voice_mappings,
                    dialogue_pause=self.config.dialogue_pause,
                    **kwargs
                )
            else:
                combined_audio_path = self.tts.generate_audio(
                    combined_text,
                    f'{output_name}_complete.wav',
                    **kwargs
                )

            logging.debug(f"Combined audio complete: {combined_audio_path}")
            print(f"  ✓ Combined: {combined_audio_path}")
        else:
            logging.debug("Single combined audio mode enabled")
            # Generate single combined audio file
            combined_text = '\n\n'.join([ch['content'] for ch in audio_chapters])
            logging.debug(f"Combined text length: {len(combined_text)} characters")

            # Apply duration limit if configured
            if self.config.max_duration > 0:
                logging.debug(f"Applying duration limit: {self.config.max_duration} minutes")
                combined_text = self._apply_duration_limit(combined_text, self.config.max_duration)

            logging.debug("Generating single combined audio file")

            # Use multi-voice if enabled
            if self.character_voice_manager and dialogue_segments_by_chapter:
                # Flatten all dialogue segments from all chapters
                all_segments = []
                for segments in dialogue_segments_by_chapter:
                    all_segments.extend(segments)
                combined_audio_path = self.tts.generate_multi_voice_audio(
                    all_segments,
                    f'{output_name}.wav',
                    voice_mappings,
                    dialogue_pause=self.config.dialogue_pause,
                    **kwargs
                )
            else:
                combined_audio_path = self.tts.generate_audio(
                    combined_text,
                    f'{output_name}.wav',
                    **kwargs
                )

            logging.debug(f"Combined audio complete: {combined_audio_path}")

            # Create chapter info for combined audio
            logging.debug("Creating chapter info for combined audio")
            for i, chapter in enumerate(audio_chapters, 1):
                chapter_info.append({
                    'number': i,
                    'title': chapter.get('title', f'Chapter {i}'),
                    'audio': str(combined_audio_path),
                    'text': chapter['content']
                })

        # Step 5/4: Generate Synchronized Text Display
        step_num += 1
        logging.debug("="*50)
        logging.debug(f"STEP {step_num}: SYNCHRONIZED TEXT GENERATION")
        logging.debug("="*50)
        print(f"\n📝 Step {step_num}: Generating synchronized text display...")

        if self.config.generate_per_chapter_audio:
            logging.debug("Generating chapter-based synchronized text")
            # Generate chapter-based synchronized text with navigation
            logging.debug(f"Generating chapter navigation HTML for {len(chapter_info)} chapters")
            sync_html_path = self.sync_text_gen.generate_chapter_html(
                chapter_info,
                f'{output_name}_sync.html',
                title=output_name,
                speech_rate=self.config.speech_rate
            )
            logging.debug(f"Chapter HTML generated: {sync_html_path}")
        else:
            logging.debug("Generating single synchronized text HTML")
            # Generate single combined synchronized text
            combined_text = '\n\n'.join([ch['content'] for ch in audio_chapters])
            logging.debug(f"Combined text length for sync: {len(combined_text)} characters")
            sync_html_path = self.sync_text_gen.generate_html(
                combined_text,
                f'{output_name}.wav',
                f'{output_name}_sync.html',
                title=output_name,
                speech_rate=self.config.speech_rate
            )
            logging.debug(f"Synchronized HTML generated: {sync_html_path}")

        logging.debug("="*50)
        logging.debug("PROCESS COMPLETE")
        logging.debug("="*50)
        print("\n" + "="*50)
        print("✅ Conversion complete!")
        print(f"📕 EPUB: {epub_path}")

        if self.config.generate_per_chapter_audio:
            print(f"🎵 Audio files: {len(audio_files)} chapter files + 1 combined")
            print(f"   Combined: {combined_audio_path}")
        else:
            print(f"🎵 Audio: {combined_audio_path}")

        print("👥 Character checklist and dialogue preview generated")
        print(f"📄 Synchronized Text: {sync_html_path}")
        print("="*50 + "\n")

        result = {
            'epub': str(epub_path),
            'audio': str(combined_audio_path),
            'sync_html': str(sync_html_path),
            'chapters': len(chapters)
        }
        result.update(character_artifacts)

        if self.config.generate_per_chapter_audio:
            result['chapter_audio_files'] = audio_files
            result['chapter_info'] = chapter_info

        logging.debug(f"Process complete. Result: {list(result.keys())}")
        return result

    def batch_process(self, index_url: str, output_name: str = None,
                      num_chapters: int = None, audio_batch_size: int = None,
                      start_chapter: int = None, end_chapter: int = None) -> dict:
        """Process a book from its index page: scrape chapters, create EPUBs, then batch audio.

        Args:
            index_url: URL of the book's chapter-list / index page.
            output_name: Base name for output files.  Defaults to epub_title from config.
            num_chapters: How many chapters to process starting from start_chapter.
                          When *None* the user is prompted interactively.
            audio_batch_size: How many chapters to combine into each audio file.
                              When *None* the user is prompted interactively.
            start_chapter: Starting chapter number (1-based, inclusive).
            end_chapter: Ending chapter number (1-based, inclusive).
                         Use 0 or None to process through the last available chapter.

        Returns:
            dict with keys ``chapters``, ``epub_files``, and ``audio_files``.
        """
        output_name = output_name or self.config.epub_title

        print("\n" + "="*60)
        print("📚 BATCH BOOK PROCESSOR")
        print("="*60)

        # ── Step 1: Fetch chapter list from index page ───────────────────────
        print(f"\n🔍 Fetching chapter list from: {index_url}")
        logging.info(f"Fetching chapter list from: {index_url}")
        all_chapter_urls = self.scraper.scrape_index_page(index_url)

        if not all_chapter_urls:
            raise ValueError(
                "No chapter URLs were found on the index page. "
                "Check the URL and make sure it is the book's table-of-contents page."
            )

        total_available = len(all_chapter_urls)
        print(f"\n✅ Found {total_available} chapters on the index page")
        logging.info(f"Found {total_available} chapters")

        # ── Step 2: Select chapter range ─────────────────────────────────────
        if start_chapter is None:
            start_chapter = self.config.start_chapter if self.config.start_chapter > 0 else 1
        if end_chapter is None:
            end_chapter = self.config.end_chapter

        if start_chapter < 1:
            raise ValueError("start_chapter must be >= 1.")

        selected_end = end_chapter if end_chapter and end_chapter > 0 else total_available
        selected_end = min(selected_end, total_available)

        if selected_end < start_chapter:
            raise ValueError(
                f"Invalid chapter range: start_chapter={start_chapter}, end_chapter={selected_end}."
            )

        selected_urls = all_chapter_urls[start_chapter - 1:selected_end]
        selectable_total = len(selected_urls)
        if selectable_total < 1:
            raise ValueError("Selected chapter range contains no chapters.")

        # ── Step 3: Ask how many chapters to process from selected range ─────
        if num_chapters is None:
            while True:
                try:
                    raw = input(
                        f"\nProcess how many chapters? (1-{selectable_total}, or 0 for all): "
                    ).strip()
                    n = int(raw)
                    if n == 0:
                        n = selectable_total
                    if 1 <= n <= selectable_total:
                        break
                    print(f"  Please enter a number between 1 and {selectable_total}.")
                except ValueError:
                    print("  Please enter a valid integer.")
            num_chapters = n

        if not (1 <= num_chapters <= selectable_total):
            raise ValueError(
                f"num_chapters={num_chapters} is out of range 1-{selectable_total}."
            )

        chapter_urls = selected_urls[:num_chapters]
        range_end = start_chapter + num_chapters - 1
        print(f"\n📖 Will process chapters {start_chapter} to {range_end} ({num_chapters} total)")
        logging.info(f"Processing chapters {start_chapter}-{range_end} ({num_chapters} chapters)")

        # ── Step 4: Ask for audio batch size ─────────────────────────────────
        if audio_batch_size is None:
            while True:
                try:
                    raw = input(
                        f"\nHow many chapters per audio batch? (1-{num_chapters}): "
                    ).strip()
                    b = int(raw)
                    if 1 <= b <= num_chapters:
                        break
                    print(f"  Please enter a number between 1 and {num_chapters}.")
                except ValueError:
                    print("  Please enter a valid integer.")
            audio_batch_size = b

        num_batches = (num_chapters + audio_batch_size - 1) // audio_batch_size
        print(
            f"\n🎵 Audio will be split into {num_batches} batch(es) "
            f"of up to {audio_batch_size} chapter(s) each"
        )
        logging.info(f"Audio batch size: {audio_batch_size} ({num_batches} batches)")

        # ── Step 5: Scrape all chapters ───────────────────────────────────────
        total_steps = 2 + num_batches  # scrape + EPUBs + N audio batches
        print(f"\n📥 Step 1/{total_steps}: Scraping {num_chapters} chapters...")
        logging.info(f"Scraping {num_chapters} chapters")
        chapters = self.scraper.scrape_chapters(chapter_urls)

        if not chapters:
            raise ValueError("No chapters were successfully scraped.")

        chapters_with_content = [ch for ch in chapters if ch.get('content', '').strip()]
        if not chapters_with_content:
            raise ValueError("All scraped chapters are empty.")

        if len(chapters_with_content) < len(chapters):
            empty = len(chapters) - len(chapters_with_content)
            logging.warning(f"{empty} chapters had no content and will be skipped")
            print(f"⚠️  {empty} chapter(s) had no content and will be skipped")
            chapters = chapters_with_content

        # Preview before committing to processing
        if not self._preview_chapters(chapters):
            print("\n❌ Batch processing cancelled by user")
            logging.info("User cancelled batch processing after preview")
            return {'status': 'cancelled', 'message': 'User cancelled after preview'}

        # ── Step 6: Create individual EPUB per chapter ───────────────────────
        print(f"\n📄 Step 2/{total_steps}: Creating {len(chapters)} EPUBs...")
        logging.info(f"Creating {len(chapters)} individual EPUBs")
        epub_paths: List[str] = []

        for i, chapter in enumerate(chapters, 1):
            chapter_name = f"{output_name}_chapter_{i:03d}"
            epub_path = self.ebook_gen.create_epub(
                [chapter],
                chapter_name,
                self.config.epub_author
            )
            epub_paths.append(str(epub_path))
            print(f"  ✓ Chapter {i}: {epub_path}")
            logging.debug(f"EPUB created: {epub_path}")

        # ── Step 7: Generate audio files in batches ──────────────────────────
        print(
            f"\n🔊 Steps 3-{total_steps}/{total_steps}: "
            f"Generating audio in {num_batches} batch(es)..."
        )
        logging.info(f"Starting audio generation: {num_batches} batches")
        audio_chapters = self._prepare_chapters_for_audio(chapters)

        kwargs = {
            'voice': self.config.kokoro_voice,
            'lang_code': self.config.kokoro_lang_code,
            'speed': self.config.kokoro_speed,
        }

        audio_files: List[str] = []
        batches = [
            audio_chapters[i:i + audio_batch_size]
            for i in range(0, len(audio_chapters), audio_batch_size)
        ]

        for batch_num, batch in enumerate(batches, 1):
            batch_start = (batch_num - 1) * audio_batch_size + 1
            batch_end = batch_start + len(batch) - 1
            batch_filename = (
                f"{output_name}_audio_batch_{batch_num:03d}"
                f"_ch{batch_start:03d}-{batch_end:03d}.wav"
            )

            print(
                f"\n  🎵 Batch {batch_num}/{num_batches}: "
                f"chapters {batch_start}-{batch_end}"
            )
            logging.info(
                f"Audio batch {batch_num}/{num_batches}: "
                f"chapters {batch_start}-{batch_end}"
            )

            combined_text = '\n\n'.join(ch['content'] for ch in batch)
            if self.config.max_duration > 0:
                combined_text = self._apply_duration_limit(
                    combined_text, self.config.max_duration
                )

            audio_path = self.tts.generate_audio(combined_text, batch_filename, **kwargs)
            audio_files.append(str(audio_path))
            print(f"  ✓ Batch {batch_num}: {audio_path}")
            logging.info(f"Audio batch {batch_num} complete: {audio_path}")

        # ── Summary ──────────────────────────────────────────────────────────
        print("\n" + "="*60)
        print("✅ Batch processing complete!")
        print(f"   Chapters processed : {len(chapters)}")
        print(f"   EPUBs created      : {len(epub_paths)}")
        print(f"   Audio batches      : {len(audio_files)}")
        print("="*60 + "\n")
        logging.info(
            f"Batch processing complete: {len(chapters)} chapters, "
            f"{len(epub_paths)} EPUBs, {len(audio_files)} audio files"
        )

        return {
            'status': 'complete',
            'chapters': len(chapters),
            'epub_files': epub_paths,
            'audio_files': audio_files,
        }

    def _apply_duration_limit(self, text: str, max_minutes: int) -> str:
        """Limit text based on estimated audio duration"""
        logging.debug(f"Applying duration limit: max_minutes={max_minutes}")
        # Estimate: average reading speed is ~150 words per minute
        # Speech rate from config affects this
        words_per_minute = self.config.speech_rate if hasattr(self.config, 'speech_rate') else 150
        max_words = max_minutes * words_per_minute
        logging.debug(f"Words per minute: {words_per_minute}, max words: {max_words}")

        words = text.split()
        logging.debug(f"Original word count: {len(words)}")
        if len(words) <= max_words:
            logging.debug("Text is within duration limit, no trimming needed")
            return text

        logging.debug(f"Trimming from {len(words)} to {max_words} words")
        print(f"⚠️  Duration limit applied: Trimming to ~{max_minutes} minutes ({max_words} words)")
        return ' '.join(words[:max_words])

    def _preview_chapters(self, chapters: list, max_preview: int = 3) -> bool:
        """Preview first N chapters for user verification.

        Args:
            chapters: List of chapter dictionaries
            max_preview: Maximum number of chapters to preview (default: 3)

        Returns:
            True if user wants to continue, False to cancel
        """
        logging.info("Starting chapter preview")
        print("\n" + "="*60)
        print("📖 CHAPTER PREVIEW")
        print("="*60)
        print(f"\nShowing preview of first {min(max_preview, len(chapters))} chapters")
        print("Please verify that the text was scraped correctly.\n")

        # Preview up to max_preview chapters
        preview_count = min(max_preview, len(chapters))

        for i in range(preview_count):
            chapter = chapters[i]
            title = chapter.get('title', f'Chapter {i+1}')
            content = chapter.get('content', '')

            print(f"\n{'─'*60}")
            print(f"📄 Chapter {i+1}: {title}")
            print(f"{'─'*60}")

            # Show first 500 characters of content
            preview_text = content[:500] if len(content) > 500 else content
            word_count = len(content.split())

            print(preview_text)
            if len(content) > 500:
                print(f"\n... (showing first 500 of {len(content)} characters)")

            print(f"\n📊 Statistics: {word_count} words, {len(content)} characters")

        print(f"\n{'='*60}")
        print(f"Total chapters to process: {len(chapters)}")
        print(f"{'='*60}\n")

        # Ask user to confirm
        while True:
            response = input("Continue with EPUB and audio generation? [Y/n/r(review more)]: ").strip().lower()

            if response in ['', 'y', 'yes']:
                logging.info("User confirmed to continue after preview")
                return True
            elif response in ['n', 'no']:
                logging.info("User chose to cancel after preview")
                return False
            elif response in ['r', 'review']:
                # Show more chapters
                print("\n" + "="*60)
                print("📖 EXTENDED PREVIEW")
                print("="*60)

                start_idx = preview_count
                end_idx = min(start_idx + 3, len(chapters))

                if start_idx >= len(chapters):
                    print(f"\nNo more chapters to preview (total: {len(chapters)})")
                    continue

                print(f"\nShowing chapters {start_idx+1} to {end_idx}")

                for i in range(start_idx, end_idx):
                    chapter = chapters[i]
                    title = chapter.get('title', f'Chapter {i+1}')
                    content = chapter.get('content', '')

                    print(f"\n{'─'*60}")
                    print(f"📄 Chapter {i+1}: {title}")
                    print(f"{'─'*60}")

                    preview_text = content[:500] if len(content) > 500 else content
                    word_count = len(content.split())

                    print(preview_text)
                    if len(content) > 500:
                        print(f"\n... (showing first 500 of {len(content)} characters)")

                    print(f"\n📊 Statistics: {word_count} words, {len(content)} characters")

                preview_count = end_idx
            else:
                print("Please enter 'y' (yes), 'n' (no), or 'r' (review more)")



if __name__ == '__main__':
    # Example usage - Method 1: Direct configuration
    config = Config(
        kokoro_voice='af_heart',
        kokoro_lang_code='a',
        kokoro_speed=1.0,
        epub_title='My Web Book',
        epub_author='Web Scraper',
        max_chapters=0,  # 0 = no limit
        max_duration=0   # 0 = no limit (minutes)
    )

    # Example usage - Method 2: Load from YAML (recommended)
    # config = Config.from_yaml('config.yaml')

    app = WebToEbookApp(config)

    # Example URLs
    urls = [
        'https://example.com/chapter1',
        'https://example.com/chapter2',
    ]

    # Process
    result = app.process(urls, output_name='My Book')

    # Tip: Run voice_preview.py first to choose your preferred voice!
    # python voice_preview.py
