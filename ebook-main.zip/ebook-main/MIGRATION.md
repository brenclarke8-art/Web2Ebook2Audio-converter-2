# Migration: Portable Zip Release Model

## What changed

The Windows release pipeline has been simplified.  The old custom installer
(`WebToEbookInstaller.exe`) is no longer the primary release artifact.  Starting
with this change, every GitHub release publishes a portable zip that users
extract and run directly.

### Before

| Aspect | Old approach |
|---|---|
| Artifact | `WebToEbookInstaller.exe` – a bootstrap installer |
| Build runner | Self-hosted Windows runner (often unavailable) |
| Python discovery | Custom PowerShell environment resolution |
| Binary commit-back | Installer exe committed to the repo on each build |
| Release dependency | Release step required the committed exe to be present at the tag |
| Build methods | PyInstaller bootstrap **or** Nuitka (selectable) |
| Workflow | `.github/workflows/build_installer.yml` |

### After

| Aspect | New approach |
|---|---|
| Artifact | `ebook-windows-x64-v<version>.zip` – portable bundle |
| Build runner | `windows-latest` (GitHub-hosted, always available) |
| Python setup | `actions/setup-python@v5` (reliable, reproducible) |
| Binary commit-back | None – the zip is built fresh on every release |
| Release dependency | None – the workflow builds and uploads in one step |
| Build method | PyInstaller one-folder bundle only |
| Workflow | `.github/workflows/release-windows.yml` |

## Why

The old `build_installer.yml` workflow was failing ([run 26411604377](https://github.com/brenclarke8-art/ebook/actions/runs/26411604377)) due to a PowerShell syntax error in the custom Python resolution step.  Beyond this specific failure the design had several reliability problems:

1. **Self-hosted runner dependency** – if the Windows machine was offline or
   misconfigured, no release asset could be produced.
2. **Binary commit-back** – building required a git push back to `main`, which
   added noise to the history and created ordering dependencies between the build
   run and the release publication.
3. **Two-phase release** – the release upload job depended on the installer exe
   being committed at the exact tag, so a release could publish with no asset
   attached if the build job had not run recently.
4. **Multiple code paths** – selectable PyInstaller / Nuitka methods added
   complexity and maintenance surface with no benefit for the common case.

## How to release

1. Create and push a tag (e.g. `git tag v1.2.3 && git push origin v1.2.3`).
2. Publish a GitHub release from that tag.
3. The `Release Windows Portable Bundle` workflow runs automatically on
   `windows-latest`, builds the portable zip with PyInstaller, and attaches it
   to the release as `ebook-windows-x64-v1.2.3.zip`.

That is the complete release process.

## User install instructions

1. Download `ebook-windows-x64-v<version>.zip` from the
   [Releases page](https://github.com/brenclarke8-art/ebook/releases/latest).
2. Extract the zip to any folder.
3. Run `app.exe`.

## Deprecated files

The following files are **no longer part of the main release path** but are
kept in the repository to avoid breaking the source-install path (which still
uses `installer.py`) and for historical reference:

| File | Status |
|---|---|
| `.github/workflows/build_installer.yml` | Deprecated – dispatch-only, marked `[DEPRECATED]` in its name |
| `build_windows_installer.py` | Deprecated – used by the old bootstrap build |
| `build_pyinstaller_bootstrap.py` | Deprecated – builds the bootstrap installer exe |
| `installer.py` | Still used for source installs on Linux/macOS/Windows |
| `installer.spec` | Deprecated – PyInstaller spec for the bootstrap installer |
| `launcher.py` / `launcher.spec` | Deprecated – launcher for the old installed layout |
| `windows_installer.iss` | Deprecated – Inno Setup script (Nuitka path only) |
| `build_nuitka.py` | Deprecated – Nuitka-based build script |

These files may be removed in a future cleanup PR once it is confirmed that no
users rely on the bootstrap installer path.

## New files

| File | Purpose |
|---|---|
| `.github/workflows/release-windows.yml` | New main release workflow |
| `app.spec` | PyInstaller one-folder spec for the portable bundle |
