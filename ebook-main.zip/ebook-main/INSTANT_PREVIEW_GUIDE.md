# Instant Preview and Feedback Features

## Overview

This document describes the new instant preview and progress feedback features added to the Web to Ebook Converter application.

## Features

### 1. Instant Preview for Voice & Speed Settings

**Location:** Main Converter Tab → Kokoro TTS Settings → "⚡ Test Voice & Speed (Instant Preview)" button

**Purpose:** Allows users to quickly test their selected voice and speed settings before starting a full conversion.

**How it works:**
1. Select your desired voice from the dropdown
2. Adjust the speed slider (0.5 - 2.0)
3. Optionally adjust the speech rate (100-250 WPM)
4. Click the "⚡ Test Voice & Speed (Instant Preview)" button
5. A short audio sample will be generated with your current settings
6. The preview file is saved to `output/preview/` directory

**Benefits:**
- No need to process an entire book to test settings
- Quick feedback on voice quality and speaking speed
- Helps users find their ideal configuration before conversion
- Preview files are small and generate quickly

**Sample preview text:**
> "This is a preview of the selected voice at the current speed setting. Listen carefully to determine if this suits your needs."

### 2. Detailed Progress Feedback During Conversion

**Location:** Main Converter Tab → Progress section

**Purpose:** Provides real-time updates on the conversion process so users know exactly what's happening.

**Progress tracking includes:**
- **Progress bar:** Visual indicator showing percentage complete
- **Status updates:** Detailed text showing current step and operation
- **Step breakdown:**
  - Step 1/4: Scraping web pages
  - Step 2/4: Translating content (if enabled)
  - Step 3/4: Creating EPUB
  - Step 4/4: Generating audio
    - Loading TTS model (first time only)
    - Generating audio...
    - Processing segment X...
    - Saving audio file...
    - Audio generation complete

**For multi-chapter conversions:**
- Shows "Generating audio for chapter X/Y"
- Updates in real-time as each chapter is processed
- Provides feedback on combined audio creation

**Benefits:**
- Users know the conversion is progressing (not frozen)
- Can estimate remaining time based on current step
- Understand what operation is taking the longest
- Get immediate feedback if something goes wrong

## Technical Implementation

### TTS Engine Changes (`tts_engine.py`)

1. **New method:** `generate_preview(voice, lang_code, speed)`
   - Generates a quick preview audio sample
   - Uses standard preview text
   - Returns path to generated audio file

2. **Enhanced:** `generate_audio()` and `_generate_kokoro()`
   - Added optional `progress_callback` parameter
   - Calls callback at key points in the generation process
   - Provides detailed status messages during operation

### GUI Changes (`gui.py`)

1. **New button:** "⚡ Test Voice & Speed (Instant Preview)"
   - Positioned prominently in TTS settings
   - Generates preview in background thread
   - Shows success/failure message with file location

2. **Enhanced progress tracking:**
   - Changed progress bar from indeterminate to determinate mode
   - Shows 0-100% completion
   - Status bar updates with step-by-step progress

3. **New method:** `_process_with_progress()`
   - Wraps the conversion process with progress tracking
   - Updates UI in real-time via `root.after()`
   - Thread-safe updates to status and progress

4. **New methods for preview:**
   - `instant_preview()`: Initiates preview generation
   - `instant_preview_complete()`: Handles successful preview
   - `instant_preview_failed()`: Handles preview errors

## Usage Examples

### Quick Preview Workflow

1. Open the GUI application
2. Go to "Kokoro TTS Settings"
3. Select voice: "af_heart"
4. Set speed: 1.2
5. Click "⚡ Test Voice & Speed (Instant Preview)"
6. Wait ~10-30 seconds (first time may take longer for model loading)
7. Play the generated preview file
8. Adjust settings if needed and preview again
9. Once satisfied, proceed with full conversion

### Monitoring Conversion Progress

1. Start a conversion with "Start Conversion" button
2. Watch the progress bar fill from 0% to 100%
3. Read detailed status updates in the status bar
4. See log messages in the scrollable text area
5. Wait for "Conversion complete!" message

## Configuration

No additional configuration is required. The features work with your existing settings in `config.yaml` or GUI settings.

## Troubleshooting

### Preview Generation Fails

**Problem:** Preview button shows an error message

**Solutions:**
1. Ensure Kokoro TTS dependencies are installed
2. Check that espeak-ng is installed on your system
3. Verify output directory permissions
4. Check log messages for detailed error information

### Progress Bar Not Updating

**Problem:** Progress bar stays at 0% during conversion

**Solutions:**
1. Check that the conversion is actually running (logs should update)
2. For very fast conversions, progress may complete quickly
3. Ensure GUI is responsive (not frozen)

### Preview Files Accumulate

**Problem:** Many preview files in output/preview/ directory

**Note:** This is normal behavior. Preview files are small and named with the voice and speed, so you can compare different settings. You can safely delete old preview files.

## API Usage (Programmatic)

### Generating Previews in Code

```python
from tts_engine import TTSEngine

tts = TTSEngine(output_dir='output/preview')

# Generate preview
preview_path = tts.generate_preview(
    voice='af_heart',
    lang_code='a',
    speed=1.2
)

print(f"Preview saved to: {preview_path}")
```

### Using Progress Callbacks

```python
def progress_callback(message):
    print(f"Progress: {message}")

tts.generate_audio(
    text="Your text here",
    output_filename="output.wav",
    voice='af_heart',
    lang_code='a',
    speed=1.0,
    progress_callback=progress_callback
)
```

## Performance Notes

- **First preview:** May take 30-60 seconds (model loading)
- **Subsequent previews:** ~5-15 seconds
- **Preview file size:** ~200-500 KB
- **Memory usage:** Same as normal TTS operation
- **Thread safety:** All GUI updates are thread-safe via `root.after()`

## Future Enhancements

Potential improvements for future versions:
- Auto-play preview in GUI
- Compare multiple voices side-by-side
- Preview with custom text input
- Save preferred voice/speed as default
- Cancel preview generation mid-process
- Show estimated time remaining during conversion

## Feedback

If you encounter any issues or have suggestions for improving these features, please open an issue on the GitHub repository.
