"""
Synchronized Text Generator for Audio Playback
Generates HTML page with text synchronized to audio playback with word/sentence highlighting
"""

import re
import logging
import html
from pathlib import Path
from typing import List, Dict, Tuple

logger = logging.getLogger(__name__)


class SyncTextGenerator:
    """Generate synchronized text display for audio playback"""

    def __init__(self, output_dir: str = 'output'):
        logger.debug(f"Initializing SyncTextGenerator with output_dir='{output_dir}'")
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        logger.debug(f"Output directory created/verified: {self.output_dir}")

    def estimate_timings(self, text: str, speech_rate: int = 150) -> Tuple[List[Dict], List[Dict]]:
        """
        Estimate word and sentence timings based on speech rate.

        Args:
            text: The full text content
            speech_rate: Words per minute (default 150)

        Returns:
            Tuple of (word_timings, sentence_timings)
        """
        logger.debug(f"Estimating timings for text: {len(text)} characters, speech_rate={speech_rate} WPM")

        # Split into sentences
        logger.debug("Splitting text into sentences")
        sentences = re.split(r'(?<=[.!?])\s+', text.strip())
        logger.debug(f"Split into {len(sentences)} sentences")

        # Calculate timings
        words_per_second = speech_rate / 60.0
        logger.debug(f"Words per second: {words_per_second:.2f}")
        current_time = 0.0

        word_timings = []
        sentence_timings = []

        for sent_idx, sentence in enumerate(sentences):
            if not sentence.strip():
                continue

            sentence_start = current_time

            # Split sentence into words
            words = re.findall(r'\b\w+\b|[^\w\s]', sentence)

            for word_idx, word in enumerate(words):
                if not word.strip():
                    continue

                # Estimate word duration (average word takes 1/words_per_second seconds)
                # Add slight pause for punctuation
                if word in '.!?,;:':
                    word_duration = 0.3
                else:
                    word_duration = 1.0 / words_per_second

                word_timings.append({
                    'word': word,
                    'start': current_time,
                    'end': current_time + word_duration,
                    'sentence_idx': sent_idx
                })

                current_time += word_duration

            sentence_timings.append({
                'sentence': sentence,
                'start': sentence_start,
                'end': current_time,
                'sentence_idx': sent_idx
            })

            # Add small pause between sentences
            current_time += 0.2

        logger.debug(f"Timing estimation complete: {len(word_timings)} words, {len(sentence_timings)} sentences, total_duration={current_time:.2f}s")
        return word_timings, sentence_timings

    def generate_html(self, text: str, audio_filename: str, output_filename: str,
                     title: str = "Audiobook with Synchronized Text",
                     speech_rate: int = 150) -> Path:
        """
        Generate HTML file with synchronized text display.

        Args:
            text: The full text content
            audio_filename: Name of the audio file
            output_filename: Name for the HTML output file
            title: Title for the HTML page
            speech_rate: Words per minute for timing estimation

        Returns:
            Path to the generated HTML file
        """
        logger.debug(f"Starting HTML generation: output_filename='{output_filename}', title='{title}'")
        logger.debug(f"Text length: {len(text)} characters, audio: '{audio_filename}', speech_rate={speech_rate}")

        logger.debug("Estimating word and sentence timings")
        word_timings, sentence_timings = self.estimate_timings(text, speech_rate)
        logger.debug(f"Timings calculated: {len(word_timings)} words, {len(sentence_timings)} sentences")

        # Generate HTML with embedded JavaScript for synchronization
        logger.debug("Generating HTML template")
        html_content = self._generate_html_template(
            text, audio_filename, title, word_timings, sentence_timings
        )
        logger.debug(f"HTML template generated: {len(html_content)} characters")

        output_path = self.output_dir / output_filename
        logger.debug(f"Writing HTML to: {output_path}")
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        logger.debug("HTML file written successfully")

        print(f"✓ Generated synchronized text: {output_path}")
        return output_path

    def generate_chapter_html(self, chapter_info: List[Dict], output_filename: str,
                             title: str = "Audiobook with Chapter Navigation",
                             speech_rate: int = 150) -> Path:
        """
        Generate HTML file with chapter-based synchronized text display.

        Args:
            chapter_info: List of dicts with 'number', 'title', 'audio', 'text' keys
            output_filename: Name for the HTML output file
            title: Title for the HTML page
            speech_rate: Words per minute for timing estimation

        Returns:
            Path to the generated HTML file
        """
        logger.debug(f"Starting chapter HTML generation: output_filename='{output_filename}', title='{title}'")
        logger.debug(f"Processing {len(chapter_info)} chapters, speech_rate={speech_rate}")

        # Generate HTML with chapter navigation
        logger.debug("Generating chapter-based HTML template")
        html_content = self._generate_chapter_html_template(
            chapter_info, title, speech_rate
        )
        logger.debug(f"Chapter HTML template generated: {len(html_content)} characters")

        output_path = self.output_dir / output_filename
        logger.debug(f"Writing chapter HTML to: {output_path}")
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        logger.debug("Chapter HTML file written successfully")

        print(f"✓ Generated chapter-based synchronized text: {output_path}")
        return output_path

    @staticmethod
    def _speaker_css_class(speaker: str) -> str:
        """Convert speaker name to a safe CSS class token."""
        safe = re.sub(r'[^a-zA-Z0-9]+', '-', (speaker or 'narrator').strip().lower())
        safe = safe.strip('-') or 'narrator'
        return f"speaker-{safe}"

    def generate_character_dialogue_preview(
        self,
        dialogue_segments: List,
        character_checklist: List[Dict],
        output_filename: str,
        title: str = "Character Dialogue Preview",
    ) -> Path:
        """Generate a color-coded dialogue preview HTML with a character glossary."""
        palette = [
            "#f8bbd0", "#bbdefb", "#c8e6c9", "#ffe0b2", "#d1c4e9",
            "#b2dfdb", "#fff9c4", "#ffccbc", "#c5cae9", "#dcedc8"
        ]

        # Ensure all speakers in segments appear in glossary/color mapping
        checklist_by_name = {entry["name"]: entry for entry in character_checklist}
        speakers_in_dialogue = set()
        for segment in dialogue_segments:
            if getattr(segment, "is_dialogue", False):
                speakers_in_dialogue.add(getattr(segment, "speaker", "narrator") or "narrator")

        for speaker in sorted(speakers_in_dialogue):
            if speaker not in checklist_by_name:
                checklist_by_name[speaker] = {
                    "name": speaker,
                    "gender": "n/a" if speaker == "narrator" else "unknown",
                    "dialogue_count": 0,
                    "mention_count": 0,
                }

        ordered_entries = sorted(
            checklist_by_name.values(),
            key=lambda e: (e.get("dialogue_count", 0), e.get("mention_count", 0), e.get("name", "")),
            reverse=True,
        )

        colors = {"narrator": "#e0e0e0"}
        color_idx = 0
        for entry in ordered_entries:
            name = entry["name"]
            if name == "narrator":
                continue
            colors[name] = palette[color_idx % len(palette)]
            color_idx += 1

        glossary_rows = []
        if ordered_entries:
            for entry in ordered_entries:
                name = entry["name"]
                gender = entry.get("gender", "unknown")
                dialogue_count = entry.get("dialogue_count", 0)
                mention_count = entry.get("mention_count", 0)
                css_class = self._speaker_css_class(name)
                glossary_rows.append(
                    f'<tr class="glossary-row {css_class}">'
                    f'<td><span class="swatch" style="background:{colors.get(name, "#eeeeee")}"></span>{html.escape(name)}</td>'
                    f'<td>{html.escape(str(gender))}</td>'
                    f'<td>{dialogue_count}</td>'
                    f'<td>{mention_count}</td>'
                    f'</tr>'
                )
        else:
            glossary_rows.append('<tr><td colspan="4">No characters were identified.</td></tr>')

        text_blocks = []
        for segment in dialogue_segments:
            speaker = getattr(segment, "speaker", "narrator") or "narrator"
            speaker_label = f'<span class="speaker-label">{html.escape(speaker)}:</span> ' if getattr(segment, "is_dialogue", False) else ""
            css_class = self._speaker_css_class(speaker)
            color = colors.get(speaker, "#f5f5f5")
            content = html.escape(getattr(segment, "text", "")).replace("\n", "<br>")
            segment_type = "dialogue" if getattr(segment, "is_dialogue", False) else "narration"
            text_blocks.append(
                f'<p class="segment {segment_type} {css_class}" style="background:{color};">{speaker_label}{content}</p>'
            )

        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{html.escape(title)}</title>
    <style>
        body {{
            font-family: Georgia, serif;
            margin: 0;
            background: #f5f5f5;
            color: #2c3e50;
        }}
        .container {{
            max-width: 1100px;
            margin: 0 auto;
            padding: 20px;
        }}
        .panel {{
            background: #fff;
            border-radius: 8px;
            padding: 18px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            margin-bottom: 16px;
        }}
        h1 {{
            margin-top: 0;
        }}
        .glossary {{
            width: 100%;
            border-collapse: collapse;
        }}
        .glossary th, .glossary td {{
            border-bottom: 1px solid #e0e0e0;
            padding: 8px;
            text-align: left;
        }}
        .swatch {{
            display: inline-block;
            width: 14px;
            height: 14px;
            border: 1px solid #999;
            border-radius: 3px;
            margin-right: 8px;
            vertical-align: middle;
        }}
        .segment {{
            margin: 0 0 10px 0;
            padding: 10px;
            border-radius: 6px;
            line-height: 1.7;
            border-left: 4px solid rgba(0,0,0,0.15);
        }}
        .segment.dialogue {{
            font-style: italic;
        }}
        .speaker-label {{
            font-weight: bold;
            font-style: normal;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="panel">
            <h1>{html.escape(title)}</h1>
            <p>Color-coded dialogue preview with character glossary.</p>
        </div>
        <div class="panel">
            <h2>Character Glossary</h2>
            <table class="glossary">
                <thead>
                    <tr><th>Character</th><th>Gender</th><th>Dialogue Segments</th><th>Mentions</th></tr>
                </thead>
                <tbody>
                    {''.join(glossary_rows)}
                </tbody>
            </table>
        </div>
        <div class="panel">
            <h2>Text Preview</h2>
            {''.join(text_blocks) if text_blocks else '<p>No text available for preview.</p>'}
        </div>
    </div>
</body>
</html>"""

        output_path = self.output_dir / output_filename
        with open(output_path, "w", encoding="utf-8") as handle:
            handle.write(html_content)

        print(f"✓ Generated character dialogue preview: {output_path}")
        return output_path

    def _generate_html_template(self, text: str, audio_filename: str, title: str,
                                word_timings: List[Dict], sentence_timings: List[Dict]) -> str:
        """Generate the HTML template with embedded data and JavaScript"""

        # Split text into sentences for display
        sentences = re.split(r'(?<=[.!?])\s+', text.strip())

        # Build HTML structure with word spans
        text_html = ""
        word_idx = 0

        for sent_idx, sentence in enumerate(sentences):
            if not sentence.strip():
                continue

            text_html += f'<p class="sentence" data-sentence-idx="{sent_idx}">'

            # Split sentence into words
            words = re.findall(r'\b\w+\b|[^\w\s]', sentence)

            for word in words:
                if not word.strip():
                    continue

                if word_idx < len(word_timings):
                    timing = word_timings[word_idx]
                    text_html += f'<span class="word" data-word-idx="{word_idx}" data-start="{timing["start"]:.2f}" data-end="{timing["end"]:.2f}">{word}</span>'
                    if word not in '.!?,;:':
                        text_html += ' '
                    word_idx += 1

            text_html += '</p>\n'

        # Convert timings to JSON for JavaScript
        import json
        word_timings_json = json.dumps(word_timings)
        sentence_timings_json = json.dumps(sentence_timings)

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: 'Georgia', serif;
            line-height: 1.8;
            color: #333;
            background: #f5f5f5;
        }}

        .container {{
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }}

        header {{
            background: #2c3e50;
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 8px 8px 0 0;
        }}

        h1 {{
            font-size: 2em;
            margin-bottom: 10px;
        }}

        .controls {{
            background: white;
            padding: 20px;
            border-left: 4px solid #3498db;
            border-right: 4px solid #3498db;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}

        .audio-player {{
            width: 100%;
            margin-bottom: 15px;
        }}

        .options {{
            display: flex;
            gap: 20px;
            align-items: center;
            flex-wrap: wrap;
        }}

        .option-group {{
            display: flex;
            align-items: center;
            gap: 10px;
        }}

        label {{
            font-weight: bold;
            color: #555;
        }}

        input[type="radio"] {{
            cursor: pointer;
        }}

        .text-display {{
            background: white;
            padding: 30px;
            border-radius: 0 0 8px 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-left: 4px solid #3498db;
            border-right: 4px solid #3498db;
            border-bottom: 4px solid #3498db;
            min-height: 400px;
        }}

        .sentence {{
            margin-bottom: 1em;
            transition: background-color 0.3s ease;
        }}

        .word {{
            transition: background-color 0.2s ease, color 0.2s ease;
            padding: 2px 1px;
        }}

        /* Sentence highlighting */
        .sentence.highlight-sentence {{
            background-color: #fff9c4;
            padding: 5px;
            border-radius: 4px;
        }}

        /* Word highlighting */
        .word.highlight-word {{
            background-color: #ffeb3b;
            color: #000;
            font-weight: bold;
            padding: 2px 4px;
            border-radius: 3px;
        }}

        .instructions {{
            background: #e3f2fd;
            padding: 15px;
            border-radius: 6px;
            margin-top: 20px;
            border-left: 4px solid #2196f3;
        }}

        .instructions h3 {{
            color: #1976d2;
            margin-bottom: 10px;
        }}

        .instructions ul {{
            margin-left: 20px;
        }}

        .instructions li {{
            margin: 5px 0;
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 10px;
            }}

            .text-display {{
                padding: 15px;
            }}

            h1 {{
                font-size: 1.5em;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>{title}</h1>
            <p>Read along with synchronized text highlighting</p>
        </header>

        <div class="controls">
            <audio class="audio-player" controls id="audioPlayer">
                <source src="{audio_filename}" type="audio/wav">
                Your browser does not support the audio element.
            </audio>

            <div class="options">
                <div class="option-group">
                    <label>Highlight Mode:</label>
                    <input type="radio" id="modeWord" name="highlightMode" value="word" checked>
                    <label for="modeWord">Word</label>
                    <input type="radio" id="modeSentence" name="highlightMode" value="sentence">
                    <label for="modeSentence">Sentence</label>
                    <input type="radio" id="modeOff" name="highlightMode" value="off">
                    <label for="modeOff">Off</label>
                </div>
            </div>
        </div>

        <div class="text-display" id="textDisplay">
{text_html}
        </div>

        <div class="instructions">
            <h3>Instructions</h3>
            <ul>
                <li><strong>Play/Pause:</strong> Use the audio controls above to play or pause the narration</li>
                <li><strong>Word Mode:</strong> Highlights the current word being spoken (default)</li>
                <li><strong>Sentence Mode:</strong> Highlights the current sentence being spoken</li>
                <li><strong>Off Mode:</strong> Disables highlighting for distraction-free reading</li>
                <li><strong>Tip:</strong> The text will automatically scroll to keep the current position in view</li>
            </ul>
        </div>
    </div>

    <script>
        // Timing data
        const wordTimings = {word_timings_json};
        const sentenceTimings = {sentence_timings_json};

        // DOM elements
        const audioPlayer = document.getElementById('audioPlayer');
        const textDisplay = document.getElementById('textDisplay');
        const modeRadios = document.getElementsByName('highlightMode');

        // State
        let highlightMode = 'word';
        let currentWordIdx = -1;
        let currentSentenceIdx = -1;

        // Update highlight mode when radio buttons change
        modeRadios.forEach(radio => {{
            radio.addEventListener('change', (e) => {{
                highlightMode = e.target.value;
                clearHighlights();
            }});
        }});

        // Update highlights as audio plays
        audioPlayer.addEventListener('timeupdate', () => {{
            const currentTime = audioPlayer.currentTime;

            if (highlightMode === 'off') {{
                clearHighlights();
                return;
            }}

            if (highlightMode === 'word') {{
                updateWordHighlight(currentTime);
            }} else if (highlightMode === 'sentence') {{
                updateSentenceHighlight(currentTime);
            }}
        }});

        // Clear highlights when audio is paused or ends
        audioPlayer.addEventListener('pause', () => {{
            if (highlightMode !== 'off') {{
                // Keep highlights when paused
            }}
        }});

        audioPlayer.addEventListener('ended', () => {{
            clearHighlights();
        }});

        function updateWordHighlight(currentTime) {{
            // Find the current word based on time
            let foundIdx = -1;
            for (let i = 0; i < wordTimings.length; i++) {{
                if (currentTime >= wordTimings[i].start && currentTime < wordTimings[i].end) {{
                    foundIdx = i;
                    break;
                }}
            }}

            if (foundIdx !== currentWordIdx) {{
                // Remove previous highlight
                if (currentWordIdx >= 0) {{
                    const prevWord = document.querySelector(`.word[data-word-idx="${{currentWordIdx}}"]`);
                    if (prevWord) {{
                        prevWord.classList.remove('highlight-word');
                    }}
                }}

                // Add new highlight
                currentWordIdx = foundIdx;
                if (currentWordIdx >= 0) {{
                    const currentWord = document.querySelector(`.word[data-word-idx="${{currentWordIdx}}"]`);
                    if (currentWord) {{
                        currentWord.classList.add('highlight-word');
                        scrollToElement(currentWord);
                    }}
                }}
            }}
        }}

        function updateSentenceHighlight(currentTime) {{
            // Find the current sentence based on time
            let foundIdx = -1;
            for (let i = 0; i < sentenceTimings.length; i++) {{
                if (currentTime >= sentenceTimings[i].start && currentTime < sentenceTimings[i].end) {{
                    foundIdx = i;
                    break;
                }}
            }}

            if (foundIdx !== currentSentenceIdx) {{
                // Remove previous highlight
                if (currentSentenceIdx >= 0) {{
                    const prevSentence = document.querySelector(`.sentence[data-sentence-idx="${{currentSentenceIdx}}"]`);
                    if (prevSentence) {{
                        prevSentence.classList.remove('highlight-sentence');
                    }}
                }}

                // Add new highlight
                currentSentenceIdx = foundIdx;
                if (currentSentenceIdx >= 0) {{
                    const currentSentence = document.querySelector(`.sentence[data-sentence-idx="${{currentSentenceIdx}}"]`);
                    if (currentSentence) {{
                        currentSentence.classList.add('highlight-sentence');
                        scrollToElement(currentSentence);
                    }}
                }}
            }}
        }}

        function clearHighlights() {{
            // Remove all word highlights
            document.querySelectorAll('.word.highlight-word').forEach(el => {{
                el.classList.remove('highlight-word');
            }});

            // Remove all sentence highlights
            document.querySelectorAll('.sentence.highlight-sentence').forEach(el => {{
                el.classList.remove('highlight-sentence');
            }});

            currentWordIdx = -1;
            currentSentenceIdx = -1;
        }}

        function scrollToElement(element) {{
            // Smooth scroll to keep element in view
            const rect = element.getBoundingClientRect();
            const isInView = (
                rect.top >= 0 &&
                rect.bottom <= window.innerHeight
            );

            if (!isInView) {{
                element.scrollIntoView({{
                    behavior: 'smooth',
                    block: 'center'
                }});
            }}
        }}
    </script>
</body>
</html>"""

        return html

    def _generate_chapter_html_template(self, chapter_info: List[Dict], title: str,
                                       speech_rate: int) -> str:
        """Generate HTML template with chapter navigation"""

        import json

        # Build chapter data for JavaScript
        chapters_data = []
        for ch in chapter_info:
            word_timings, sentence_timings = self.estimate_timings(ch['text'], speech_rate)
            chapters_data.append({
                'number': ch['number'],
                'title': ch['title'],
                'audio': Path(ch['audio']).name,  # Use just the filename
                'word_timings': word_timings,
                'sentence_timings': sentence_timings,
                'text': ch['text']
            })

        chapters_json = json.dumps(chapters_data)

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: 'Georgia', serif;
            line-height: 1.8;
            color: #333;
            background: #f5f5f5;
        }}

        .container {{
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }}

        header {{
            background: #2c3e50;
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 8px 8px 0 0;
        }}

        h1 {{
            font-size: 2em;
            margin-bottom: 10px;
        }}

        .controls {{
            background: white;
            padding: 20px;
            border-left: 4px solid #3498db;
            border-right: 4px solid #3498db;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}

        .audio-player {{
            width: 100%;
            margin-bottom: 15px;
        }}

        .chapter-nav {{
            background: #ecf0f1;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 15px;
        }}

        .chapter-nav h3 {{
            margin-bottom: 10px;
            color: #2c3e50;
        }}

        .chapter-buttons {{
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }}

        .chapter-btn {{
            padding: 8px 15px;
            background: #3498db;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s;
        }}

        .chapter-btn:hover {{
            background: #2980b9;
        }}

        .chapter-btn.active {{
            background: #27ae60;
        }}

        .chapter-btn.disabled {{
            background: #95a5a6;
            cursor: not-allowed;
        }}

        .options {{
            display: flex;
            gap: 20px;
            align-items: center;
            flex-wrap: wrap;
            padding-top: 15px;
            border-top: 1px solid #ddd;
        }}

        .option-group {{
            display: flex;
            align-items: center;
            gap: 10px;
        }}

        label {{
            font-weight: bold;
            color: #555;
        }}

        input[type="radio"] {{
            cursor: pointer;
        }}

        .text-display {{
            background: white;
            padding: 30px;
            border-radius: 0 0 8px 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-left: 4px solid #3498db;
            border-right: 4px solid #3498db;
            border-bottom: 4px solid #3498db;
            min-height: 400px;
        }}

        .chapter-title {{
            font-size: 1.8em;
            color: #2c3e50;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #3498db;
        }}

        .sentence {{
            margin-bottom: 1em;
            transition: background-color 0.3s ease;
        }}

        .word {{
            transition: background-color 0.2s ease, color 0.2s ease;
            padding: 2px 1px;
        }}

        .sentence.highlight-sentence {{
            background-color: #fff9c4;
            padding: 5px;
            border-radius: 4px;
        }}

        .word.highlight-word {{
            background-color: #ffeb3b;
            color: #000;
            font-weight: bold;
            padding: 2px 4px;
            border-radius: 3px;
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 10px;
            }}

            .text-display {{
                padding: 15px;
            }}

            h1 {{
                font-size: 1.5em;
            }}

            .chapter-buttons {{
                flex-direction: column;
            }}

            .chapter-btn {{
                width: 100%;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>{title}</h1>
            <p>Chapter-based audiobook with synchronized text</p>
        </header>

        <div class="controls">
            <audio class="audio-player" controls id="audioPlayer">
                <source id="audioSource" src="" type="audio/wav">
                Your browser does not support the audio element.
            </audio>

            <div class="chapter-nav">
                <h3>📖 Chapters</h3>
                <div class="chapter-buttons" id="chapterButtons"></div>
            </div>

            <div class="options">
                <div class="option-group">
                    <label>Highlight Mode:</label>
                    <input type="radio" id="modeWord" name="highlightMode" value="word" checked>
                    <label for="modeWord">Word</label>
                    <input type="radio" id="modeSentence" name="highlightMode" value="sentence">
                    <label for="modeSentence">Sentence</label>
                    <input type="radio" id="modeOff" name="highlightMode" value="off">
                    <label for="modeOff">Off</label>
                </div>
            </div>
        </div>

        <div class="text-display" id="textDisplay">
            <h2 class="chapter-title" id="chapterTitle"></h2>
            <div id="chapterContent"></div>
        </div>
    </div>

    <script>
        // Chapter data
        const chaptersData = {chapters_json};

        // State
        let currentChapter = 0;
        let highlightMode = 'word';
        let currentWordIdx = -1;
        let currentSentenceIdx = -1;

        // DOM elements
        const audioPlayer = document.getElementById('audioPlayer');
        const audioSource = document.getElementById('audioSource');
        const textDisplay = document.getElementById('textDisplay');
        const chapterTitle = document.getElementById('chapterTitle');
        const chapterContent = document.getElementById('chapterContent');
        const chapterButtons = document.getElementById('chapterButtons');
        const modeRadios = document.getElementsByName('highlightMode');

        // Initialize chapters
        function initChapters() {{
            chaptersData.forEach((chapter, index) => {{
                const btn = document.createElement('button');
                btn.className = 'chapter-btn';
                btn.textContent = `Ch ${{chapter.number}}: ${{chapter.title}}`;
                btn.onclick = () => loadChapter(index);
                chapterButtons.appendChild(btn);
            }});
            loadChapter(0);
        }}

        // Load chapter
        function loadChapter(index) {{
            currentChapter = index;
            const chapter = chaptersData[index];

            // Update audio source
            audioSource.src = chapter.audio;
            audioPlayer.load();

            // Update title
            chapterTitle.textContent = `Chapter ${{chapter.number}}: ${{chapter.title}}`;

            // Generate text HTML
            chapterContent.innerHTML = generateChapterHTML(chapter);

            // Update button states
            const buttons = chapterButtons.querySelectorAll('.chapter-btn');
            buttons.forEach((btn, i) => {{
                btn.classList.toggle('active', i === index);
            }});

            // Reset highlights
            clearHighlights();
        }}

        // Generate HTML for chapter text
        function generateChapterHTML(chapter) {{
            const sentences = chapter.text.split(/(?<=[.!?])\\s+/);
            let html = '';
            let wordIdx = 0;

            sentences.forEach((sentence, sentIdx) => {{
                html += `<p class="sentence" data-sentence-idx="${{sentIdx}}">`;
                const words = sentence.match(/\\b\\w+\\b|[^\\w\\s]/g) || [];

                words.forEach(word => {{
                    if (wordIdx < chapter.word_timings.length) {{
                        const timing = chapter.word_timings[wordIdx];
                        html += `<span class="word" data-word-idx="${{wordIdx}}" data-start="${{timing.start.toFixed(2)}}" data-end="${{timing.end.toFixed(2)}}">${{word}}</span>`;
                        if (!/[.!?,;:]/.test(word)) {{
                            html += ' ';
                        }}
                        wordIdx++;
                    }}
                }});

                html += '</p>\\n';
            }});

            return html;
        }}

        // Update highlight mode
        modeRadios.forEach(radio => {{
            radio.addEventListener('change', (e) => {{
                highlightMode = e.target.value;
                clearHighlights();
            }});
        }});

        // Update highlights as audio plays
        audioPlayer.addEventListener('timeupdate', () => {{
            const currentTime = audioPlayer.currentTime;
            const chapter = chaptersData[currentChapter];

            if (highlightMode === 'off') {{
                clearHighlights();
                return;
            }}

            if (highlightMode === 'word') {{
                updateWordHighlight(currentTime, chapter);
            }} else if (highlightMode === 'sentence') {{
                updateSentenceHighlight(currentTime, chapter);
            }}
        }});

        // Auto-play next chapter when current chapter ends
        audioPlayer.addEventListener('ended', () => {{
            const nextChapter = currentChapter + 1;
            if (nextChapter < chaptersData.length) {{
                console.log(`Auto-playing next chapter: ${{nextChapter + 1}}`);
                loadChapter(nextChapter);
                // Small delay to ensure audio is loaded before playing
                setTimeout(() => {{
                    audioPlayer.play().catch(err => {{
                        console.log('Auto-play prevented by browser:', err);
                    }});
                }}, 100);
            }} else {{
                console.log('Finished all chapters');
                clearHighlights();
            }}
        }});

        function updateWordHighlight(currentTime, chapter) {{
            let foundIdx = -1;
            for (let i = 0; i < chapter.word_timings.length; i++) {{
                if (currentTime >= chapter.word_timings[i].start && currentTime < chapter.word_timings[i].end) {{
                    foundIdx = i;
                    break;
                }}
            }}

            if (foundIdx !== currentWordIdx) {{
                if (currentWordIdx >= 0) {{
                    const prevWord = document.querySelector(`.word[data-word-idx="${{currentWordIdx}}"]`);
                    if (prevWord) prevWord.classList.remove('highlight-word');
                }}

                currentWordIdx = foundIdx;
                if (currentWordIdx >= 0) {{
                    const currentWord = document.querySelector(`.word[data-word-idx="${{currentWordIdx}}"]`);
                    if (currentWord) {{
                        currentWord.classList.add('highlight-word');
                        scrollToElement(currentWord);
                    }}
                }}
            }}
        }}

        function updateSentenceHighlight(currentTime, chapter) {{
            let foundIdx = -1;
            for (let i = 0; i < chapter.sentence_timings.length; i++) {{
                if (currentTime >= chapter.sentence_timings[i].start && currentTime < chapter.sentence_timings[i].end) {{
                    foundIdx = i;
                    break;
                }}
            }}

            if (foundIdx !== currentSentenceIdx) {{
                if (currentSentenceIdx >= 0) {{
                    const prevSentence = document.querySelector(`.sentence[data-sentence-idx="${{currentSentenceIdx}}"]`);
                    if (prevSentence) prevSentence.classList.remove('highlight-sentence');
                }}

                currentSentenceIdx = foundIdx;
                if (currentSentenceIdx >= 0) {{
                    const currentSentence = document.querySelector(`.sentence[data-sentence-idx="${{currentSentenceIdx}}"]`);
                    if (currentSentence) {{
                        currentSentence.classList.add('highlight-sentence');
                        scrollToElement(currentSentence);
                    }}
                }}
            }}
        }}

        function clearHighlights() {{
            document.querySelectorAll('.word.highlight-word').forEach(el => {{
                el.classList.remove('highlight-word');
            }});
            document.querySelectorAll('.sentence.highlight-sentence').forEach(el => {{
                el.classList.remove('highlight-sentence');
            }});
            currentWordIdx = -1;
            currentSentenceIdx = -1;
        }}

        function scrollToElement(element) {{
            const rect = element.getBoundingClientRect();
            const isInView = (
                rect.top >= 0 &&
                rect.bottom <= window.innerHeight
            );

            if (!isInView) {{
                element.scrollIntoView({{
                    behavior: 'smooth',
                    block: 'center'
                }});
            }}
        }}

        // Initialize
        initChapters();
    </script>
</body>
</html>"""

        return html
