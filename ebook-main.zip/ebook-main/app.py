#!/usr/bin/env python3
"""Compiled application entry point."""

from gui import main


if __name__ == "__main__":
    main()
