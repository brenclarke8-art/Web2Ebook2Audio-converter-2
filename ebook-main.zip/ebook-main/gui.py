#!/usr/bin/env python3
"""
GUI Application for Web to Ebook Converter
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox
import threading
import logging
import sys
import subprocess
import platform
import shutil
import atexit
import tempfile
import time
import traceback
import webbrowser
from pathlib import Path
import urllib.error
import urllib.request
import yaml
from urllib.parse import urlparse
from config import Config
from kokoro_voice_catalog import get_kokoro_voice_names
from book_library import BookLibrary

APP_DIR = Path(__file__).parent.resolve()
CONFIG_PATH = APP_DIR / "config.yaml"
APP_USER_AGENT = "WebToEbookConverter"

# ── Per-platform UI defaults ──────────────────────────────────────────────────
_IS_WINDOWS = platform.system() == "Windows"
_FONT_FAMILY = "Segoe UI" if _IS_WINDOWS else "TkDefaultFont"
_MONO_FAMILY = "Consolas" if _IS_WINDOWS else "TkFixedFont"
_FONT = (_FONT_FAMILY, 10)
_FONT_BOLD = (_FONT_FAMILY, 10, "bold")
_FONT_HEADING = (_FONT_FAMILY, 12, "bold")
_FONT_MONO = (_MONO_FAMILY, 9)

# Windows 11 / Fluent-inspired palette (used for clam/cross-platform fallback)
_CLR_ACCENT = "#0078D4"
_CLR_ACCENT_HOVER = "#106EBE"
_CLR_ACCENT_FG = "#FFFFFF"
_CLR_BG = "#F3F3F3"
_CLR_SURFACE = "#FFFFFF"
_CLR_BORDER = "#D1D1D1"
_CLR_TEXT = "#1A1A1A"
_CLR_TEXT_MUTED = "#6B6B6B"
_CLR_LOG_BG = "#FAFAFA"
_CLR_SUCCESS = "#107C10"
_CLR_ERROR = "#D13438"


def write_gui_crash_log(exc: Exception):
    """Write a crash log only when the GUI actually fails."""
    try:
        from datetime import datetime

        log_dir = APP_DIR / "logs"
        log_dir.mkdir(exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = log_dir / f"gui_crash_{timestamp}.log"
        with open(log_file, "w", encoding="utf-8") as handle:
            handle.write(f"Error: {exc}\n\n")
            handle.write(traceback.format_exc())
        return log_file
    except Exception:
        return None


class TextHandler(logging.Handler):
    """Custom logging handler to redirect logs to GUI text widget"""

    def __init__(self, text_widget):
        super().__init__()
        self.text_widget = text_widget

    def emit(self, record):
        msg = self.format(record)
        def append():
            self.text_widget.configure(state='normal')
            self.text_widget.insert(tk.END, msg + '\n')
            self.text_widget.configure(state='disabled')
            self.text_widget.see(tk.END)
        self.text_widget.after(0, append)


class EbookConverterGUI:
    """Main GUI Application"""
    BROWSER_CLEANUP_TIMEOUT_SECONDS = 5
    CDP_POLL_INTERVAL_SECONDS = 0.5
    CDP_WAIT_TIMEOUT_SECONDS = 10
    EDGE_SIGNIN_URL = "https://login.live.com/"

    def __init__(self, root):
        self.root = root
        self.root.title("Web to Ebook Converter")
        self.root.geometry("1020x860")
        self.root.minsize(800, 620)

        # ── Apply theme ───────────────────────────────────────────────────────
        style = ttk.Style()
        _applied_native = False
        for _theme in ("vista", "winnative", "clam"):
            if _theme in style.theme_names():
                style.theme_use(_theme)
                _applied_native = _theme in ("vista", "winnative")
                break

        # ── Font / colour overrides (supplement the native theme) ─────────────
        style.configure("TLabel", font=_FONT)
        style.configure("TButton", font=_FONT, padding=(8, 4))
        style.configure("TCheckbutton", font=_FONT)
        style.configure("TRadiobutton", font=_FONT)
        style.configure("TCombobox", font=_FONT, padding=(4, 3))
        style.configure("TEntry", font=_FONT, padding=(4, 3))
        style.configure("TSpinbox", font=_FONT, padding=(4, 3))
        style.configure("TLabelframe.Label", font=_FONT_BOLD)
        style.configure("TNotebook.Tab", font=_FONT, padding=(12, 6))
        style.configure("Treeview", font=_FONT, rowheight=26)
        style.configure("Treeview.Heading", font=_FONT_BOLD)

        # Accent button — blue on non-native themes; native themes keep OS default
        if not _applied_native:
            style.configure(
                "Accent.TButton",
                font=_FONT_BOLD,
                padding=(10, 5),
                background=_CLR_ACCENT,
                foreground=_CLR_ACCENT_FG,
                borderwidth=0,
                relief="flat",
            )
            style.map(
                "Accent.TButton",
                background=[("active", _CLR_ACCENT_HOVER), ("disabled", _CLR_BORDER)],
                foreground=[("disabled", _CLR_TEXT_MUTED)],
            )
        else:
            # On native Windows themes inherit OS button look; just make it bold
            style.configure("Accent.TButton", font=_FONT_BOLD, padding=(10, 5))

        # Progressbar accent colour
        if not _applied_native:
            style.configure(
                "Accent.Horizontal.TProgressbar",
                troughcolor=_CLR_BORDER,
                background=_CLR_ACCENT,
                thickness=6,
            )

        # Background for the root window
        if not _applied_native:
            self.root.configure(bg=_CLR_BG)

        # Variables
        self.is_processing = False
        self.browser_process = None
        self.browser_profile_dir = None
        atexit.register(self._cleanup_browser_profile_dir)
        self.root.protocol("WM_DELETE_WINDOW", self.on_window_close)

        # Create main container
        main_container = ttk.Frame(root, padding="10")
        main_container.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        root.columnconfigure(0, weight=1)
        root.rowconfigure(0, weight=1)

        # Create notebook (tabs)
        self.notebook = ttk.Notebook(main_container)
        self.notebook.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        main_container.columnconfigure(0, weight=1)
        main_container.rowconfigure(0, weight=1)

        # Create tabs
        self.create_main_tab()
        self.create_multispeaker_tab()
        self.create_browser_tab()
        self.create_translation_tab()
        self.create_advanced_tab()
        self.create_batch_tab()
        self.create_library_tab()
        self.create_update_tab()

        # Status bar — separator above, label below
        ttk.Separator(main_container, orient=tk.HORIZONTAL).grid(
            row=1, column=0, sticky=(tk.W, tk.E), pady=(4, 0)
        )
        self.status_var = tk.StringVar(value="Ready")
        status_bar = ttk.Label(
            main_container,
            textvariable=self.status_var,
            relief=tk.FLAT,
            anchor=tk.W,
            font=_FONT,
            padding=(6, 3),
        )
        status_bar.grid(row=2, column=0, sticky=(tk.W, tk.E))

    def create_main_tab(self):
        """Create main conversion tab"""
        main_tab = self._create_scrollable_tab("Converter")

        # URLs Section
        urls_frame = ttk.LabelFrame(main_tab, text="URLs to Convert", padding="10")
        urls_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))

        ttk.Label(urls_frame, text="Enter URLs (one per line):").grid(row=0, column=0, sticky=tk.W, pady=(0, 5))

        self.urls_text = scrolledtext.ScrolledText(
            urls_frame, height=8, width=70,
            font=_FONT_MONO, relief=tk.FLAT, borderwidth=1,
        )
        self.urls_text.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        urls_frame.rowconfigure(1, weight=1)
        urls_frame.columnconfigure(0, weight=1)

        # Book Information Section
        info_frame = ttk.LabelFrame(main_tab, text="Book Information", padding="10")
        info_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))

        ttk.Label(info_frame, text="Title:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.title_var = tk.StringVar(value="My Book")
        ttk.Entry(info_frame, textvariable=self.title_var, width=50).grid(row=0, column=1, sticky=(tk.W, tk.E), pady=5, padx=(5, 0))

        ttk.Label(info_frame, text="Author:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.author_var = tk.StringVar(value="Unknown")
        ttk.Entry(info_frame, textvariable=self.author_var, width=50).grid(row=1, column=1, sticky=(tk.W, tk.E), pady=5, padx=(5, 0))

        ttk.Label(info_frame, text="Output Directory:").grid(row=2, column=0, sticky=tk.W, pady=5)
        output_frame = ttk.Frame(info_frame)
        output_frame.grid(row=2, column=1, sticky=(tk.W, tk.E), pady=5, padx=(5, 0))
        self.output_var = tk.StringVar(value="output")
        ttk.Entry(output_frame, textvariable=self.output_var, width=40).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(output_frame, text="Browse...", command=self.browse_output_dir).pack(side=tk.LEFT, padx=(5, 0))

        info_frame.columnconfigure(1, weight=1)

        # TTS Settings Section
        tts_frame = ttk.LabelFrame(main_tab, text="Kokoro TTS Settings", padding="10")
        tts_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))

        # Voice selection
        ttk.Label(tts_frame, text="Voice:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.kokoro_voice_var = tk.StringVar(value="af_heart")
        kokoro_voices = get_kokoro_voice_names()
        ttk.Combobox(tts_frame, textvariable=self.kokoro_voice_var,
                    values=kokoro_voices, width=20).grid(row=0, column=1, sticky=tk.W, pady=5, padx=(5, 0))
        ttk.Label(
            tts_frame,
            text="Tip: you can also type any Kokoro voice name, a local .pt filename, or an absolute .pt file path.",
            foreground="gray",
            wraplength=450,
        ).grid(row=0, column=2, sticky=tk.W, padx=(10, 0))

        # Language selection
        ttk.Label(tts_frame, text="Language:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.kokoro_lang_code_var = tk.StringVar(value="a")
        kokoro_languages = ["a", "b", "e", "f", "h", "i", "j", "p", "z"]
        lang_labels = {
            "a": "a - American English",
            "b": "b - British English",
            "e": "e - Spanish",
            "f": "f - French",
            "h": "h - Hindi",
            "i": "i - Italian",
            "j": "j - Japanese",
            "p": "p - Portuguese",
            "z": "z - Mandarin"
        }
        ttk.Combobox(tts_frame, textvariable=self.kokoro_lang_code_var,
                    values=list(lang_labels.values()), state="readonly", width=25).grid(row=1, column=1, sticky=tk.W, pady=5, padx=(5, 0))

        # Speed control
        ttk.Label(tts_frame, text="Speed (0.5-2.0):").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.kokoro_speed_var = tk.DoubleVar(value=1.0)
        speed_frame = ttk.Frame(tts_frame)
        speed_frame.grid(row=2, column=1, sticky=(tk.W, tk.E), pady=5, padx=(5, 0))
        ttk.Scale(speed_frame, from_=0.5, to=2.0, variable=self.kokoro_speed_var,
                 orient=tk.HORIZONTAL, length=200).pack(side=tk.LEFT)
        ttk.Label(speed_frame, textvariable=self.kokoro_speed_var, width=5).pack(side=tk.LEFT, padx=(10, 0))

        ttk.Label(tts_frame, text="Speech Rate (WPM):").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.speech_rate_var = tk.IntVar(value=150)
        rate_frame = ttk.Frame(tts_frame)
        rate_frame.grid(row=3, column=1, sticky=(tk.W, tk.E), pady=5, padx=(5, 0))
        ttk.Scale(rate_frame, from_=100, to=250, variable=self.speech_rate_var,
                 orient=tk.HORIZONTAL, length=200).pack(side=tk.LEFT)
        ttk.Label(rate_frame, textvariable=self.speech_rate_var, width=5).pack(side=tk.LEFT, padx=(10, 0))

        # Instant Preview button
        ttk.Button(tts_frame, text="⚡ Test Voice & Speed (Instant Preview)",
                  command=self.instant_preview).grid(row=4, column=0, columnspan=2, pady=(10, 5))

        # Voice preview button
        ttk.Button(tts_frame, text="Preview All Voices",
                  command=self.preview_voices).grid(row=5, column=0, columnspan=2, pady=(5, 0))

        # Control Buttons
        button_frame = ttk.Frame(main_tab)
        button_frame.grid(row=3, column=0, columnspan=2, pady=(10, 0))

        self.start_button = ttk.Button(button_frame, text="Start Conversion",
                                       command=self.start_conversion, style="Accent.TButton")
        self.start_button.pack(side=tk.LEFT, padx=5)

        self.stop_button = ttk.Button(button_frame, text="Stop",
                                      command=self.stop_conversion, state=tk.DISABLED)
        self.stop_button.pack(side=tk.LEFT, padx=5)

        ttk.Button(button_frame, text="Clear Log",
                  command=self.clear_log).pack(side=tk.LEFT, padx=5)

        # Progress Section
        progress_frame = ttk.LabelFrame(main_tab, text="Progress", padding="10")
        progress_frame.grid(row=4, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(10, 0))

        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(
            progress_frame,
            variable=self.progress_var,
            mode='determinate',
            maximum=100,
            style="Accent.Horizontal.TProgressbar",
        )
        self.progress_bar.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))

        self.log_text = scrolledtext.ScrolledText(
            progress_frame, height=15, width=70,
            state='disabled',
            bg=_CLR_LOG_BG,
            fg=_CLR_TEXT,
            font=_FONT_MONO,
            relief=tk.FLAT,
            borderwidth=1,
            insertbackground=_CLR_TEXT,
        )
        self.log_text.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        progress_frame.columnconfigure(0, weight=1)
        progress_frame.rowconfigure(1, weight=1)

        # Configure logging to GUI
        self.setup_logging()

        # Configure grid weights
        main_tab.columnconfigure(0, weight=1)
        main_tab.rowconfigure(4, weight=1)

    def _create_scrollable_tab(self, title):
        """Create a notebook tab with a right-side vertical scrollbar."""
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text=title)

        canvas = tk.Canvas(tab, highlightthickness=0, borderwidth=0)
        scrollbar = ttk.Scrollbar(tab, orient=tk.VERTICAL, command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas, padding="10")
        scrollable_window = canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")

        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))

        tab.columnconfigure(0, weight=1)
        tab.rowconfigure(0, weight=1)

        scrollable_frame.bind(
            "<Configure>",
            lambda event, canvas=canvas: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.bind(
            "<Configure>",
            lambda event, canvas=canvas, window=scrollable_window: canvas.itemconfigure(window, width=event.width)
        )
        canvas.bind("<MouseWheel>", lambda event, c=canvas: self._on_mousewheel(event, c))
        canvas.bind("<Button-4>", lambda event, c=canvas: self._on_mousewheel_linux(event, c))
        canvas.bind("<Button-5>", lambda event, c=canvas: self._on_mousewheel_linux(event, c))

        return scrollable_frame

    def _on_mousewheel(self, event, canvas):
        """Handle Windows/macOS wheel scrolling."""
        if event.delta:
            canvas.yview_scroll(int(-event.delta / 120), "units")

    def _on_mousewheel_linux(self, event, canvas):
        """Handle Linux wheel scrolling."""
        if event.num == 4:
            canvas.yview_scroll(-1, "units")
        elif event.num == 5:
            canvas.yview_scroll(1, "units")

    def create_multispeaker_tab(self):
        """Create dedicated multi-speaker settings tab."""
        multispeaker_tab = self._create_scrollable_tab("Multi-Speaker")

        ttk.Label(
            multispeaker_tab,
            text="Configure narrator and dialogue voices for multi-speaker audiobook output.",
            foreground="gray",
            wraplength=700,
            justify=tk.LEFT,
        ).grid(row=0, column=0, sticky=tk.W, pady=(0, 10))

        char_voice_frame = ttk.LabelFrame(multispeaker_tab, text="Character Voices", padding="10")
        char_voice_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        kokoro_voices = get_kokoro_voice_names()

        self.enable_character_voices_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            char_voice_frame,
            text="Enable separate voices for characters in dialogue",
            variable=self.enable_character_voices_var,
            command=self.toggle_character_voice_settings,
        ).grid(row=0, column=0, columnspan=2, sticky=tk.W, pady=(0, 10))

        ttk.Label(char_voice_frame, text="Narrator Voice:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.narrator_voice_var = tk.StringVar(value="af_heart")
        self.narrator_voice_combo = ttk.Combobox(
            char_voice_frame,
            textvariable=self.narrator_voice_var,
            values=kokoro_voices,
            width=20,
            state=tk.DISABLED,
        )
        self.narrator_voice_combo.grid(row=1, column=1, sticky=tk.W, pady=5, padx=(5, 0))

        self.auto_assign_voices_var = tk.BooleanVar(value=True)
        self.auto_assign_check = ttk.Checkbutton(
            char_voice_frame,
            text="Auto-assign voices based on character gender",
            variable=self.auto_assign_voices_var,
            state=tk.DISABLED,
        )
        self.auto_assign_check.grid(row=2, column=0, columnspan=2, sticky=tk.W, pady=5)

        ttk.Label(char_voice_frame, text="Default Male Voice:").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.default_male_voice_var = tk.StringVar(value="am_adam")
        self.default_male_voice_combo = ttk.Combobox(
            char_voice_frame,
            textvariable=self.default_male_voice_var,
            values=kokoro_voices,
            width=20,
            state=tk.DISABLED,
        )
        self.default_male_voice_combo.grid(row=3, column=1, sticky=tk.W, pady=5, padx=(5, 0))

        ttk.Label(char_voice_frame, text="Default Female Voice:").grid(row=4, column=0, sticky=tk.W, pady=5)
        self.default_female_voice_var = tk.StringVar(value="af_bella")
        self.default_female_voice_combo = ttk.Combobox(
            char_voice_frame,
            textvariable=self.default_female_voice_var,
            values=kokoro_voices,
            width=20,
            state=tk.DISABLED,
        )
        self.default_female_voice_combo.grid(row=4, column=1, sticky=tk.W, pady=5, padx=(5, 0))

        ttk.Label(char_voice_frame, text="Pause Between Speakers (seconds):").grid(row=5, column=0, sticky=tk.W, pady=5)
        self.dialogue_pause_var = tk.DoubleVar(value=0.3)
        pause_frame = ttk.Frame(char_voice_frame)
        pause_frame.grid(row=5, column=1, sticky=(tk.W, tk.E), pady=5, padx=(5, 0))
        self.dialogue_pause_scale = ttk.Scale(
            pause_frame,
            from_=0.0,
            to=1.0,
            variable=self.dialogue_pause_var,
            orient=tk.HORIZONTAL,
            length=150,
            state=tk.DISABLED,
        )
        self.dialogue_pause_scale.pack(side=tk.LEFT)
        self.dialogue_pause_label = ttk.Label(pause_frame, textvariable=self.dialogue_pause_var, width=5)
        self.dialogue_pause_label.pack(side=tk.LEFT, padx=(10, 0))

        ttk.Label(char_voice_frame, text="Manual Character-to-Voice Mappings (YAML):").grid(
            row=6, column=0, columnspan=2, sticky=tk.W, pady=(10, 5)
        )

        mappings_frame = ttk.Frame(char_voice_frame)
        mappings_frame.grid(row=7, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S))

        self.character_voice_mappings_text = scrolledtext.ScrolledText(
            mappings_frame,
            height=6,
            width=70,
            state=tk.DISABLED,
            font=_FONT_MONO,
            relief=tk.FLAT,
            borderwidth=1,
        )
        self.character_voice_mappings_text.pack(fill=tk.BOTH, expand=True)

        mappings_example = """# Character-to-Voice Mappings (YAML format)
# Override auto-assignment with specific voice choices
# Format: character_name: voice_name
# Example:
# Alice: af_bella
# Bob: am_michael
# Carol: bf_emma

# Add your character mappings below:
"""
        self.character_voice_mappings_text.insert(tk.END, mappings_example)
        self.character_voice_mappings_text.config(state=tk.DISABLED)

        ttk.Label(
            char_voice_frame,
            text="💡 Tip: Leave blank to use auto-assignment. The app will detect characters and assign voices automatically.",
            foreground="gray",
            wraplength=700,
            state=tk.DISABLED,
        ).grid(row=8, column=0, columnspan=2, sticky=tk.W, pady=(5, 0))

        llm_frame = ttk.LabelFrame(multispeaker_tab, text="Dialogue Detector LLM (Ollama)", padding="10")
        llm_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=(10, 0))

        ttk.Label(llm_frame, text="LLM mode:").grid(row=0, column=0, sticky=tk.W, pady=(0, 10))
        self.dialogue_llm_mode_var = tk.StringVar(value="full")
        ttk.Label(llm_frame, text="full").grid(row=0, column=1, sticky=tk.W, pady=(0, 10), padx=(5, 0))
        ttk.Label(
            llm_frame,
            text="Full mode is always used for chapter-level dialogue detection.",
            foreground="gray",
            wraplength=550,
        ).grid(row=0, column=2, sticky=tk.W, pady=(0, 10), padx=(10, 0))

        self.dialogue_llm_strict_quotes_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            llm_frame,
            text='Strict quotes: only "..." text is dialogue',
            variable=self.dialogue_llm_strict_quotes_var,
        ).grid(row=1, column=0, columnspan=3, sticky=tk.W, pady=(0, 10))

        self.character_manual_review_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            llm_frame,
            text="Always prompt for manual character review",
            variable=self.character_manual_review_var,
        ).grid(row=2, column=0, columnspan=3, sticky=tk.W, pady=(0, 10))

        ttk.Label(
            llm_frame,
            text="Low-confidence new character threshold:",
        ).grid(row=3, column=0, sticky=tk.W, pady=5)
        self.character_review_low_conf_var = tk.DoubleVar(value=0.7)
        ttk.Spinbox(
            llm_frame,
            from_=0.0,
            to=1.0,
            increment=0.05,
            textvariable=self.character_review_low_conf_var,
            width=10,
        ).grid(row=3, column=1, sticky=tk.W, pady=5, padx=(5, 0))
        ttk.Label(
            llm_frame,
            text="Prompt review when new detected characters have confidence below this value.",
            foreground="gray",
            wraplength=550,
        ).grid(row=3, column=2, sticky=tk.W, pady=5, padx=(10, 0))

        ttk.Label(llm_frame, text="Model:").grid(row=4, column=0, sticky=tk.W, pady=5)
        self.dialogue_llm_model_var = tk.StringVar(value="mistral:instruct")
        ttk.Entry(llm_frame, textvariable=self.dialogue_llm_model_var, width=30).grid(
            row=4, column=1, sticky=(tk.W, tk.E), pady=5, padx=(5, 0)
        )

        ttk.Label(llm_frame, text="Ollama URL:").grid(row=5, column=0, sticky=tk.W, pady=5)
        self.dialogue_llm_url_var = tk.StringVar(value="http://localhost:11434/api/chat")
        ttk.Entry(llm_frame, textvariable=self.dialogue_llm_url_var, width=40).grid(
            row=5, column=1, sticky=(tk.W, tk.E), pady=5, padx=(5, 0)
        )

        ttk.Label(llm_frame, text="Request Timeout (seconds):").grid(row=6, column=0, sticky=tk.W, pady=5)
        self.dialogue_llm_timeout_var = tk.IntVar(value=200)
        ttk.Spinbox(llm_frame, from_=5, to=600, textvariable=self.dialogue_llm_timeout_var, width=10).grid(
            row=6, column=1, sticky=tk.W, pady=5, padx=(5, 0)
        )
        ttk.Label(
            llm_frame,
            text="Large timeout values can keep retries running longer before fallback.",
            foreground="gray",
            wraplength=550,
        ).grid(row=6, column=2, sticky=tk.W, pady=5, padx=(10, 0))

        ttk.Label(
            llm_frame,
            text="Uses local Ollama. If unavailable, detector falls back to regex-only automatically.",
            foreground="gray",
            wraplength=700,
        ).grid(row=7, column=0, columnspan=2, sticky=tk.W, pady=(5, 0))

        multispeaker_tab.columnconfigure(0, weight=1)
        char_voice_frame.columnconfigure(1, weight=1)
        llm_frame.columnconfigure(1, weight=1)

    def create_browser_tab(self):
        """Create dedicated browser connection settings tab."""
        browser_tab = self._create_scrollable_tab("Browser Connection")

        browser_frame = ttk.LabelFrame(browser_tab, text="Browser Connection", padding="10")
        browser_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))

        self.wait_for_js_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            browser_frame,
            text="Wait for JavaScript-rendered content",
            variable=self.wait_for_js_var
        ).grid(row=0, column=0, columnspan=2, sticky=tk.W, pady=(0, 2))

        self.remove_overlays_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            browser_frame,
            text="Remove anti-copy overlays",
            variable=self.remove_overlays_var
        ).grid(row=1, column=0, columnspan=2, sticky=tk.W, pady=(0, 10))

        ttk.Label(browser_frame, text="Browser timeout (seconds):").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.browser_timeout_var = tk.IntVar(value=30)
        ttk.Spinbox(browser_frame, from_=5, to=300, textvariable=self.browser_timeout_var, width=10).grid(
            row=2, column=1, sticky=tk.W, pady=5, padx=(5, 0)
        )

        self.use_existing_browser_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            browser_frame,
            text="Attach to existing Edge browser (required - use logged-in user session)",
            variable=self.use_existing_browser_var,
            state="disabled"
        ).grid(row=3, column=0, columnspan=2, sticky=tk.W, pady=(10, 5))

        # Edge browser is the only supported browser
        self.browser_choice_var = tk.StringVar(value="Edge")

        ttk.Label(browser_frame, text="CDP URL:").grid(row=4, column=0, sticky=tk.W, pady=5)
        self.browser_cdp_url_var = tk.StringVar(value="http://127.0.0.1:9222")
        ttk.Entry(browser_frame, textvariable=self.browser_cdp_url_var, width=40).grid(
            row=4, column=1, sticky=(tk.W, tk.E), pady=5, padx=(5, 0)
        )

        self.allow_edge_signin_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            browser_frame,
            text="Allow Edge account sign-in in the launched CDP window",
            variable=self.allow_edge_signin_var,
        ).grid(row=5, column=0, columnspan=2, sticky=tk.W, pady=(0, 5))

        ttk.Label(
            browser_frame,
            text="Uses a temporary Edge profile instead of guest mode so you can sign in before scraping.",
            foreground="gray",
            wraplength=700
        ).grid(row=6, column=0, columnspan=2, sticky=tk.W, pady=(0, 5))

        browser_button_frame = ttk.Frame(browser_frame)
        browser_button_frame.grid(row=7, column=0, columnspan=2, sticky=tk.W, pady=(5, 0))
        ttk.Button(
            browser_button_frame,
            text="Open Edge with CDP",
            command=self.open_browser_for_cloudflare
        ).pack(side=tk.LEFT)
        ttk.Button(
            browser_button_frame,
            text="Show Step-by-Step Setup",
            command=self.show_browser_setup_instructions
        ).pack(side=tk.LEFT, padx=(8, 0))

        ttk.Label(
            browser_frame,
            text=(
                "The scraper requires an open browser with remote debugging.\n"
                "Launch Edge here, then complete any Edge sign-in, website login, or anti-bot challenge in that same window before starting conversion."
            ),
            foreground="gray",
            wraplength=700
        ).grid(row=8, column=0, columnspan=2, sticky=tk.W, pady=(5, 0))

        browser_tab.columnconfigure(0, weight=1)
        browser_frame.columnconfigure(1, weight=1)

    def create_translation_tab(self):
        """Create translation settings tab"""
        translation_tab = self._create_scrollable_tab("Translation")

        # Enable Translation
        enable_frame = ttk.Frame(translation_tab)
        enable_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))

        self.enable_translation_var = tk.BooleanVar(value=False)
        enable_check = ttk.Checkbutton(enable_frame, text="Enable Translation",
                                       variable=self.enable_translation_var,
                                       command=self.on_translation_toggle)
        enable_check.pack(side=tk.LEFT)

        # Language Settings
        lang_frame = ttk.LabelFrame(translation_tab, text="Language Settings", padding="10")
        lang_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=(0, 10))

        ttk.Label(lang_frame, text="Source Language:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.source_language_var = tk.StringVar(value="auto")
        source_langs = ["auto", "ja", "zh", "ko", "ru", "es", "fr", "de", "it", "pt"]
        source_combo = ttk.Combobox(lang_frame, textvariable=self.source_language_var,
                                    values=source_langs, width=15)
        source_combo.grid(row=0, column=1, sticky=tk.W, pady=5, padx=(5, 0))

        ttk.Label(lang_frame, text="Target Language:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.target_language_var = tk.StringVar(value="en")
        target_langs = ["en", "es", "fr", "de", "it", "pt", "ru", "ja", "zh", "ko"]
        target_combo = ttk.Combobox(lang_frame, textvariable=self.target_language_var,
                                    values=target_langs, width=15)
        target_combo.grid(row=1, column=1, sticky=tk.W, pady=5, padx=(5, 0))

        # API Settings
        api_frame = ttk.LabelFrame(translation_tab, text="Translation API Settings", padding="10")
        api_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=(0, 10))

        ttk.Label(api_frame, text="API URL:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.translation_api_url_var = tk.StringVar(value="http://localhost:5000/translate")
        ttk.Entry(api_frame, textvariable=self.translation_api_url_var, width=50).grid(
            row=0, column=1, sticky=(tk.W, tk.E), pady=5, padx=(5, 0))

        ttk.Label(api_frame, text="API Key (optional):").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.translation_api_key_var = tk.StringVar(value="")
        ttk.Entry(api_frame, textvariable=self.translation_api_key_var, width=50, show="*").grid(
            row=1, column=1, sticky=(tk.W, tk.E), pady=5, padx=(5, 0))

        api_frame.columnconfigure(1, weight=1)

        # Character-Pronoun Mapping (NEW)
        char_frame = ttk.LabelFrame(translation_tab, text="Character-Pronoun Mapping (Auto-Correction)", padding="10")
        char_frame.grid(row=3, column=0, sticky=(tk.W, tk.E), pady=(0, 10))

        ttk.Label(char_frame, text="Define character genders for automatic pronoun correction:").grid(
            row=0, column=0, columnspan=3, sticky=tk.W, pady=(0, 5))

        ttk.Label(char_frame, text="Character Name:").grid(row=1, column=0, sticky=tk.W, pady=5)
        ttk.Label(char_frame, text="Gender:").grid(row=1, column=1, sticky=tk.W, pady=5, padx=(10, 0))

        # Scrollable character list
        char_list_frame = ttk.Frame(char_frame)
        char_list_frame.grid(row=2, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S))

        self.character_gender_text = scrolledtext.ScrolledText(
            char_list_frame, height=6, width=70,
            font=_FONT_MONO, relief=tk.FLAT, borderwidth=1,
        )
        self.character_gender_text.pack(fill=tk.BOTH, expand=True)

        # Insert example
        char_example = """# Character Gender Mapping (YAML format)
# Specify character names and their correct gender for pronoun correction
# Format: character_name: gender (male, female, or neutral)
# Example:
# Alice: female
# Bob: male
# Sam: neutral

# Add your characters below:
"""
        self.character_gender_text.insert(tk.END, char_example)

        ttk.Label(char_frame, text="💡 Tip: The system will analyze the text, detect characters, and automatically fix pronouns based on this mapping.",
                 foreground="gray", wraplength=600).grid(row=3, column=0, columnspan=3, sticky=tk.W, pady=(5, 0))

        char_frame.columnconfigure(0, weight=1)

        # Custom Translation Rules
        rules_frame = ttk.LabelFrame(translation_tab, text="Custom Translation Rules (Advanced)", padding="10")
        rules_frame.grid(row=4, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))

        ttk.Label(rules_frame, text="Define custom rules for consistent translation (character names, pronouns, etc.):").grid(
            row=0, column=0, columnspan=2, sticky=tk.W, pady=(0, 5))

        # Rules editor
        self.translation_rules_text = scrolledtext.ScrolledText(
            rules_frame, height=12, width=70,
            font=_FONT_MONO, relief=tk.FLAT, borderwidth=1,
        )
        self.translation_rules_text.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S))

        # Insert example
        example_rules = """# Translation Rules (YAML format)
# Each rule has: pattern, replacement, is_regex (true/false), case_sensitive (true/false)
# Example 1: Keep character names consistent
- pattern: "Protagonist"
  replacement: "Hero"
  is_regex: false
  case_sensitive: true

# Example 2: Fix pronoun (using regex)
- pattern: "\\\\bhe\\\\b"
  replacement: "she"
  is_regex: true
  case_sensitive: false

# Add your own rules below:
"""
        self.translation_rules_text.insert(tk.END, example_rules)

        rules_frame.columnconfigure(0, weight=1)
        rules_frame.rowconfigure(1, weight=1)

        # Helper info
        info_frame = ttk.Frame(translation_tab)
        info_frame.grid(row=5, column=0, sticky=(tk.W, tk.E), pady=(10, 0))

        info_text = """Translation requires a local or remote AI translation API.
For local translation, you can use tools like:
• LibreTranslate (https://github.com/LibreTranslate/LibreTranslate)
• Argos Translate (https://github.com/argosopentech/argos-translate)
• DeepL API (https://www.deepl.com/pro-api)

Common language codes: ja (Japanese), zh (Chinese), ko (Korean),
ru (Russian), es (Spanish), fr (French), de (German)

Pronoun Analysis: The system automatically analyzes character mentions and pronoun usage
to intelligently fix pronoun inconsistencies after translation."""

        ttk.Label(info_frame, text=info_text, foreground="gray", justify=tk.LEFT, wraplength=650).pack()

        # Configure grid weights
        translation_tab.columnconfigure(0, weight=1)
        translation_tab.rowconfigure(4, weight=1)

        # Initial state
        self.on_translation_toggle()

    def on_translation_toggle(self):
        """Handle translation enable/disable"""
        # This could enable/disable translation-related widgets
        pass

    def create_advanced_tab(self):
        """Create advanced settings tab"""
        advanced_tab = self._create_scrollable_tab("Advanced Settings")

        # Limits Section
        limits_frame = ttk.LabelFrame(advanced_tab, text="Processing Limits", padding="10")
        limits_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))

        ttk.Label(limits_frame, text="Max Chapters (0 = no limit):").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.max_chapters_var = tk.IntVar(value=0)
        ttk.Spinbox(limits_frame, from_=0, to=100, textvariable=self.max_chapters_var,
                   width=10).grid(row=0, column=1, sticky=tk.W, pady=5, padx=(5, 0))

        ttk.Label(limits_frame, text="Max Duration (minutes, 0 = no limit):").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.max_duration_var = tk.IntVar(value=0)
        ttk.Spinbox(limits_frame, from_=0, to=300, textvariable=self.max_duration_var,
                   width=10).grid(row=1, column=1, sticky=tk.W, pady=5, padx=(5, 0))

        # Chapter Range Section
        chapter_frame = ttk.LabelFrame(advanced_tab, text="Chapter Range & Audio Options", padding="10")
        chapter_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=(0, 10))

        ttk.Label(chapter_frame, text="Start Chapter (1-based):").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.start_chapter_var = tk.IntVar(value=1)
        ttk.Spinbox(chapter_frame, from_=1, to=999, textvariable=self.start_chapter_var,
                   width=10).grid(row=0, column=1, sticky=tk.W, pady=5, padx=(5, 0))

        ttk.Label(chapter_frame, text="End Chapter (0 = all):").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.end_chapter_var = tk.IntVar(value=0)
        ttk.Spinbox(chapter_frame, from_=0, to=999, textvariable=self.end_chapter_var,
                   width=10).grid(row=1, column=1, sticky=tk.W, pady=5, padx=(5, 0))

        self.per_chapter_audio_var = tk.BooleanVar(value=False)
        per_chapter_check = ttk.Checkbutton(chapter_frame,
                                           text="Generate separate audio files per chapter",
                                           variable=self.per_chapter_audio_var)
        per_chapter_check.grid(row=2, column=0, columnspan=2, sticky=tk.W, pady=(10, 5))

        ttk.Label(chapter_frame,
                 text="💡 Per-chapter audio enables chapter navigation in sync display",
                 foreground="gray",
                 wraplength=600).grid(row=3, column=0, columnspan=2, sticky=tk.W)

        # CSS Selectors Section
        css_frame = ttk.LabelFrame(advanced_tab, text="CSS Selectors for Content Extraction", padding="10")
        css_frame.grid(row=2, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))

        ttk.Label(css_frame, text="Enter CSS selectors (one per line):").grid(row=0, column=0, sticky=tk.W, pady=(0, 5))

        self.css_text = scrolledtext.ScrolledText(
            css_frame, height=10, width=70,
            font=_FONT_MONO, relief=tk.FLAT, borderwidth=1,
        )
        self.css_text.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        self.css_text.insert(tk.END, "article\n.content\n.post-content\nmain")

        # Visual Order Option
        visual_order_frame = ttk.Frame(css_frame)
        visual_order_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=(10, 0))

        self.use_visual_order_var = tk.BooleanVar(value=False)
        visual_check = ttk.Checkbutton(visual_order_frame,
                                       text="Use Visual Order (for pages with incorrect HTML order)",
                                       variable=self.use_visual_order_var)
        visual_check.pack(side=tk.LEFT)

        ttk.Label(visual_order_frame,
                 text="💡 Enable this if text appears in wrong order",
                 foreground="gray").pack(side=tk.LEFT, padx=(10, 0))

        css_frame.columnconfigure(0, weight=1)
        css_frame.rowconfigure(1, weight=1)

        # Config File Section
        config_frame = ttk.LabelFrame(advanced_tab, text="Configuration File", padding="10")
        config_frame.grid(row=3, column=0, sticky=(tk.W, tk.E), pady=(0, 10))

        ttk.Button(config_frame, text="Load from config.yaml",
                  command=self.load_config_yaml).grid(row=0, column=0, padx=5)
        ttk.Button(config_frame, text="Save to config.yaml",
                  command=self.save_config_yaml).grid(row=0, column=1, padx=5)

        # Configure grid weights
        advanced_tab.columnconfigure(0, weight=1)
        advanced_tab.rowconfigure(2, weight=1)

    def setup_logging(self):
        """Setup logging to GUI text widget only (no console output)."""
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)

        # Remove all existing handlers (including any StreamHandler to stderr)
        for handler in logger.handlers[:]:
            logger.removeHandler(handler)

        # Route all log output to the GUI widget
        gui_handler = TextHandler(self.log_text)
        gui_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
        logger.addHandler(gui_handler)

    def browse_output_dir(self):
        """Browse for output directory"""
        directory = filedialog.askdirectory(initialdir=self.output_var.get())
        if directory:
            self.output_var.set(directory)

    def preview_voices(self):
        """Run voice preview script"""
        def run_preview():
            try:
                import subprocess
                self.status_var.set("Running voice preview...")
                kwargs = dict(check=True, cwd=str(APP_DIR))
                if _IS_WINDOWS:
                    kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
                subprocess.run(
                    [sys.executable, str(APP_DIR / "voice_preview.py")],
                    **kwargs,
                )
                self.status_var.set("Voice preview complete")
                messagebox.showinfo("Voice Preview",
                                   "Voice preview complete! Check the voice_samples directory.")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to run voice preview: {str(e)}")
                self.status_var.set("Voice preview failed")

        threading.Thread(target=run_preview, daemon=True).start()

    def instant_preview(self):
        """Generate instant preview with current settings"""
        def run_instant_preview():
            try:
                from tts_engine import TTSEngine
                from pathlib import Path

                self.status_var.set("Generating instant preview...")

                # Get current settings
                voice = self.kokoro_voice_var.get()
                lang_code = self.kokoro_lang_code_var.get().split()[0] if ' - ' in self.kokoro_lang_code_var.get() else self.kokoro_lang_code_var.get()
                speed = self.kokoro_speed_var.get()

                # Create preview directory
                preview_dir = Path('output/preview')
                preview_dir.mkdir(parents=True, exist_ok=True)

                # Generate preview
                logging.info(f"Generating instant preview: voice={voice}, speed={speed}")
                tts = TTSEngine(output_dir=str(preview_dir))
                preview_path = tts.generate_preview(voice=voice, lang_code=lang_code, speed=speed)

                self.root.after(0, lambda p=preview_path: self.instant_preview_complete(p))
            except Exception as e:
                self.root.after(0, lambda err=str(e): self.instant_preview_failed(err))

        threading.Thread(target=run_instant_preview, daemon=True).start()

    def instant_preview_complete(self, preview_path):
        """Handle successful instant preview"""
        self.status_var.set("Preview ready!")
        messagebox.showinfo("Instant Preview",
                           f"Preview generated successfully!\n\n"
                           f"File: {preview_path}\n\n"
                           f"The audio file has been saved and can be played with your media player.\n"
                           f"Adjust the speed slider and try again if needed.")

    def instant_preview_failed(self, error_msg):
        """Handle instant preview failure"""
        self.status_var.set("Preview failed")
        messagebox.showerror("Error", f"Failed to generate preview:\n{error_msg}")

    def toggle_character_voice_settings(self):
        """Enable/disable character voice settings based on checkbox"""
        enabled = self.enable_character_voices_var.get()
        state = tk.NORMAL if enabled else tk.DISABLED

        # Enable/disable all character voice controls
        self.narrator_voice_combo.config(state=state)
        self.auto_assign_check.config(state=state)
        self.default_male_voice_combo.config(state=state)
        self.default_female_voice_combo.config(state=state)
        self.dialogue_pause_scale.config(state=state)
        self.character_voice_mappings_text.config(state=state)

    def _extract_first_url(self):
        """Extract first URL from URL textbox."""
        urls_text = self.urls_text.get("1.0", tk.END).strip()
        urls = [url.strip() for url in urls_text.split("\n") if url.strip()]
        return urls[0] if urls else None

    def _get_cdp_port(self):
        """Extract CDP port from URL field."""
        cdp_url = self.browser_cdp_url_var.get().strip() or "http://127.0.0.1:9222"
        parsed = urlparse(cdp_url)
        try:
            port = parsed.port
        except ValueError as exc:
            raise ValueError(f"Invalid port in CDP URL: {cdp_url}") from exc
        if port is None:
            raise ValueError(f"Invalid CDP URL (missing port): {cdp_url}")
        return port

    def _get_cdp_host(self):
        """Extract CDP host from URL field."""
        cdp_url = self.browser_cdp_url_var.get().strip() or "http://127.0.0.1:9222"
        parsed = urlparse(cdp_url)
        if not parsed.hostname:
            raise ValueError(f"Invalid CDP URL (missing host): {cdp_url}")
        return parsed.hostname

    def _get_browser_launch_urls(self, target_url=None):
        """Build the initial URLs for a CDP browser launch."""
        launch_urls = []
        if self.allow_edge_signin_var.get():
            launch_urls.append(self.EDGE_SIGNIN_URL)

        first_url = target_url or self._extract_first_url()
        if first_url and first_url not in launch_urls:
            launch_urls.append(first_url)

        return launch_urls

    def _should_show_browser_launch_tip(self, launch_urls):
        """Return True when the launch did not include a target content URL."""
        return not launch_urls or (
            len(launch_urls) == 1 and launch_urls[0] == self.EDGE_SIGNIN_URL
        )

    def _resolve_browser_executable(self, browser_name):
        """Resolve Edge browser executable path per platform."""
        system = platform.system().lower()

        if system == 'windows':
            candidates = [
                r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
                shutil.which("msedge"),
            ]
        elif system == 'darwin':
            candidates = [
                "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
                shutil.which("msedge"),
            ]
        else:
            candidates = [
                shutil.which("microsoft-edge"),
                shutil.which("microsoft-edge-stable"),
                shutil.which("msedge"),
            ]

        for candidate in candidates:
            if candidate and Path(candidate).exists():
                return candidate
        return None

    def open_browser_for_cloudflare(self, target_url=None):
        """Open Edge with remote debugging enabled for CDP attach."""
        try:
            browser_name = "Edge"
            cdp_port = self._get_cdp_port()
            cdp_host = self._get_cdp_host()
            cdp_url = self.browser_cdp_url_var.get().strip() or "http://127.0.0.1:9222"
            existing_browser = self._detect_existing_cdp_browser()
            if existing_browser:
                detected_name = existing_browser.get("Browser", browser_name)
                self.use_existing_browser_var.set(True)
                self.status_var.set(f"Using existing CDP browser at {cdp_url}")
                messagebox.showinfo(
                    "Browser Already Available",
                    "\n".join([
                        f"Detected an existing browser with CDP enabled: {detected_name}",
                        "",
                        "The app will reuse that browser session instead of opening a new one.",
                        "Leave the browser open and click Start Conversion when ready.",
                    ]),
                )
                return

            browser_executable = self._resolve_browser_executable(browser_name)

            if not browser_executable:
                raise FileNotFoundError(
                    f"Could not find Edge executable on this system. "
                    f"Please install Microsoft Edge browser."
                )
            profile_dir = self._prepare_cdp_user_data_dir()

            command = [
                browser_executable,
                f"--remote-debugging-port={cdp_port}",
                f"--remote-debugging-address={cdp_host}",
                f"--user-data-dir={profile_dir}",
                "--new-window",
            ]
            if not self.allow_edge_signin_var.get():
                command.append("--guest")

            launch_urls = self._get_browser_launch_urls(target_url)
            if launch_urls:
                command.extend(launch_urls)

            self._cleanup_browser_process()
            self.browser_process = subprocess.Popen(
                command,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            if not self._wait_for_cdp_browser(timeout_seconds=self.CDP_WAIT_TIMEOUT_SECONDS):
                self._cleanup_browser_process()
                raise RuntimeError(
                    "Edge opened but CDP endpoint did not become available.\n\n"
                    "Close all Edge windows and click 'Open Edge with CDP' again.\n"
                    "If needed, set CDP URL to a free port (for example http://127.0.0.1:9223)."
                )
            self.use_existing_browser_var.set(True)
            self.status_var.set(f"{browser_name} opened with CDP on port {cdp_port}")

            message = [
                f"{browser_name} launched successfully with remote debugging.",
                "",
                "Next steps:",
            ]
            if self.allow_edge_signin_var.get():
                message.extend([
                    "1) Sign in to your Edge/Microsoft account if you want to use that temporary profile.",
                    "2) Open the target site and log in there if needed.",
                    "3) Complete any Cloudflare challenge in that same browser window.",
                    "4) Leave that browser window open.",
                    "5) Ensure 'Attach to existing Edge browser' is checked.",
                    "6) Click Start Conversion in this app.",
                ])
            else:
                message.extend([
                    "1) In the opened browser window, log in to the target site if needed.",
                    "2) Complete any Cloudflare challenge in that same browser window.",
                    "3) Leave that browser window open.",
                    "4) Ensure 'Attach to existing Edge browser' is checked.",
                    "5) Click Start Conversion in this app.",
                ])
            if self._should_show_browser_launch_tip(launch_urls):
                message.append("")
                message.append("Tip: Paste at least one URL in the Converter tab to auto-open it here.")

            messagebox.showinfo("Browser Opened", "\n".join(message))
        except Exception as e:
            messagebox.showerror("Browser Launch Failed", str(e))
            self.status_var.set("Failed to open browser")

    def _detect_existing_cdp_browser(self):
        """Return CDP version metadata when a browser is already listening."""
        cdp_url = self.browser_cdp_url_var.get().strip() or "http://127.0.0.1:9222"
        endpoint = cdp_url.rstrip("/") + "/json/version"
        request = urllib.request.Request(endpoint, headers={"User-Agent": APP_USER_AGENT})
        try:
            with urllib.request.urlopen(request, timeout=2) as response:
                if response.status != 200:
                    logging.debug("CDP probe returned status %s for %s", response.status, endpoint)
                    return None
                payload = response.read().decode("utf-8", errors="replace")
        except (urllib.error.URLError, TimeoutError, ValueError) as exc:
            logging.debug("CDP probe failed for %s: %s", endpoint, exc)
            return None

        try:
            import json
            browser_info = json.loads(payload)
        except Exception as exc:
            logging.debug("Failed to parse CDP probe response from %s: %s", endpoint, exc)
            return None

        if not isinstance(browser_info, dict):
            return None

        websocket_url = browser_info.get("webSocketDebuggerUrl")
        if not websocket_url:
            return None
        logging.info("Detected existing CDP browser at %s", cdp_url)
        return browser_info

    def _cleanup_browser_process(self):
        """Clean up launched browser process if still running."""
        if self.browser_process and self.browser_process.poll() is None:
            try:
                self.browser_process.terminate()
                self.browser_process.wait(timeout=self.BROWSER_CLEANUP_TIMEOUT_SECONDS)
            except (subprocess.TimeoutExpired, OSError):
                try:
                    self.browser_process.kill()
                except OSError:
                    pass
        self.browser_process = None

    def _prepare_cdp_user_data_dir(self):
        """Create a clean profile directory for CDP-enabled browser launch."""
        self._cleanup_browser_profile_dir()
        self.browser_profile_dir = tempfile.mkdtemp(prefix="webtoebook-edge-cdp-")
        return self.browser_profile_dir

    def _cleanup_browser_profile_dir(self):
        """Best-effort cleanup of temporary browser profile directory."""
        if not self.browser_profile_dir:
            return
        profile_dir = self.browser_profile_dir
        self.browser_profile_dir = None
        try:
            shutil.rmtree(profile_dir)
        except Exception as exc:
            logging.warning("Failed to remove temporary browser profile directory %s: %s", profile_dir, exc)

    def _wait_for_cdp_browser(self, timeout_seconds):
        """Wait until CDP endpoint responds with browser metadata."""
        deadline = time.time() + timeout_seconds
        while time.time() < deadline:
            if self._detect_existing_cdp_browser():
                return True
            time.sleep(self.CDP_POLL_INTERVAL_SECONDS)
        logging.warning(
            "Timed out waiting for CDP browser endpoint after %ss at %s",
            timeout_seconds,
            self.browser_cdp_url_var.get().strip() or "http://127.0.0.1:9222",
        )
        return False

    def on_window_close(self):
        """Handle GUI close event."""
        self._cleanup_browser_process()
        self._cleanup_browser_profile_dir()
        self.root.destroy()

    def show_browser_setup_instructions(self):
        """Show detailed browser attach instructions."""
        cdp_url = self.browser_cdp_url_var.get().strip() or "http://127.0.0.1:9222"
        browser_name = self.browser_choice_var.get().strip() or "Edge"

        instructions = (
            "Step-by-step setup for Cloudflare-protected sites:\n\n"
            "1) Go to Browser Connection tab.\n"
            "2) Enable 'Attach to existing Edge browser'.\n"
            f"3) Set CDP URL (current: {cdp_url}).\n"
            "4) Optional: enable Edge account sign-in if you want the launched temporary profile to sign in.\n"
            "5) Click 'Open Edge with CDP'.\n"
            "6) In the opened browser window:\n"
            "   - If you enabled Edge sign-in, finish that first\n"
            "   - Open your target chapter/page (tip: paste the URL in the Converter tab first to auto-open it here)\n"
            "   - Log in if required\n"
            "   - Complete any Cloudflare check\n"
            "7) Keep that browser window open.\n"
            "8) Return to this app and click Start Conversion.\n"
            "9) If attach fails, verify the CDP URL/port and try again.\n"
        )

        messagebox.showinfo("Browser Setup Instructions", instructions)

    def get_config(self):
        """Build Config object from GUI settings"""
        css_selectors = [line.strip() for line in self.css_text.get("1.0", tk.END).strip().split("\n")
                        if line.strip()]

        # Parse translation rules if translation is enabled
        translation_rules = None
        character_genders = None

        if self.enable_translation_var.get():
            try:
                rules_text = self.translation_rules_text.get("1.0", tk.END).strip()
                # Remove comment lines and parse
                clean_lines = [line for line in rules_text.split('\n') if line.strip() and not line.strip().startswith('#')]
                if clean_lines:
                    rules_yaml = '\n'.join(clean_lines)
                    translation_rules = yaml.safe_load(rules_yaml) if rules_yaml else None
            except Exception as e:
                logging.warning(f"Failed to parse translation rules: {e}")
                translation_rules = None

            # Parse character gender mapping
            try:
                char_text = self.character_gender_text.get("1.0", tk.END).strip()
                char_lines = [line for line in char_text.split('\n') if line.strip() and not line.strip().startswith('#')]
                if char_lines:
                    char_yaml = '\n'.join(char_lines)
                    character_genders = yaml.safe_load(char_yaml) if char_yaml else None
            except Exception as e:
                logging.warning(f"Failed to parse character genders: {e}")
                character_genders = None

        character_voice_mappings = None
        if self.enable_character_voices_var.get():
            try:
                mappings_text = self.character_voice_mappings_text.get("1.0", tk.END).strip()
                mappings_lines = [line for line in mappings_text.split('\n') if line.strip() and not line.strip().startswith('#')]
                if mappings_lines:
                    mappings_yaml = '\n'.join(mappings_lines)
                    character_voice_mappings = yaml.safe_load(mappings_yaml) if mappings_yaml else None
            except Exception as e:
                logging.warning(f"Failed to parse character voice mappings: {e}")
                character_voice_mappings = None

        browser_cdp_url = self.browser_cdp_url_var.get().strip() or "http://127.0.0.1:9222"
        config = Config(
            kokoro_voice=self.kokoro_voice_var.get(),
            kokoro_lang_code=self.kokoro_lang_code_var.get().split()[0] if ' - ' in self.kokoro_lang_code_var.get() else self.kokoro_lang_code_var.get(),
            kokoro_speed=self.kokoro_speed_var.get(),
            output_dir=self.output_var.get(),
            epub_title=self.title_var.get(),
            epub_author=self.author_var.get(),
            speech_rate=self.speech_rate_var.get(),
            max_chapters=self.max_chapters_var.get(),
            max_duration=self.max_duration_var.get(),
            start_chapter=self.start_chapter_var.get(),
            end_chapter=self.end_chapter_var.get(),
            generate_per_chapter_audio=self.per_chapter_audio_var.get(),
            css_selectors=css_selectors if css_selectors else None,
            use_visual_order=self.use_visual_order_var.get(),
            wait_for_js=self.wait_for_js_var.get(),
            use_existing_browser=self.use_existing_browser_var.get(),
            browser_cdp_url=browser_cdp_url,
            allow_edge_signin=self.allow_edge_signin_var.get(),
            remove_overlays=self.remove_overlays_var.get(),
            browser_timeout=self.browser_timeout_var.get(),
            # Translation settings
            enable_translation=self.enable_translation_var.get(),
            source_language=self.source_language_var.get(),
            target_language=self.target_language_var.get(),
            translation_api_url=self.translation_api_url_var.get(),
            translation_api_key=self.translation_api_key_var.get() if self.translation_api_key_var.get() else None,
            translation_rules=translation_rules,
            character_genders=character_genders,
            # Character voice settings
            enable_character_voices=self.enable_character_voices_var.get(),
            narrator_voice=self.narrator_voice_var.get(),
            auto_assign_character_voices=self.auto_assign_voices_var.get(),
            character_voice_mappings=character_voice_mappings,
            default_male_voice=self.default_male_voice_var.get(),
            default_female_voice=self.default_female_voice_var.get(),
            dialogue_pause=self.dialogue_pause_var.get()
            ,
            # Dialogue detector LLM settings
            dialogue_llm_mode=self.dialogue_llm_mode_var.get(),
            dialogue_llm_model=self.dialogue_llm_model_var.get().strip() or "mistral:instruct",
            dialogue_llm_url=self.dialogue_llm_url_var.get().strip() or "http://localhost:11434/api/chat",
            dialogue_llm_timeout=self.dialogue_llm_timeout_var.get(),
            dialogue_llm_strict_quotes=self.dialogue_llm_strict_quotes_var.get(),
            character_manual_review=self.character_manual_review_var.get(),
            character_review_low_confidence_threshold=self.character_review_low_conf_var.get(),
        )
        return config

    def load_config_yaml(self):
        """Load settings from config.yaml"""
        try:
            config = Config.from_yaml(str(CONFIG_PATH))
            self.title_var.set(config.epub_title)
            self.author_var.set(config.epub_author)
            self.output_var.set(config.output_dir)
            self.kokoro_voice_var.set(config.kokoro_voice)
            self.kokoro_lang_code_var.set(f"{config.kokoro_lang_code} - " + {
                "a": "American English",
                "b": "British English",
                "e": "Spanish",
                "f": "French",
                "h": "Hindi",
                "i": "Italian",
                "j": "Japanese",
                "p": "Portuguese",
                "z": "Mandarin"
            }.get(config.kokoro_lang_code, "American English"))
            self.kokoro_speed_var.set(config.kokoro_speed)
            self.speech_rate_var.set(config.speech_rate)
            self.max_chapters_var.set(config.max_chapters)
            self.max_duration_var.set(config.max_duration)

            # Load chapter range settings
            self.start_chapter_var.set(config.start_chapter)
            self.end_chapter_var.set(config.end_chapter)
            self.per_chapter_audio_var.set(config.generate_per_chapter_audio)

            # Load translation settings
            self.enable_translation_var.set(config.enable_translation)
            self.source_language_var.set(config.source_language)
            self.target_language_var.set(config.target_language)
            self.translation_api_url_var.set(config.translation_api_url)
            if config.translation_api_key:
                self.translation_api_key_var.set(config.translation_api_key)

            if config.css_selectors:
                self.css_text.delete("1.0", tk.END)
                self.css_text.insert(tk.END, "\n".join(config.css_selectors))

            # Load visual order setting
            self.use_visual_order_var.set(config.use_visual_order)
            self.wait_for_js_var.set(config.wait_for_js)
            self.use_existing_browser_var.set(config.use_existing_browser)
            self.browser_cdp_url_var.set(config.browser_cdp_url)
            self.allow_edge_signin_var.set(config.allow_edge_signin)
            self.remove_overlays_var.set(config.remove_overlays)
            self.browser_timeout_var.set(config.browser_timeout)

            # Load character voice settings
            self.enable_character_voices_var.set(config.enable_character_voices)
            self.narrator_voice_var.set(config.narrator_voice)
            self.auto_assign_voices_var.set(config.auto_assign_character_voices)
            self.default_male_voice_var.set(config.default_male_voice)
            self.default_female_voice_var.set(config.default_female_voice)
            self.dialogue_pause_var.set(config.dialogue_pause)

            # Load dialogue detector LLM settings
            self.dialogue_llm_mode_var.set(config.dialogue_llm_mode)
            self.dialogue_llm_model_var.set(config.dialogue_llm_model)
            self.dialogue_llm_url_var.set(config.dialogue_llm_url)
            self.dialogue_llm_timeout_var.set(config.dialogue_llm_timeout)
            self.dialogue_llm_strict_quotes_var.set(config.dialogue_llm_strict_quotes)
            self.character_manual_review_var.set(config.character_manual_review)
            self.character_review_low_conf_var.set(config.character_review_low_confidence_threshold)

            # Load character voice mappings if present
            if config.character_voice_mappings:
                self.character_voice_mappings_text.config(state=tk.NORMAL)
                self.character_voice_mappings_text.delete("1.0", tk.END)
                mappings_yaml = yaml.dump(config.character_voice_mappings, default_flow_style=False)
                self.character_voice_mappings_text.insert(tk.END, mappings_yaml)
                if not config.enable_character_voices:
                    self.character_voice_mappings_text.config(state=tk.DISABLED)

            # Update UI state based on enable_character_voices
            self.toggle_character_voice_settings()

            messagebox.showinfo("Success", "Configuration loaded from config.yaml")
        except FileNotFoundError:
            messagebox.showerror("Error", "config.yaml not found")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load config: {str(e)}")

    def save_config_yaml(self):
        """Save current settings to config.yaml"""
        try:
            config = self.get_config()

            # Create YAML content
            yaml_content = f"""# Web to Ebook Converter Configuration File
# ==========================================

# Book Information
epub_title: "{config.epub_title}"
epub_author: "{config.epub_author}"

# Output Settings
output_dir: "{config.output_dir}"

# Translation Settings
enable_translation: {str(config.enable_translation).lower()}
source_language: "{config.source_language}"
target_language: "{config.target_language}"
translation_api_url: "{config.translation_api_url}"
translation_api_key: {config.translation_api_key if config.translation_api_key else 'null'}

# Kokoro TTS Settings
kokoro_voice: "{config.kokoro_voice}"
kokoro_lang_code: "{config.kokoro_lang_code}"
kokoro_speed: {config.kokoro_speed}

# Speech Rate (for synchronized text display)
speech_rate: {config.speech_rate}

# Stop Conditions
max_chapters: {config.max_chapters}
max_duration: {config.max_duration}

# Chapter Range
start_chapter: {config.start_chapter}
end_chapter: {config.end_chapter}
generate_per_chapter_audio: {str(config.generate_per_chapter_audio).lower()}

# Browser Scraper Settings
wait_for_js: {str(config.wait_for_js).lower()}
use_existing_browser: {str(config.use_existing_browser).lower()}
browser_cdp_url: "{config.browser_cdp_url}"
allow_edge_signin: {str(config.allow_edge_signin).lower()}
remove_overlays: {str(config.remove_overlays).lower()}
browser_timeout: {config.browser_timeout}

# Dialogue Detector LLM Settings
dialogue_llm_mode: "{config.dialogue_llm_mode}"
dialogue_llm_model: "{config.dialogue_llm_model}"
dialogue_llm_url: "{config.dialogue_llm_url}"
dialogue_llm_timeout: {config.dialogue_llm_timeout}
dialogue_llm_strict_quotes: {str(config.dialogue_llm_strict_quotes).lower()}
character_manual_review: {str(config.character_manual_review).lower()}
character_review_low_confidence_threshold: {config.character_review_low_confidence_threshold}

# Content Extraction
css_selectors:
"""
            for selector in config.css_selectors:
                yaml_content += f'  - "{selector}"\n'

            # Add visual order setting
            yaml_content += f"\n# Visual Order Extraction\nuse_visual_order: {str(config.use_visual_order).lower()}\n"

            # Add translation rules if present
            if config.translation_rules:
                yaml_content += "\n# Custom Translation Rules\ntranslation_rules:\n"
                for rule in config.translation_rules:
                    yaml_content += f'  - pattern: "{rule.get("pattern", "")}"\n'
                    yaml_content += f'    replacement: "{rule.get("replacement", "")}"\n'
                    yaml_content += f'    is_regex: {str(rule.get("is_regex", False)).lower()}\n'
                    yaml_content += f'    case_sensitive: {str(rule.get("case_sensitive", True)).lower()}\n'

            with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
                f.write(yaml_content)

            messagebox.showinfo("Success", "Configuration saved to config.yaml")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save config: {str(e)}")

    def start_conversion(self):
        """Start the conversion process"""
        # Get URLs
        urls_text = self.urls_text.get("1.0", tk.END).strip()
        if not urls_text:
            messagebox.showwarning("Warning", "Please enter at least one URL")
            return

        urls = [url.strip() for url in urls_text.split("\n") if url.strip()]

        if not urls:
            messagebox.showwarning("Warning", "Please enter at least one valid URL")
            return

        # Update UI
        self.is_processing = True
        self.start_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)
        self.progress_bar.config(mode='determinate')
        self.progress_var.set(0)
        self.status_var.set("Processing...")

        # Start processing in separate thread
        def process():
            try:
                config = self.get_config()
                from main import WebToEbookApp
                app = WebToEbookApp(config)

                # Wrap process with progress tracking
                result = self._process_with_progress(app, urls, config.epub_title)

                self.root.after(0, lambda r=result: self.conversion_complete(r))
            except Exception as e:
                self.root.after(0, lambda err=str(e): self.conversion_failed(err))

        threading.Thread(target=process, daemon=True).start()

    def _process_with_progress(self, app, urls, output_name):
        """Process with detailed progress updates"""
        total_steps = 5 if app.translator else 4
        current_step = 0

        def update_progress(step_name):
            nonlocal current_step
            current_step += 1
            progress = (current_step / total_steps) * 100
            self.root.after(0, lambda p=progress: self.progress_var.set(p))
            self.root.after(0, lambda s=step_name, cs=current_step, ts=total_steps:
                self.status_var.set(f"Step {cs}/{ts}: {s}"))
            logging.info(f"Progress: {step_name}")

        # Step 1: Scraping
        update_progress("Scraping web pages")
        chapters = app.scraper.scrape_chapters(urls)

        # Validate chapters
        if not chapters:
            raise ValueError("No chapters were successfully scraped")

        chapters_with_content = [ch for ch in chapters if ch.get('content', '').strip()]
        if not chapters_with_content:
            raise ValueError("All chapters are empty")

        if len(chapters_with_content) < len(chapters):
            empty_count = len(chapters) - len(chapters_with_content)
            logging.warning(f"{empty_count} chapters had no content and will be skipped")
            chapters = chapters_with_content

        # Show preview dialog and get user approval
        preview_approved = self._show_preview_dialog(chapters)
        if not preview_approved:
            raise ValueError("User cancelled after preview")

        # Step 2: Translation (if enabled)
        if app.translator:
            update_progress("Translating content")
            chapters = app.translator.translate_chapters(chapters)

        # Step 3: Creating EPUB
        update_progress("Creating EPUB")
        epub_path = app.ebook_gen.create_epub(chapters, output_name, app.config.epub_author)

        # Step 4: Character checklist + preview
        update_progress("Building character checklist and dialogue preview")
        character_artifacts = app._generate_character_artifacts(chapters, output_name)

        # Step 4b: Conditional character review popup before audio generation
        raw_checklist = character_artifacts.get('character_checklist', [])
        delta_summary = character_artifacts.get('character_delta_summary', {})
        low_confidence_new = delta_summary.get('low_confidence_new_characters', [])
        gender_changes = delta_summary.get('gender_changes', [])
        needs_review = (
            app.config.character_manual_review
            or bool(low_confidence_new)
            or bool(gender_changes)
        )
        if needs_review:
            confirmed_characters = self._show_character_review_dialog(
                raw_checklist, book_title=output_name
            )
            if confirmed_characters is None:
                raise ValueError("User cancelled at character review")
        else:
            confirmed_characters = raw_checklist

        # Persist the confirmed characters to the book database so that future
        # chapters (and the dialogue detector) know about them.
        character_artifacts['character_checklist'] = confirmed_characters
        review_decisions = app._collect_review_decisions(character_artifacts)
        db_path = app.character_db.save_characters(
            output_name,
            confirmed_characters,
            review_decisions=review_decisions,
        )
        character_artifacts['character_database_file'] = str(db_path)

        # Step 5: Generating audio
        audio_chapters = app._prepare_chapters_for_audio(chapters)
        update_progress("Generating audio")

        def progress_update(msg):
            """Thread-safe progress update callback"""
            self.root.after(0, lambda m=msg: self.status_var.set(m))

        kwargs = {
            'voice': app.config.kokoro_voice,
            'lang_code': app.config.kokoro_lang_code,
            'speed': app.config.kokoro_speed,
            'progress_callback': progress_update
        }

        dialogue_segments_by_chapter = []
        voice_mappings = {}
        debug_report_path = None

        if app.character_voice_manager:
            logging.info("Character voices enabled (GUI) - analyzing text for dialogue segmentation")
            combined_text = '\n\n'.join([ch['content'] for ch in audio_chapters])
            known_character_records = app.character_db.load_records(output_name)
            known_characters = app._get_known_characters_for_book(output_name)

            assignments = app.character_voice_manager.analyze_and_assign_voices(
                combined_text,
                known_characters=known_characters,
                manual_mappings=app.config.character_voice_mappings,
                known_character_records=known_character_records,
            )
            voice_mappings = {
                char_name: assignment.voice_name
                for char_name, assignment in assignments.items()
            }

            detector = app._create_dialogue_detector(llm_mode_override="full")
            for chapter in audio_chapters:
                segments = detector.detect_dialogue_in_text(
                    chapter['content'],
                    known_characters=list(assignments.keys()),
                    known_character_records=known_character_records,
                )
                dialogue_segments_by_chapter.append(segments)

            app._log_multispeaker_debug_summary(
                output_name,
                assignments,
                voice_mappings,
                dialogue_segments_by_chapter,
                audio_chapters,
            )
            debug_report_path = app._write_multispeaker_debug_report(
                output_name,
                assignments=assignments,
                voice_mappings=voice_mappings,
                dialogue_segments_by_chapter=dialogue_segments_by_chapter,
                audio_chapters=audio_chapters,
            )
        else:
            debug_report_path = app._write_multispeaker_debug_report(output_name)

        audio_files = []
        chapter_info = []

        if app.config.generate_per_chapter_audio:
            total_audio_chapters = len(audio_chapters)
            for i, chapter in enumerate(audio_chapters, 1):
                # Update status with proper variable capture
                self.root.after(0, lambda chapter_num=i, total_chapters=total_audio_chapters:
                    self.status_var.set(f"Generating audio for chapter {chapter_num}/{total_chapters}"))

                chapter_text = chapter['content']
                if app.config.max_duration > 0:
                    chapter_text = app._apply_duration_limit(chapter_text, app.config.max_duration)

                chapter_filename = f'{output_name}_chapter_{i:03d}.wav'
                if app.character_voice_manager and dialogue_segments_by_chapter:
                    if i - 1 < len(dialogue_segments_by_chapter):
                        segments = dialogue_segments_by_chapter[i - 1]
                        audio_path = app.tts.generate_multi_voice_audio(
                            segments,
                            chapter_filename,
                            voice_mappings,
                            dialogue_pause=app.config.dialogue_pause,
                            **kwargs,
                        )
                    else:
                        logging.warning(
                            "Missing dialogue segments for chapter %d; falling back to narrator-only audio",
                            i,
                        )
                        audio_path = app.tts.generate_audio(chapter_text, chapter_filename, **kwargs)
                else:
                    audio_path = app.tts.generate_audio(chapter_text, chapter_filename, **kwargs)
                audio_files.append(str(audio_path))
                chapter_info.append({
                    'number': i,
                    'title': chapter.get('title', f'Chapter {i}'),
                    'audio': str(audio_path),
                    'text': chapter_text
                })

            # Create combined audio
            combined_text = '\n\n'.join([ch['content'] for ch in audio_chapters])
            if app.config.max_duration > 0:
                combined_text = app._apply_duration_limit(combined_text, app.config.max_duration)

            self.root.after(0, lambda: self.status_var.set("Creating combined audio file"))
            if app.character_voice_manager and dialogue_segments_by_chapter:
                all_segments = []
                for segments in dialogue_segments_by_chapter:
                    all_segments.extend(segments)
                combined_audio_path = app.tts.generate_multi_voice_audio(
                    all_segments,
                    f'{output_name}_complete.wav',
                    voice_mappings,
                    dialogue_pause=app.config.dialogue_pause,
                    **kwargs,
                )
            else:
                combined_audio_path = app.tts.generate_audio(combined_text, f'{output_name}_complete.wav', **kwargs)
        else:
            combined_text = '\n\n'.join([ch['content'] for ch in audio_chapters])
            if app.config.max_duration > 0:
                combined_text = app._apply_duration_limit(combined_text, app.config.max_duration)

            if app.character_voice_manager and dialogue_segments_by_chapter:
                all_segments = []
                for segments in dialogue_segments_by_chapter:
                    all_segments.extend(segments)
                combined_audio_path = app.tts.generate_multi_voice_audio(
                    all_segments,
                    f'{output_name}.wav',
                    voice_mappings,
                    dialogue_pause=app.config.dialogue_pause,
                    **kwargs,
                )
            else:
                combined_audio_path = app.tts.generate_audio(combined_text, f'{output_name}.wav', **kwargs)

            for i, chapter in enumerate(audio_chapters, 1):
                chapter_info.append({
                    'number': i,
                    'title': chapter.get('title', f'Chapter {i}'),
                    'audio': str(combined_audio_path),
                    'text': chapter['content']
                })

        # Generate synchronized text
        self.root.after(0, lambda: self.status_var.set("Generating synchronized text display"))

        if app.config.generate_per_chapter_audio:
            sync_html_path = app.sync_text_gen.generate_chapter_html(
                chapter_info, f'{output_name}_sync.html',
                title=output_name, speech_rate=app.config.speech_rate
            )
        else:
            sync_html_path = app.sync_text_gen.generate_html(
                combined_text, f'{output_name}.wav', f'{output_name}_sync.html',
                title=output_name, speech_rate=app.config.speech_rate
            )

        result = {
            'epub': str(epub_path),
            'audio': str(combined_audio_path),
            'sync_html': str(sync_html_path),
            'chapters': len(chapters)
        }
        if debug_report_path:
            result['multispeaker_debug_file'] = debug_report_path
        result.update(character_artifacts)

        if app.config.generate_per_chapter_audio:
            result['chapter_audio_files'] = audio_files
            result['chapter_info'] = chapter_info

        return result

    def stop_conversion(self):
        """Stop the conversion process"""
        self.is_processing = False
        self.progress_var.set(0)
        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.status_var.set("Stopped")
        logging.warning("Conversion stopped by user")

    def conversion_complete(self, result):
        """Handle successful conversion"""
        self.progress_var.set(100)
        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.status_var.set("Conversion complete!")

        message = f"Conversion completed successfully!\n\n"
        message += f"Chapters processed: {result['chapters']}\n"
        message += f"EPUB: {result['epub']}\n"
        message += f"Audio: {result['audio']}\n"
        if 'sync_html' in result:
            message += f"Synchronized Text: {result['sync_html']}\n"
            message += f"\n💡 Open the HTML file to read along with the audio!"
        if 'character_checklist_file' in result:
            message += f"\n\nCharacter Checklist: {result['character_checklist_file']}"
        if 'character_preview_html' in result:
            message += f"\nCharacter Dialogue Preview: {result['character_preview_html']}"
        if result.get('character_checklist'):
            preview_lines = []
            for entry in result['character_checklist'][:8]:
                preview_lines.append(f"{entry['name']} ({entry['gender']})")
            message += f"\n\nIdentified Characters: {', '.join(preview_lines)}"
            if len(result['character_checklist']) > 8:
                message += ", ..."
        else:
            message += "\n\nIdentified Characters: none"

        messagebox.showinfo("Success", message)

    def conversion_failed(self, error_msg):
        """Handle conversion failure"""
        self.progress_var.set(0)
        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.status_var.set("Conversion failed")

        messagebox.showerror("Error", f"Conversion failed:\n{error_msg}")

    def clear_log(self):
        """Clear the log display"""
        self.log_text.configure(state='normal')
        self.log_text.delete("1.0", tk.END)
        self.log_text.configure(state='disabled')

    def _show_preview_dialog(self, chapters, max_preview=3):
        """Show a preview dialog with scraped chapter text.

        Args:
            chapters: List of chapter dictionaries
            max_preview: Maximum number of chapters to preview initially

        Returns:
            True if user approves, False if cancelled
        """
        preview_result = {'approved': False}

        def on_approve():
            preview_result['approved'] = True
            dialog.destroy()

        def on_cancel():
            preview_result['approved'] = False
            dialog.destroy()

        # Create dialog window
        dialog = tk.Toplevel(self.root)
        dialog.title("Chapter Preview - Verify Scraped Text")
        dialog.geometry("800x600")
        dialog.transient(self.root)
        dialog.grab_set()

        # Main frame
        main_frame = ttk.Frame(dialog, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        dialog.columnconfigure(0, weight=1)
        dialog.rowconfigure(0, weight=1)

        # Title
        title_label = ttk.Label(main_frame,
                                text=f"📖 Preview of First {min(max_preview, len(chapters))} Chapters",
                                font=('TkDefaultFont', 12, 'bold'))
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 10), sticky=tk.W)

        subtitle_label = ttk.Label(main_frame,
                                   text="Please verify that the text was scraped correctly before proceeding.",
                                   foreground="gray")
        subtitle_label.grid(row=1, column=0, columnspan=2, pady=(0, 10), sticky=tk.W)

        # Create notebook for chapters
        notebook = ttk.Notebook(main_frame)
        notebook.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))

        # Add tabs for each chapter
        preview_count = min(max_preview, len(chapters))
        for i in range(preview_count):
            chapter = chapters[i]
            title = chapter.get('title', f'Chapter {i+1}')
            content = chapter.get('content', '')
            word_count = len(content.split())

            # Create tab
            tab_frame = ttk.Frame(notebook, padding="10")
            notebook.add(tab_frame, text=f"Ch {i+1}")

            # Chapter info
            info_frame = ttk.Frame(tab_frame)
            info_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))

            ttk.Label(info_frame, text=f"Title: {title}",
                     font=('TkDefaultFont', 10, 'bold')).pack(anchor=tk.W)
            ttk.Label(info_frame, text=f"Statistics: {word_count} words, {len(content)} characters",
                     foreground="gray").pack(anchor=tk.W)

            # Content display
            content_text = scrolledtext.ScrolledText(tab_frame, wrap=tk.WORD,
                                                     width=80, height=20)
            content_text.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
            content_text.insert("1.0", content)
            content_text.configure(state='disabled')

            tab_frame.columnconfigure(0, weight=1)
            tab_frame.rowconfigure(1, weight=1)

        # Summary info
        summary_frame = ttk.Frame(main_frame)
        summary_frame.grid(row=3, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))

        summary_text = f"📊 Total chapters to process: {len(chapters)}"
        if len(chapters) > preview_count:
            summary_text += f" (showing first {preview_count})"

        ttk.Label(summary_frame, text=summary_text,
                 font=('TkDefaultFont', 10)).pack(anchor=tk.W)

        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=4, column=0, columnspan=2, pady=(10, 0))

        ttk.Button(button_frame, text="✓ Approve & Continue",
                  command=on_approve, style="Accent.TButton").pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="✗ Cancel",
                  command=on_cancel).pack(side=tk.LEFT, padx=5)

        # Configure grid weights
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(2, weight=1)

        # Center dialog on parent
        dialog.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() - dialog.winfo_width()) // 2
        y = self.root.winfo_y() + (self.root.winfo_height() - dialog.winfo_height()) // 2
        dialog.geometry(f"+{x}+{y}")

        # Wait for dialog to close
        dialog.wait_window()

        return preview_result['approved']

    def _show_character_review_dialog(self, characters, book_title=""):
        """Show an editable character review dialog before audio generation.

        Args:
            characters: List of dicts with keys: name, gender,
                        dialogue_count, mention_count.
            book_title: Optional book title for the dialog heading.

        Returns:
            Confirmed list of character dicts (name/gender only needed), or
            None if the user cancelled.
        """
        GENDER_OPTIONS = ["male", "female", "neutral", "unknown"]
        result = {'confirmed': None}

        # Working copy that we mutate via the editor widgets
        rows = [
            {
                'name': c.get('name', ''),
                'source_name': c.get('source_name', c.get('name', '')),
                'gender': c.get('gender', 'unknown'),
                'source_gender': c.get('source_gender', c.get('gender', 'unknown')),
                'dialogue_count': c.get('dialogue_count', 0),
                'mention_count': c.get('mention_count', 0),
            }
            for c in characters
            if c.get('name', '').strip()
        ]

        # ── Dialog window ────────────────────────────────────────────────────
        dialog = tk.Toplevel(self.root)
        title_suffix = f" — {book_title}" if book_title else ""
        dialog.title(f"Character Review{title_suffix}")
        dialog.geometry("760x520")
        dialog.transient(self.root)
        dialog.grab_set()

        main_frame = ttk.Frame(dialog, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        dialog.columnconfigure(0, weight=1)
        dialog.rowconfigure(0, weight=1)

        # ── Header ───────────────────────────────────────────────────────────
        ttk.Label(
            main_frame,
            text="🧑‍🤝‍🧑 Review Characters Before Audio Generation",
            font=('TkDefaultFont', 12, 'bold'),
        ).grid(row=0, column=0, columnspan=3, pady=(0, 4), sticky=tk.W)

        ttk.Label(
            main_frame,
            text=(
                "Edit names or genders as needed, then click Confirm to save and "
                "continue.  These characters will be remembered for future chapters."
            ),
            foreground="gray",
            wraplength=700,
            justify=tk.LEFT,
        ).grid(row=1, column=0, columnspan=3, pady=(0, 8), sticky=tk.W)

        # ── Treeview ─────────────────────────────────────────────────────────
        tree_frame = ttk.Frame(main_frame)
        tree_frame.grid(row=2, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S))
        main_frame.rowconfigure(2, weight=1)
        main_frame.columnconfigure(0, weight=1)

        columns = ('name', 'gender', 'dialogue_count', 'mention_count')
        tree = ttk.Treeview(
            tree_frame,
            columns=columns,
            show='headings',
            selectmode='browse',
            height=14,
        )
        tree.heading('name', text='Name')
        tree.heading('gender', text='Gender')
        tree.heading('dialogue_count', text='Dialogue Lines')
        tree.heading('mention_count', text='Mentions')
        tree.column('name', width=220, minwidth=120)
        tree.column('gender', width=110, minwidth=80)
        tree.column('dialogue_count', width=110, minwidth=80, anchor=tk.CENTER)
        tree.column('mention_count', width=90, minwidth=80, anchor=tk.CENTER)

        vsb = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        tree.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        vsb.grid(row=0, column=1, sticky=(tk.N, tk.S))
        tree_frame.columnconfigure(0, weight=1)
        tree_frame.rowconfigure(0, weight=1)

        def _populate():
            tree.delete(*tree.get_children())
            for row in rows:
                tree.insert('', tk.END, values=(
                    row['name'],
                    row['gender'],
                    row['dialogue_count'],
                    row['mention_count'],
                ))

        _populate()

        # ── Inline editor ────────────────────────────────────────────────────
        # An Entry + Combobox that float over the treeview when a row is selected.
        editor_frame = tk.Frame(tree)
        name_var = tk.StringVar()
        gender_var = tk.StringVar()
        name_entry = ttk.Entry(editor_frame, textvariable=name_var, width=22)
        name_entry.grid(row=0, column=0, padx=(0, 4))
        gender_combo = ttk.Combobox(
            editor_frame,
            textvariable=gender_var,
            values=GENDER_OPTIONS,
            state='readonly',
            width=10,
        )
        gender_combo.grid(row=0, column=1)

        _editing_iid = [None]

        def _commit_editor():
            """Write editor values back to rows[] and the tree."""
            iid = _editing_iid[0]
            if iid is None:
                return
            idx = tree.index(iid)
            new_name = name_var.get().strip()
            new_gender = gender_var.get().strip().lower() or 'unknown'
            if new_gender not in GENDER_OPTIONS:
                new_gender = 'unknown'
            if new_name:
                rows[idx]['name'] = new_name
                rows[idx]['gender'] = new_gender
                tree.item(iid, values=(
                    new_name,
                    new_gender,
                    rows[idx]['dialogue_count'],
                    rows[idx]['mention_count'],
                ))
            _hide_editor()

        def _hide_editor():
            _editing_iid[0] = None
            editor_frame.place_forget()

        def _show_editor(iid):
            """Position the inline editor over the selected treeview row."""
            _commit_editor()
            _editing_iid[0] = iid
            idx = tree.index(iid)
            row = rows[idx]
            name_var.set(row['name'])
            gender_var.set(row['gender'])

            bbox_name = tree.bbox(iid, column='name')
            bbox_gender = tree.bbox(iid, column='gender')
            if not bbox_name or not bbox_gender:
                return
            x = bbox_name[0]
            y = bbox_name[1]
            w = bbox_gender[0] + bbox_gender[2] - bbox_name[0]
            h = max(bbox_name[3], bbox_gender[3])
            editor_frame.place(x=x, y=y, width=w, height=h)
            name_entry.focus_set()
            name_entry.select_range(0, tk.END)

        def _on_tree_select(event):
            sel = tree.selection()
            if sel:
                _show_editor(sel[0])

        def _on_name_entry_return(event):
            gender_combo.focus_set()

        def _on_gender_combo_return(event):
            _commit_editor()

        tree.bind('<<TreeviewSelect>>', _on_tree_select)
        name_entry.bind('<Return>', _on_name_entry_return)
        gender_combo.bind('<Return>', _on_gender_combo_return)
        gender_combo.bind('<<ComboboxSelected>>', lambda e: _commit_editor())
        # Clicking elsewhere hides the editor
        tree.bind('<Button-1>', lambda e: _commit_editor() if _editing_iid[0] else None, add='+')

        # ── Row action buttons ────────────────────────────────────────────────
        action_frame = ttk.Frame(main_frame)
        action_frame.grid(row=3, column=0, columnspan=3, pady=(6, 0), sticky=tk.W)

        def _add_character():
            _commit_editor()
            rows.append({'name': 'New Character', 'gender': 'unknown',
                         'source_name': 'New Character', 'source_gender': 'unknown',
                         'dialogue_count': 0, 'mention_count': 0,
                         'avg_dialogue_confidence': 0.0})
            _populate()
            last_iid = tree.get_children()[-1]
            tree.selection_set(last_iid)
            tree.see(last_iid)
            _show_editor(last_iid)

        def _delete_selected():
            _hide_editor()
            sel = tree.selection()
            if not sel:
                return
            idx = tree.index(sel[0])
            del rows[idx]
            _populate()

        ttk.Button(action_frame, text="➕ Add Character",
                   command=_add_character).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(action_frame, text="🗑 Delete Selected",
                   command=_delete_selected).pack(side=tk.LEFT)

        # ── Confirm / Cancel buttons ──────────────────────────────────────────
        btn_frame = ttk.Frame(main_frame)
        btn_frame.grid(row=4, column=0, columnspan=3, pady=(10, 0))

        def _on_confirm():
            _commit_editor()
            result['confirmed'] = [
                {'name': r['name'], 'gender': r['gender'],
                 'source_name': r.get('source_name', r['name']),
                 'source_gender': r.get('source_gender', r['gender']),
                 'dialogue_count': r['dialogue_count'],
                 'mention_count': r['mention_count']}
                for r in rows
                if r.get('name', '').strip()
            ]
            dialog.destroy()

        def _on_cancel():
            result['confirmed'] = None
            dialog.destroy()

        ttk.Button(btn_frame, text="✓ Confirm & Continue",
                   command=_on_confirm).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="✗ Cancel",
                   command=_on_cancel).pack(side=tk.LEFT, padx=5)

        # ── Center on parent ──────────────────────────────────────────────────
        dialog.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() - dialog.winfo_width()) // 2
        y = self.root.winfo_y() + (self.root.winfo_height() - dialog.winfo_height()) // 2
        dialog.geometry(f"+{x}+{y}")

        dialog.wait_window()
        return result['confirmed']

    # ── Library tab ───────────────────────────────────────────────────────────

    def create_library_tab(self):
        """Create the Book Library tab for tracking per-book chapter progress."""
        lib_tab = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(lib_tab, text="Library")
        lib_tab.columnconfigure(0, weight=1)
        lib_tab.rowconfigure(1, weight=2)
        lib_tab.rowconfigure(2, weight=1)

        # ── Toolbar ──────────────────────────────────────────────────────────
        toolbar = ttk.Frame(lib_tab)
        toolbar.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 6))

        ttk.Button(toolbar, text="➕ Add Book",
                   command=self._library_add_book).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="✏️ Edit",
                   command=self._library_edit_book).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="🗑 Remove",
                   command=self._library_remove_book).pack(side=tk.LEFT, padx=2)
        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=8)
        ttk.Button(toolbar, text="🔍 Check for New Chapters",
                   command=self._library_check_chapters).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="▶ Convert New Chapters",
                   command=self._library_convert_new,
                   style="Accent.TButton").pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="🔄 Check & Convert All",
                   command=self._library_check_and_convert).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="Clear Log",
                   command=self._library_clear_log).pack(side=tk.RIGHT, padx=2)

        self.lib_max_new_chapters_var = tk.IntVar(value=0)
        ttk.Label(toolbar, text="Max new/run:").pack(side=tk.RIGHT, padx=(12, 2))
        ttk.Spinbox(
            toolbar,
            from_=0,
            to=9999,
            width=7,
            textvariable=self.lib_max_new_chapters_var,
        ).pack(side=tk.RIGHT, padx=(0, 2))

        # ── Treeview ──────────────────────────────────────────────────────────
        tree_frame = ttk.LabelFrame(lib_tab, text="Books", padding="6")
        tree_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 6))
        tree_frame.columnconfigure(0, weight=1)
        tree_frame.rowconfigure(0, weight=1)

        cols = ("title", "author", "progress", "last_checked", "status")
        self.lib_tree = ttk.Treeview(
            tree_frame, columns=cols, show="headings", height=8,
            selectmode="browse",
        )
        self.lib_tree.heading("title", text="Title")
        self.lib_tree.heading("author", text="Author")
        self.lib_tree.heading("progress", text="Chapters (done / total)")
        self.lib_tree.heading("last_checked", text="Last Checked")
        self.lib_tree.heading("status", text="Status")
        self.lib_tree.column("title", width=200, minwidth=120)
        self.lib_tree.column("author", width=120, minwidth=80)
        self.lib_tree.column("progress", width=150, anchor=tk.CENTER, minwidth=100)
        self.lib_tree.column("last_checked", width=175, minwidth=120)
        self.lib_tree.column("status", width=130, minwidth=80)

        vsb = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.lib_tree.yview)
        self.lib_tree.configure(yscrollcommand=vsb.set)
        self.lib_tree.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        vsb.grid(row=0, column=1, sticky=(tk.N, tk.S))

        # Double-click opens the edit dialog.
        self.lib_tree.bind("<Double-1>", lambda _e: self._library_edit_book())

        # ── Log pane ──────────────────────────────────────────────────────────
        log_frame = ttk.LabelFrame(lib_tab, text="Library Log", padding="6")
        log_frame.grid(row=2, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)

        self.lib_log_text = scrolledtext.ScrolledText(
            log_frame, height=7, width=90,
            state="disabled",
            bg=_CLR_LOG_BG, fg=_CLR_TEXT,
            font=_FONT_MONO, relief=tk.FLAT, borderwidth=1,
            insertbackground=_CLR_TEXT,
        )
        self.lib_log_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        self._lib_is_processing = False
        self._library_refresh_tree()

    # ── Library helpers ───────────────────────────────────────────────────────

    def _get_library(self) -> BookLibrary:
        """Return a BookLibrary bound to the current output directory."""
        return BookLibrary(self.output_var.get() or "output")

    def _library_log(self, msg: str) -> None:
        """Append *msg* to the library log widget (thread-safe)."""
        def _append():
            self.lib_log_text.configure(state="normal")
            self.lib_log_text.insert(tk.END, msg + "\n")
            self.lib_log_text.configure(state="disabled")
            self.lib_log_text.see(tk.END)
        self.lib_log_text.after(0, _append)

    def _library_clear_log(self) -> None:
        self.lib_log_text.configure(state="normal")
        self.lib_log_text.delete("1.0", tk.END)
        self.lib_log_text.configure(state="disabled")

    def _library_refresh_tree(self) -> None:
        """Repopulate the library treeview from persisted data."""
        library = self._get_library()
        self.lib_tree.delete(*self.lib_tree.get_children())
        for entry in library.list_books():
            done = entry.get("last_processed_chapter", 0)
            total = entry.get("last_chapter_count", 0)
            progress = f"{done} / {total}" if total else "—"

            raw_ts = entry.get("last_checked")
            if raw_ts:
                # Show only the date+time portion (drop timezone/fractional seconds)
                checked = raw_ts[:19].replace("T", " ")
            else:
                checked = "Never"

            new_count = max(0, total - done)
            if not entry.get("last_checked"):
                status = "Not checked"
            elif new_count > 0:
                status = f"{new_count} new"
            else:
                status = "Up to date"

            self.lib_tree.insert(
                "", tk.END,
                iid=entry["book_id"],
                values=(
                    entry.get("title", ""),
                    entry.get("author", ""),
                    progress,
                    checked,
                    status,
                ),
            )

    def _library_selected_book_id(self) -> Optional[str]:
        """Return the book_id of the currently selected row, or None."""
        sel = self.lib_tree.selection()
        return sel[0] if sel else None

    def _library_add_book(self) -> None:
        data = self._library_show_book_dialog(title="Add Book to Library")
        if data is None:
            return
        library = self._get_library()
        snapshot = self._capture_settings_snapshot()
        book_id = library.add_book(
            data["title"], data["author"], data["index_url"], settings=snapshot
        )
        self._library_log(f"➕ Added: {data['title']} ({book_id})")
        self._library_refresh_tree()

    def _library_edit_book(self) -> None:
        book_id = self._library_selected_book_id()
        if not book_id:
            messagebox.showinfo("Library", "Please select a book to edit.")
            return
        library = self._get_library()
        entry = library.get_book(book_id)
        if entry is None:
            self._library_refresh_tree()
            return
        data = self._library_show_book_dialog(title="Edit Book", book_entry=entry)
        if data is None:
            return
        library.update_book(book_id, data["title"], data["author"], data["index_url"])
        self._library_log(f"✏️  Updated: {data['title']}")
        self._library_refresh_tree()

    def _library_remove_book(self) -> None:
        book_id = self._library_selected_book_id()
        if not book_id:
            messagebox.showinfo("Library", "Please select a book to remove.")
            return
        library = self._get_library()
        entry = library.get_book(book_id)
        if entry is None:
            self._library_refresh_tree()
            return
        if not messagebox.askyesno(
            "Remove Book",
            f"Remove "{entry['title']}" from the library?\n\n"
            "This only removes the tracking record — output files are kept.",
        ):
            return
        library.remove_book(book_id)
        self._library_log(f"🗑 Removed: {entry['title']}")
        self._library_refresh_tree()

    def _library_show_book_dialog(
        self, title: str = "Book", book_entry: Optional[dict] = None
    ) -> Optional[dict]:
        """Open a modal dialog to collect/edit book metadata.

        Returns a dict ``{title, author, index_url}`` on OK, or ``None`` on cancel.
        """
        result = [None]

        dialog = tk.Toplevel(self.root)
        dialog.title(title)
        dialog.geometry("520x240")
        dialog.resizable(True, False)
        dialog.transient(self.root)
        dialog.grab_set()

        frm = ttk.Frame(dialog, padding="14")
        frm.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        dialog.columnconfigure(0, weight=1)
        frm.columnconfigure(1, weight=1)

        ttk.Label(frm, text="Title:").grid(row=0, column=0, sticky=tk.W, pady=5)
        title_var = tk.StringVar(
            value=book_entry["title"] if book_entry else self.title_var.get()
        )
        ttk.Entry(frm, textvariable=title_var, width=48).grid(
            row=0, column=1, sticky=(tk.W, tk.E), pady=5, padx=(8, 0)
        )

        ttk.Label(frm, text="Author:").grid(row=1, column=0, sticky=tk.W, pady=5)
        author_var = tk.StringVar(
            value=book_entry["author"] if book_entry else self.author_var.get()
        )
        ttk.Entry(frm, textvariable=author_var, width=48).grid(
            row=1, column=1, sticky=(tk.W, tk.E), pady=5, padx=(8, 0)
        )

        ttk.Label(frm, text="Index URL:").grid(row=2, column=0, sticky=tk.W, pady=5)
        url_var = tk.StringVar(
            value=book_entry["index_url"] if book_entry else ""
        )
        ttk.Entry(frm, textvariable=url_var, width=48).grid(
            row=2, column=1, sticky=(tk.W, tk.E), pady=5, padx=(8, 0)
        )

        note = (
            "(Settings snapshot will be preserved as-is)"
            if book_entry else
            "(Current Converter tab settings will be saved as the initial snapshot)"
        )
        ttk.Label(frm, text=note, foreground=_CLR_TEXT_MUTED).grid(
            row=3, column=0, columnspan=2, sticky=tk.W, pady=(0, 8)
        )

        btn_frm = ttk.Frame(frm)
        btn_frm.grid(row=4, column=0, columnspan=2)

        def _ok():
            t = title_var.get().strip()
            u = url_var.get().strip()
            if not t:
                messagebox.showwarning("Warning", "Title is required.", parent=dialog)
                return
            if not u:
                messagebox.showwarning("Warning", "Index URL is required.", parent=dialog)
                return
            result[0] = {
                "title": t,
                "author": author_var.get().strip(),
                "index_url": u,
            }
            dialog.destroy()

        ttk.Button(btn_frm, text="OK", command=_ok,
                   style="Accent.TButton").pack(side=tk.LEFT, padx=6)
        ttk.Button(btn_frm, text="Cancel",
                   command=dialog.destroy).pack(side=tk.LEFT, padx=6)

        # Allow Enter key to submit and Escape to cancel
        dialog.bind("<Return>", lambda _e: _ok())
        dialog.bind("<Escape>", lambda _e: dialog.destroy())

        dialog.wait_window()
        return result[0]

    # ── Check flow ────────────────────────────────────────────────────────────

    def _library_check_chapters(self, book_ids: Optional[List[str]] = None) -> None:
        """Fetch chapter counts for selected books (or all if nothing selected)."""
        library = self._get_library()
        if book_ids is None:
            sel = self._library_selected_book_id()
            if sel:
                book_ids = [sel]
            else:
                book_ids = [b["book_id"] for b in library.list_books()]

        if not book_ids:
            messagebox.showinfo("Library", "No books in library to check.")
            return

        if self._lib_is_processing:
            messagebox.showinfo("Library", "A library operation is already running.")
            return

        self._lib_is_processing = True
        self._library_log(f"🔍 Checking {len(book_ids)} book(s) for new chapters…")
        self.status_var.set("Checking library…")

        def _run():
            for book_id in book_ids:
                entry = library.get_book(book_id)
                if entry is None:
                    continue
                try:
                    config = self._config_from_snapshot(entry.get("last_settings") or {})
                    from main import WebToEbookApp
                    app = WebToEbookApp(config)
                    urls = app.scraper.scrape_index_page(entry["index_url"])
                    count = len(urls)
                    library.update_checked(book_id, count)
                    new_count = max(0, count - entry.get("last_processed_chapter", 0))
                    self.root.after(0, lambda bid=entry["title"], n=new_count, c=count:
                        self._library_log(
                            f"  ✅ {bid}: {c} chapter(s) found, {n} new"
                        ))
                except Exception as exc:
                    self.root.after(0, lambda bid=entry["title"], e=str(exc):
                        self._library_log(f"  ❌ {bid}: {e}"))

            def _done():
                self._lib_is_processing = False
                self._library_refresh_tree()
                self.status_var.set("Library check complete")
                self._library_log("🔍 Check complete.\n")

            self.root.after(0, _done)

        threading.Thread(target=_run, daemon=True).start()

    # ── Convert flow ──────────────────────────────────────────────────────────

    def _library_convert_new(self, book_ids: Optional[List[str]] = None) -> None:
        """Convert new (un-processed) chapters for selected book(s)."""
        library = self._get_library()
        max_new_chapters = max(0, int(self.lib_max_new_chapters_var.get()))
        if book_ids is None:
            sel = self._library_selected_book_id()
            if sel:
                book_ids = [sel]
            else:
                # Default: all books that have new chapters
                book_ids = [
                    b["book_id"] for b in library.list_books()
                    if b.get("last_chapter_count", 0) > b.get("last_processed_chapter", 0)
                ]

        if not book_ids:
            messagebox.showinfo(
                "Library",
                "No books with new chapters found.\n"
                "Run 'Check for New Chapters' first, or add a book.",
            )
            return

        if self._lib_is_processing:
            messagebox.showinfo("Library", "A library operation is already running.")
            return

        entries = [library.get_book(bid) for bid in book_ids]
        entries = [e for e in entries if e is not None]

        # Build a summary for the confirmation dialog
        lines = []
        for e in entries:
            done = e.get("last_processed_chapter", 0)
            total = e.get("last_chapter_count", 0)
            new_count = max(0, total - done)
            if new_count:
                lines.append(f"  • {e['title']}: {new_count} new chapter(s) (#{done + 1}–{total})")
            else:
                lines.append(f"  • {e['title']}: 0 new chapters (skipped)")

        to_process = [e for e in entries
                      if e.get("last_chapter_count", 0) > e.get("last_processed_chapter", 0)]

        if not to_process:
            messagebox.showinfo(
                "Library",
                "All selected books are already up to date.\n\n" + "\n".join(lines),
            )
            return

        if not messagebox.askyesno(
            "Convert New Chapters",
            "The following books will be processed:\n\n"
            + "\n".join(lines)
            + "\n\nProceed?",
        ):
            return

        self._lib_is_processing = True
        self.status_var.set("Library conversion running…")
        self._library_log(f"▶ Starting conversion for {len(to_process)} book(s)…\n")
        if max_new_chapters > 0:
            self._library_log(
                f"ℹ Per-run chapter limit enabled: {max_new_chapters} new chapter(s) max per book.\n"
            )

        threading.Thread(
            target=self._library_run_books_sequentially,
            args=(to_process, max_new_chapters),
            daemon=True,
        ).start()

    def _library_check_and_convert(self) -> None:
        """Check all books for new chapters, then convert any that have updates."""
        library = self._get_library()
        max_new_chapters = max(0, int(self.lib_max_new_chapters_var.get()))
        book_ids = [b["book_id"] for b in library.list_books()]
        if not book_ids:
            messagebox.showinfo("Library", "No books in library.")
            return

        if self._lib_is_processing:
            messagebox.showinfo("Library", "A library operation is already running.")
            return

        self._lib_is_processing = True
        self._library_log("🔄 Check & Convert All started…\n")
        self.status_var.set("Library: checking…")

        def _check_then_convert():
            # Step 1: check all books
            for book_id in book_ids:
                entry = library.get_book(book_id)
                if entry is None:
                    continue
                try:
                    config = self._config_from_snapshot(entry.get("last_settings") or {})
                    from main import WebToEbookApp
                    app = WebToEbookApp(config)
                    urls = app.scraper.scrape_index_page(entry["index_url"])
                    count = len(urls)
                    library.update_checked(book_id, count)
                    new_count = max(0, count - entry.get("last_processed_chapter", 0))
                    self.root.after(0, lambda bid=entry["title"], n=new_count, c=count:
                        self._library_log(
                            f"  🔍 {bid}: {c} chapter(s), {n} new"
                        ))
                except Exception as exc:
                    self.root.after(0, lambda bid=entry["title"], e=str(exc):
                        self._library_log(f"  ❌ {bid}: {e}"))

            self.root.after(0, self._library_refresh_tree)

            # Step 2: convert books that have new chapters
            to_process = []
            for book_id in book_ids:
                entry = library.get_book(book_id)
                if entry and entry.get("last_chapter_count", 0) > entry.get("last_processed_chapter", 0):
                    to_process.append(entry)

            if not to_process:
                def _all_done():
                    self._lib_is_processing = False
                    self.status_var.set("Library: all up to date")
                    self._library_log("✅ All books are up to date.\n")
                self.root.after(0, _all_done)
                return

            self.root.after(0, lambda n=len(to_process):
                self._library_log(f"▶ Converting {n} book(s) with new chapters…\n"))
            if max_new_chapters > 0:
                self.root.after(0, lambda m=max_new_chapters:
                    self._library_log(
                        f"ℹ Per-run chapter limit enabled: {m} new chapter(s) max per book.\n"
                    ))
            self._library_run_books_sequentially(to_process, max_new_chapters)

        threading.Thread(target=_check_then_convert, daemon=True).start()

    # ── Core batch runner ─────────────────────────────────────────────────────

    def _library_run_books_sequentially(
        self,
        entries: List[dict],
        max_new_chapters: int = 0,
    ) -> None:
        """Process each book in *entries* one by one (called from a worker thread)."""
        library = self._get_library()
        for entry in entries:
            if not self._lib_is_processing:
                break
            title = entry.get("title", entry["book_id"])
            self.root.after(0, lambda t=title:
                self._library_log(f"📖 Processing: {t}"))
            try:
                self._library_run_batch_for_book(
                    entry,
                    library,
                    max_new_chapters=max_new_chapters,
                )
            except Exception as exc:
                self.root.after(0, lambda t=title, e=str(exc):
                    self._library_log(f"  ❌ {t} failed: {e}\n"))

        def _finish():
            self._lib_is_processing = False
            self._library_refresh_tree()
            self.status_var.set("Library conversion complete")
            self._library_log("✅ Library conversion finished.\n")

        self.root.after(0, _finish)

    def _library_run_batch_for_book(
        self,
        entry: dict,
        library: BookLibrary,
        max_new_chapters: int = 0,
    ) -> None:
        """Convert new chapters for a single book entry (called from a worker thread).

        Uses ``entry['last_settings']`` to reconstruct the conversion Config so
        that voice, speed, LLM settings, etc. are identical to the last run.
        The pipeline mirrors ``_process_with_progress``:
        1. URL-level filler filtering (before scraping)
        2. Scrape
        3. Content-level filler filtering (after scraping)
        4. EPUB creation
        5. Character artifact extraction + automatic DB persistence
        6. Multi-speaker voice assignment + dialogue detection (when enabled)
        7. Audio generation (multi-voice or narrator-only)
        """
        from book_library import FillerChapterFilter
        from main import WebToEbookApp

        book_id = entry["book_id"]
        title = entry.get("title", book_id)
        index_url = entry["index_url"]
        last_done = entry.get("last_processed_chapter", 0)
        audio_batch_size = (
            entry.get("last_settings", {}).get("_lib_audio_batch_size") or 10
        )

        config = self._config_from_snapshot(entry.get("last_settings") or {})
        config.epub_title = title

        app = WebToEbookApp(config)
        filler = FillerChapterFilter()

        # ── Fetch chapter list ─────────────────────────────────────────────────
        self.root.after(0, lambda:
            self._library_log("  🔍 Fetching chapter list from index…"))
        all_urls = app.scraper.scrape_index_page(index_url)
        total = len(all_urls)

        if not all_urls:
            raise ValueError("No chapter URLs found on the index page.")

        if last_done >= total:
            self.root.after(0, lambda t=title:
                self._library_log(
                    f"  ⏭  {t}: already up to date (all {total} chapters done)"))
            return

        new_urls = all_urls[last_done:]
        if max_new_chapters > 0 and len(new_urls) > max_new_chapters:
            new_urls = new_urls[:max_new_chapters]
            self.root.after(0, lambda m=max_new_chapters:
                self._library_log(
                    f"  ℹ Limiting this run to {m} new chapter(s)"
                ))

        # ── URL-level filler filtering ─────────────────────────────────────────
        clean_urls, url_filler = filler.filter_urls(new_urls)
        if url_filler:
            self.root.after(0, lambda n=len(url_filler):
                self._library_log(
                    f"  🚫 Skipped {n} URL(s) that matched unreleased/locked patterns"))
        if not clean_urls:
            self.root.after(0, lambda:
                self._library_log("  ⏭  No new chapters available after filler URL filtering"))
            return

        self.root.after(0, lambda n=len(clean_urls), s=last_done + 1,
                        e=last_done + len(clean_urls):
            self._library_log(
                f"  📋 Processing chapters {s}–{e} ({n} new chapter(s))"))

        # ── Scrape ────────────────────────────────────────────────────────────
        self.root.after(0, lambda: self._library_log("  ⬇  Scraping chapters…"))
        scraper = app.create_fresh_scraper()
        chapters = scraper.scrape_chapters(clean_urls)

        # ── Content-level filler filtering ────────────────────────────────────
        chapters, content_filler = filler.filter_chapters(chapters)
        if content_filler:
            self.root.after(0, lambda n=len(content_filler):
                self._library_log(
                    f"  🚫 Skipped {n} chapter(s) with filler/unreleased content"))

        chapters = [ch for ch in chapters if ch.get("content", "").strip()]
        if not chapters:
            raise ValueError("No chapters remained after filler filtering.")

        self.root.after(0, lambda n=len(chapters):
            self._library_log(f"  ✓ {n} chapter(s) scraped"))

        # ── EPUBs ────────────────────────────────────────────────────────────
        self.root.after(0, lambda: self._library_log("  📄 Creating EPUBs…"))
        for i, chapter in enumerate(chapters, last_done + 1):
            ch_name = f"{title}_chapter_{i:03d}"
            app.ebook_gen.create_epub([chapter], ch_name, config.epub_author)
        self.root.after(0, lambda n=len(chapters):
            self._library_log(f"  ✓ {n} EPUB(s) created"))

        # ── Character extraction + DB persistence ────────────────────────────
        self.root.after(0, lambda: self._library_log("  🧑‍🤝‍🧑 Extracting characters…"))
        try:
            character_artifacts = app._generate_character_artifacts(chapters, title)
            confirmed_characters = character_artifacts.get("character_checklist", [])
            new_chars = character_artifacts.get("new_characters", [])
            if new_chars:
                self.root.after(0, lambda nc=new_chars:
                    self._library_log(
                        f"  ℹ  New character(s) detected: {', '.join(nc)}"))
            review_decisions = app._collect_review_decisions(character_artifacts)
            app.character_db.save_characters(
                title, confirmed_characters, review_decisions=review_decisions
            )
            self.root.after(0, lambda n=len(confirmed_characters):
                self._library_log(f"  ✓ Character DB updated ({n} character(s))"))
        except Exception as exc:
            self.root.after(0, lambda e=exc:
                self._library_log(f"  ⚠  Character extraction failed ({e}); continuing"))
            confirmed_characters = []

        # ── Prepare cleaned audio text ────────────────────────────────────────
        audio_chapters = app._prepare_chapters_for_audio(chapters)

        # ── Multi-speaker dialogue segmentation (if enabled) ─────────────────
        kwargs = {
            "voice": config.kokoro_voice,
            "lang_code": config.kokoro_lang_code,
            "speed": config.kokoro_speed,
        }
        dialogue_segments_by_chapter: list = []
        voice_mappings: dict = {}

        if app.character_voice_manager:
            self.root.after(0, lambda: self._library_log(
                "  🎙  Assigning character voices…"))
            try:
                combined_text = "\n\n".join(ch["content"] for ch in audio_chapters)
                known_char_records = app.character_db.load_records(title)
                known_characters = app._get_known_characters_for_book(title)
                assignments = app.character_voice_manager.analyze_and_assign_voices(
                    combined_text,
                    known_characters=known_characters,
                    manual_mappings=config.character_voice_mappings,
                    known_character_records=known_char_records,
                )
                voice_mappings = {
                    char_name: assignment.voice_name
                    for char_name, assignment in assignments.items()
                }
                detector = app._create_dialogue_detector(llm_mode_override="full")
                for chapter in audio_chapters:
                    segs = detector.detect_dialogue_in_text(
                        chapter["content"],
                        known_characters=list(assignments.keys()),
                        known_character_records=known_char_records,
                    )
                    dialogue_segments_by_chapter.append(segs)
                app._write_multispeaker_debug_report(
                    title,
                    assignments=assignments,
                    voice_mappings=voice_mappings,
                    dialogue_segments_by_chapter=dialogue_segments_by_chapter,
                    audio_chapters=audio_chapters,
                )
                self.root.after(0, lambda n=len(assignments):
                    self._library_log(f"  ✓ {n} character voice(s) assigned"))
            except Exception as exc:
                self.root.after(0, lambda e=exc:
                    self._library_log(
                        f"  ⚠  Multi-speaker setup failed ({e}); using narrator-only audio"))
                dialogue_segments_by_chapter = []
                voice_mappings = {}

        # ── Audio generation in batches ───────────────────────────────────────
        self.root.after(0, lambda: self._library_log("  🔊 Generating audio…"))
        batches = [
            audio_chapters[s: s + audio_batch_size]
            for s in range(0, len(audio_chapters), audio_batch_size)
        ]
        global_batch_offset = last_done // audio_batch_size + 1
        total_batches = len(batches) + global_batch_offset - 1
        for b_num, batch in enumerate(batches, global_batch_offset):
            if not self._lib_is_processing:
                raise ValueError("Library processing was stopped by the user.")
            b_start = last_done + (b_num - global_batch_offset) * audio_batch_size + 1
            b_end = b_start + len(batch) - 1
            b_file = (
                f"{title}_audio_batch_{b_num:03d}"
                f"_ch{b_start:03d}-{b_end:03d}.wav"
            )
            if app.character_voice_manager and dialogue_segments_by_chapter:
                batch_start_idx = (b_num - global_batch_offset) * audio_batch_size
                batch_segs: list = []
                for seg_list in dialogue_segments_by_chapter[
                    batch_start_idx: batch_start_idx + len(batch)
                ]:
                    batch_segs.extend(seg_list)
                if batch_segs:
                    ap = app.tts.generate_multi_voice_audio(
                        batch_segs,
                        b_file,
                        voice_mappings,
                        dialogue_pause=config.dialogue_pause,
                        **kwargs,
                    )
                else:
                    text = "\n\n".join(ch["content"] for ch in batch)
                    ap = app.tts.generate_audio(text, b_file, **kwargs)
            else:
                text = "\n\n".join(ch["content"] for ch in batch)
                ap = app.tts.generate_audio(text, b_file, **kwargs)

            self.root.after(0, lambda f=str(ap), bn=b_num, tb=total_batches:
                self._library_log(
                    f"  ✓ Audio batch {bn}/{tb}: {f}"))

        # ── Persist progress ──────────────────────────────────────────────────
        new_last_processed = last_done + len(chapters)
        snapshot = self._capture_settings_snapshot()
        snapshot["_lib_audio_batch_size"] = audio_batch_size
        library.update_after_run(
            book_id,
            last_processed_chapter=new_last_processed,
            last_chapter_count=total,
            settings=snapshot,
        )

        self.root.after(0, lambda t=title, n=new_last_processed, tot=total:
            self._library_log(
                f"  ✅ {t}: done. Progress: {n}/{tot} chapters.\n"
            ))

    # ── Settings snapshot helpers ─────────────────────────────────────────────

    def _capture_settings_snapshot(self) -> dict:
        """Serialise the current GUI settings into a plain dict (JSON-safe)."""
        import dataclasses
        config = self.get_config()
        return dataclasses.asdict(config)

    def _config_from_snapshot(self, snapshot: dict) -> "Config":
        """Build a Config from a previously captured settings snapshot.

        Keys that are not valid Config fields are silently ignored.
        Missing keys fall back to Config defaults.
        """
        import dataclasses
        valid_fields = {f.name for f in dataclasses.fields(Config)}
        filtered = {k: v for k, v in snapshot.items() if k in valid_fields}
        return Config(**filtered)

    def _apply_settings_snapshot(self, snapshot: dict) -> None:
        """Write a settings snapshot back into the GUI variables.

        This lets the user inspect or further edit the saved settings before
        running a manual conversion from the Converter tab.
        """
        config = self._config_from_snapshot(snapshot)

        self.title_var.set(config.epub_title)
        self.author_var.set(config.epub_author)
        self.output_var.set(config.output_dir)
        self.kokoro_voice_var.set(config.kokoro_voice)
        lang_label = {
            "a": "American English", "b": "British English",
            "e": "Spanish", "f": "French", "h": "Hindi",
            "i": "Italian", "j": "Japanese", "p": "Portuguese", "z": "Mandarin",
        }.get(config.kokoro_lang_code, "American English")
        self.kokoro_lang_code_var.set(f"{config.kokoro_lang_code} - {lang_label}")
        self.kokoro_speed_var.set(config.kokoro_speed)
        self.speech_rate_var.set(config.speech_rate)
        self.max_chapters_var.set(config.max_chapters)
        self.max_duration_var.set(config.max_duration)
        self.start_chapter_var.set(config.start_chapter)
        self.end_chapter_var.set(config.end_chapter)
        self.per_chapter_audio_var.set(config.generate_per_chapter_audio)

        if config.css_selectors:
            self.css_text.delete("1.0", tk.END)
            self.css_text.insert(tk.END, "\n".join(config.css_selectors))

        self.use_visual_order_var.set(config.use_visual_order)
        self.wait_for_js_var.set(config.wait_for_js)
        self.use_existing_browser_var.set(config.use_existing_browser)
        self.browser_cdp_url_var.set(config.browser_cdp_url)
        self.allow_edge_signin_var.set(config.allow_edge_signin)
        self.remove_overlays_var.set(config.remove_overlays)
        self.browser_timeout_var.set(config.browser_timeout)

        self.enable_translation_var.set(config.enable_translation)
        self.source_language_var.set(config.source_language)
        self.target_language_var.set(config.target_language)
        self.translation_api_url_var.set(config.translation_api_url)
        if config.translation_api_key:
            self.translation_api_key_var.set(config.translation_api_key)

        self.enable_character_voices_var.set(config.enable_character_voices)
        self.narrator_voice_var.set(config.narrator_voice)
        self.auto_assign_voices_var.set(config.auto_assign_character_voices)
        self.default_male_voice_var.set(config.default_male_voice)
        self.default_female_voice_var.set(config.default_female_voice)
        self.dialogue_pause_var.set(config.dialogue_pause)

        self.dialogue_llm_mode_var.set(config.dialogue_llm_mode)
        self.dialogue_llm_model_var.set(config.dialogue_llm_model)
        self.dialogue_llm_url_var.set(config.dialogue_llm_url)
        self.dialogue_llm_timeout_var.set(config.dialogue_llm_timeout)
        self.dialogue_llm_strict_quotes_var.set(config.dialogue_llm_strict_quotes)
        self.character_manual_review_var.set(config.character_manual_review)
        self.character_review_low_conf_var.set(
            config.character_review_low_confidence_threshold
        )

    def create_update_tab(self):
        """Create updater tab for checking and installing app updates."""
        update_tab = self._create_scrollable_tab("Updater")

        info_frame = ttk.LabelFrame(update_tab, text="Application Updates", padding="10")
        info_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))

        ttk.Label(
            info_frame,
            text=(
                "Use this tab to check for new releases and run the bundled updater.\n"
                "Update output appears below so you can confirm each updater step."
            ),
            justify=tk.LEFT,
            wraplength=760,
        ).grid(row=0, column=0, columnspan=3, sticky=tk.W, pady=(0, 8))

        self.updater_debug_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            info_frame,
            text="Enable detailed debug output",
            variable=self.updater_debug_var,
        ).grid(row=1, column=0, columnspan=3, sticky=tk.W, pady=(0, 10))

        self.check_updates_button = ttk.Button(
            info_frame,
            text="Check for Updates",
            command=self.check_for_updates,
        )
        self.check_updates_button.grid(row=2, column=0, sticky=tk.W, padx=(0, 6))

        self.install_update_button = ttk.Button(
            info_frame,
            text="Install Latest Update",
            command=self.install_latest_update,
            style="Accent.TButton",
        )
        self.install_update_button.grid(row=2, column=1, sticky=tk.W, padx=(0, 6))

        ttk.Button(
            info_frame,
            text="Clear Update Log",
            command=self.clear_update_log,
        ).grid(row=2, column=2, sticky=tk.W)

        self.updater_status_var = tk.StringVar(value="Updater idle")
        ttk.Label(
            info_frame,
            textvariable=self.updater_status_var,
            foreground="gray",
        ).grid(row=3, column=0, columnspan=3, sticky=tk.W, pady=(8, 0))

        info_frame.columnconfigure(0, weight=1)

        log_frame = ttk.LabelFrame(update_tab, text="Updater Output", padding="10")
        log_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        self.update_log_text = scrolledtext.ScrolledText(
            log_frame,
            height=18,
            width=90,
            state='disabled',
            bg=_CLR_LOG_BG,
            fg=_CLR_TEXT,
            font=_FONT_MONO,
            relief=tk.FLAT,
            borderwidth=1,
            insertbackground=_CLR_TEXT,
        )
        self.update_log_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        update_tab.columnconfigure(0, weight=1)
        update_tab.rowconfigure(1, weight=1)

        self._updater_process = None

    def clear_update_log(self):
        """Clear updater output text box."""
        self.update_log_text.configure(state='normal')
        self.update_log_text.delete("1.0", tk.END)
        self.update_log_text.configure(state='disabled')

    def _append_update_log(self, line):
        """Append a single line of updater output to the update tab."""
        self.update_log_text.configure(state='normal')
        self.update_log_text.insert(tk.END, line.rstrip("\n") + "\n")
        self.update_log_text.configure(state='disabled')
        self.update_log_text.see(tk.END)

    def _set_update_buttons_state(self, enabled):
        """Enable or disable updater actions while updater is running."""
        state = tk.NORMAL if enabled else tk.DISABLED
        self.check_updates_button.config(state=state)
        self.install_update_button.config(state=state)

    def check_for_updates(self):
        """Run updater in check-only mode from the GUI."""
        self._run_updater_command(
            ["--check-only", "--non-interactive"],
            "Checking for updates...",
            "Update Check",
        )

    def install_latest_update(self):
        """Run full updater from the GUI."""
        proceed = messagebox.askyesno(
            "Install Update",
            "This will download and install the latest release.\n\nContinue?",
        )
        if not proceed:
            return
        self._run_updater_command(
            ["--non-interactive", "--yes"],
            "Installing latest update...",
            "Updater",
        )

    def _run_updater_command(self, updater_args, running_status, dialog_title):
        """Execute updater.py and stream output into the updater tab."""
        if self._updater_process and self._updater_process.poll() is None:
            messagebox.showinfo(
                "Updater Running",
                "An updater process is already running. Please wait for it to finish.",
            )
            return

        args = list(updater_args)
        if self.updater_debug_var.get():
            args.append("--debug")

        command = [sys.executable, str(APP_DIR / "updater.py"), *args]
        self._set_update_buttons_state(False)
        self.updater_status_var.set(running_status)
        self._append_update_log("")
        self._append_update_log("=" * 72)
        self._append_update_log(f"Running: {' '.join(command)}")
        self._append_update_log("=" * 72)

        def _runner():
            kwargs = {
                "cwd": str(APP_DIR),
                "stdout": subprocess.PIPE,
                "stderr": subprocess.STDOUT,
                "text": True,
                "bufsize": 1,
            }
            if _IS_WINDOWS:
                kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW

            try:
                process = subprocess.Popen(command, **kwargs)
                self._updater_process = process

                if process.stdout:
                    for line in process.stdout:
                        self.root.after(0, lambda value=line: self._append_update_log(value))

                return_code = process.wait()
                self._updater_process = None
                self.root.after(
                    0,
                    lambda rc=return_code: self._finish_updater_command(
                        rc,
                        dialog_title,
                    ),
                )
            except Exception as exc:
                self._updater_process = None
                self.root.after(
                    0,
                    lambda err=str(exc): self._fail_updater_command(err, dialog_title),
                )

        threading.Thread(target=_runner, daemon=True).start()

    def _finish_updater_command(self, return_code, dialog_title):
        """Handle updater completion status in GUI."""
        self._set_update_buttons_state(True)
        if return_code == 0:
            self.updater_status_var.set("Updater finished successfully")
            self._append_update_log("✅ Updater finished successfully")
            messagebox.showinfo(dialog_title, "Updater finished successfully.")
            return

        self.updater_status_var.set(f"Updater failed (exit code: {return_code})")
        self._append_update_log(f"❌ Updater failed with exit code {return_code}")
        messagebox.showerror(
            dialog_title,
            f"Updater failed with exit code {return_code}.\nCheck the updater output log for details.",
        )

    def _fail_updater_command(self, error_msg, dialog_title):
        """Handle updater launch/runtime errors."""
        self._set_update_buttons_state(True)
        self.updater_status_var.set("Updater failed to start")
        self._append_update_log(f"❌ Failed to launch updater: {error_msg}")
        messagebox.showerror(dialog_title, f"Failed to launch updater:\n{error_msg}")

    def create_batch_tab(self):
        """Create batch mode tab for processing a whole book from its index page."""
        batch_tab = self._create_scrollable_tab("Batch Mode")

        # ── Index URL ────────────────────────────────────────────────────────
        index_frame = ttk.LabelFrame(batch_tab, text="Book Index Page", padding="10")
        index_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))

        ttk.Label(index_frame, text="Book index / TOC URL:").grid(
            row=0, column=0, sticky=tk.W, pady=5)
        self.batch_index_url_var = tk.StringVar()
        ttk.Entry(index_frame, textvariable=self.batch_index_url_var, width=65).grid(
            row=0, column=1, sticky=(tk.W, tk.E), pady=5, padx=(5, 0))

        ttk.Button(index_frame, text="🔍 Fetch Chapter List",
                   command=self.batch_fetch_chapters).grid(
            row=1, column=0, columnspan=2, pady=(5, 0))

        index_frame.columnconfigure(1, weight=1)

        # ── Chapter count / batch settings ──────────────────────────────────
        settings_frame = ttk.LabelFrame(batch_tab, text="Processing Settings", padding="10")
        settings_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=(0, 10))

        # Chapter range label (populated after fetch)
        self.batch_chapters_found_var = tk.StringVar(value="(fetch chapters first)")
        ttk.Label(settings_frame, text="Chapters found:").grid(
            row=0, column=0, sticky=tk.W, pady=5)
        ttk.Label(settings_frame, textvariable=self.batch_chapters_found_var,
                  foreground="gray").grid(row=0, column=1, sticky=tk.W, pady=5, padx=(5, 0))

        ttk.Label(settings_frame, text="Start chapter (1-based):").grid(
            row=1, column=0, sticky=tk.W, pady=5)
        self.batch_start_chapter_var = tk.IntVar(value=1)
        ttk.Spinbox(
            settings_frame, from_=1, to=9999,
            textvariable=self.batch_start_chapter_var, width=10).grid(
            row=1, column=1, sticky=tk.W, pady=5, padx=(5, 0))
        ttk.Label(settings_frame, text="(inclusive)",
                  foreground="gray").grid(row=1, column=2, sticky=tk.W, padx=(5, 0))

        ttk.Label(settings_frame, text="End chapter (0 = last):").grid(
            row=2, column=0, sticky=tk.W, pady=5)
        self.batch_end_chapter_var = tk.IntVar(value=0)
        ttk.Spinbox(settings_frame, from_=0, to=9999,
                    textvariable=self.batch_end_chapter_var, width=10).grid(
            row=2, column=1, sticky=tk.W, pady=5, padx=(5, 0))
        ttk.Label(settings_frame, text="(inclusive)",
                  foreground="gray").grid(row=2, column=2, sticky=tk.W, padx=(5, 0))

        ttk.Label(settings_frame, text="Chapters per audio batch:").grid(
            row=3, column=0, sticky=tk.W, pady=5)
        self.batch_audio_size_var = tk.IntVar(value=10)
        ttk.Spinbox(settings_frame, from_=1, to=9999,
                    textvariable=self.batch_audio_size_var, width=10).grid(
            row=3, column=1, sticky=tk.W, pady=5, padx=(5, 0))
        ttk.Label(settings_frame, text="chapters per .wav file",
                  foreground="gray").grid(row=3, column=2, sticky=tk.W, padx=(5, 0))

        settings_frame.columnconfigure(1, weight=1)

        # ── Book metadata ────────────────────────────────────────────────────
        meta_frame = ttk.LabelFrame(batch_tab, text="Output", padding="10")
        meta_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=(0, 10))

        ttk.Label(meta_frame, text="Book title (base filename):").grid(
            row=0, column=0, sticky=tk.W, pady=5)
        self.batch_title_var = tk.StringVar(value="My Book")
        ttk.Entry(meta_frame, textvariable=self.batch_title_var, width=45).grid(
            row=0, column=1, sticky=(tk.W, tk.E), pady=5, padx=(5, 0))

        meta_frame.columnconfigure(1, weight=1)

        # ── Control buttons ──────────────────────────────────────────────────
        btn_frame = ttk.Frame(batch_tab)
        btn_frame.grid(row=3, column=0, pady=(0, 10))

        self.batch_start_button = ttk.Button(btn_frame, text="🚀 Start Batch Processing",
                                             command=self.start_batch_process)
        self.batch_start_button.pack(side=tk.LEFT, padx=5)

        self.batch_stop_button = ttk.Button(btn_frame, text="Stop",
                                            command=self.stop_batch_process,
                                            state=tk.DISABLED)
        self.batch_stop_button.pack(side=tk.LEFT, padx=5)

        ttk.Button(btn_frame, text="Clear Log",
                   command=self.clear_batch_log).pack(side=tk.LEFT, padx=5)

        # ── Progress / log ───────────────────────────────────────────────────
        log_frame = ttk.LabelFrame(batch_tab, text="Progress", padding="10")
        log_frame.grid(row=4, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 0))

        self.batch_progress_var = tk.DoubleVar()
        ttk.Progressbar(log_frame, variable=self.batch_progress_var,
                        mode='determinate', maximum=100,
                        style="Accent.Horizontal.TProgressbar").grid(
            row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))

        self.batch_log_text = scrolledtext.ScrolledText(
            log_frame, height=14, width=70,
            state='disabled',
            bg=_CLR_LOG_BG,
            fg=_CLR_TEXT,
            font=_FONT_MONO,
            relief=tk.FLAT,
            borderwidth=1,
            insertbackground=_CLR_TEXT,
        )
        self.batch_log_text.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(1, weight=1)

        # Configure overall grid weights
        batch_tab.columnconfigure(0, weight=1)
        batch_tab.rowconfigure(4, weight=1)

        # Internal state
        self._batch_chapter_urls: list = []
        self._batch_is_processing: bool = False

    # ── Batch-mode helpers ────────────────────────────────────────────────────

    def _batch_log(self, msg: str):
        """Append *msg* to the batch log widget (thread-safe)."""
        def _append():
            self.batch_log_text.configure(state='normal')
            self.batch_log_text.insert(tk.END, msg + '\n')
            self.batch_log_text.configure(state='disabled')
            self.batch_log_text.see(tk.END)
        self.batch_log_text.after(0, _append)

    def clear_batch_log(self):
        """Clear the batch log text widget."""
        self.batch_log_text.configure(state='normal')
        self.batch_log_text.delete("1.0", tk.END)
        self.batch_log_text.configure(state='disabled')

    def batch_fetch_chapters(self):
        """Fetch chapter list from the index URL in a background thread."""
        index_url = self.batch_index_url_var.get().strip()
        if not index_url:
            messagebox.showwarning("Warning", "Please enter a book index URL first.")
            return

        self.batch_start_button.config(state=tk.DISABLED)
        self._batch_log(f"🔍 Fetching chapter list from:\n  {index_url}\n")
        self.status_var.set("Fetching chapter list...")

        def _fetch():
            try:
                config = self.get_config()
                from main import WebToEbookApp
                app = WebToEbookApp(config)

                urls = app.scraper.scrape_index_page(index_url)

                def _done(chapter_urls):
                    self._batch_chapter_urls = chapter_urls
                    n = len(chapter_urls)
                    self.batch_chapters_found_var.set(f"{n} chapter(s) found")
                    # Pre-fill start/end range
                    self.batch_start_chapter_var.set(1)
                    self.batch_end_chapter_var.set(n)
                    self._batch_log(f"✅ Found {n} chapter(s)\n")
                    for i, u in enumerate(chapter_urls[:10], 1):
                        self._batch_log(f"   {i}. {u}")
                    if n > 10:
                        self._batch_log(f"   ... and {n - 10} more")
                    self._batch_log("")
                    self.batch_start_button.config(state=tk.NORMAL)
                    self.status_var.set(f"Found {n} chapters")

                self.root.after(0, lambda u=urls: _done(u))
            except Exception as exc:
                def _fail(err):
                    self._batch_log(f"❌ Failed to fetch chapters: {err}\n")
                    self.batch_start_button.config(state=tk.NORMAL)
                    self.status_var.set("Fetch failed")
                self.root.after(0, lambda e=str(exc): _fail(e))

        threading.Thread(target=_fetch, daemon=True).start()

    def start_batch_process(self):
        """Start the batch processing workflow in a background thread."""
        index_url = self.batch_index_url_var.get().strip()
        if not index_url:
            messagebox.showwarning("Warning", "Please enter a book index URL.")
            return

        start_chapter = self.batch_start_chapter_var.get()
        end_chapter_input = self.batch_end_chapter_var.get()
        audio_batch_size = self.batch_audio_size_var.get()
        output_name = self.batch_title_var.get().strip() or "My Book"

        if start_chapter < 1:
            messagebox.showwarning("Warning", "Start chapter must be at least 1.")
            return
        if end_chapter_input < 0:
            messagebox.showwarning("Warning", "End chapter must be 0 or greater.")
            return
        if end_chapter_input > 0 and end_chapter_input < start_chapter:
            messagebox.showwarning("Warning", "End chapter must be greater than or equal to start chapter.")
            return
        if audio_batch_size < 1:
            messagebox.showwarning("Warning", "Chapters per audio batch must be at least 1.")
            return

        self._batch_is_processing = True
        self.batch_start_button.config(state=tk.DISABLED)
        self.batch_stop_button.config(state=tk.NORMAL)
        self.batch_progress_var.set(0)
        self.status_var.set("Batch processing...")
        self._batch_log(f"🚀 Starting batch processing\n   URL: {index_url}\n"
                        f"   Chapter range: {start_chapter} to {end_chapter_input or 'last'}\n"
                        f"   Audio batch size: {audio_batch_size}\n")

        def _run():
            try:
                config = self.get_config()
                # Override title with the batch-specific title
                config.epub_title = output_name
                from main import WebToEbookApp
                app = WebToEbookApp(config)

                def _cancel_batch_run(message):
                    self.root.after(0, lambda m=message: self._batch_cancelled(m))

                def _scrape_url_subset(url_subset):
                    subset_scraper = app.create_fresh_scraper()
                    return subset_scraper.scrape_chapters(url_subset)

                if config.use_existing_browser:
                    ready_holder = [False]
                    ready_event = threading.Event()

                    def _confirm_ready():
                        try:
                            self.open_browser_for_cloudflare(index_url)
                        except Exception as browser_open_error:
                            logging.warning(
                                f"Failed to auto-open browser for index page confirmation ({index_url}): "
                                f"{browser_open_error}"
                            )
                        ready_holder[0] = messagebox.askyesno(
                            "Confirm Index Page Ready",
                            "Make sure the browser shows the chapter index page and any blocker is bypassed.\n\n"
                            "Click Yes when ready to start scraping."
                        )
                        ready_event.set()

                    self.root.after(0, _confirm_ready)
                    ready_event.wait()
                    if not ready_holder[0]:
                        _cancel_batch_run("❌ Cancelled: index page not confirmed as ready.")
                        return

                # Use already-fetched URLs when available
                all_urls = self._batch_chapter_urls
                if not all_urls:
                    self.root.after(0, lambda: self._batch_log("🔍 Fetching chapter list..."))
                    all_urls = app.scraper.scrape_index_page(index_url)

                if not all_urls:
                    raise ValueError("No chapter URLs found on the index page.")

                total = len(all_urls)
                if start_chapter > total:
                    raise ValueError(
                        f"Start chapter {start_chapter} is out of range. Index contains {total} chapters."
                    )

                end_chapter = end_chapter_input if end_chapter_input > 0 else total
                end_chapter = min(end_chapter, total)
                chapter_urls = all_urls[start_chapter - 1:end_chapter]

                if not chapter_urls:
                    raise ValueError("Selected chapter range is empty.")

                self.root.after(0, lambda s=start_chapter, e=end_chapter:
                    self._batch_log(f"📖 Processing chapters {s} to {e} ({e - s + 1} total)\n"))

                preview_target = min(3, len(chapter_urls))
                preview_urls = chapter_urls[:preview_target]
                remaining_urls = chapter_urls[preview_target:]

                self.root.after(0, lambda n=preview_target:
                    self.status_var.set(f"Scraping preview chapters (1-{n})..."))

                preview_chapters = _scrape_url_subset(preview_urls)
                preview_chapters = [ch for ch in preview_chapters if ch.get('content', '').strip()]
                if not preview_chapters:
                    raise ValueError("Preview chapters contained no content after scraping.")

                preview_start = start_chapter
                preview_end = start_chapter + len(preview_chapters) - 1
                preview_epub = app.ebook_gen.create_epub(
                    preview_chapters,
                    f"{output_name}_preview_ch{preview_start:03d}-{preview_end:03d}",
                    config.epub_author
                )

                approved_holder = [False]
                preview_event = threading.Event()

                def _confirm_preview():
                    opened = webbrowser.open(Path(preview_epub).resolve().as_uri())
                    if not opened:
                        messagebox.showwarning(
                            "Preview EPUB",
                            f"Could not auto-open preview EPUB (common causes: no default EPUB reader is configured).\n"
                            f"You can open it manually:\n{preview_epub}"
                        )
                    approved_holder[0] = self._show_preview_dialog(preview_chapters, max_preview=3)
                    preview_event.set()

                self.root.after(0, _confirm_preview)
                preview_event.wait()
                approved = approved_holder[0]
                if not approved:
                    _cancel_batch_run("❌ Cancelled by user after preview.")
                    return

                chapters = list(preview_chapters)

                if remaining_urls and self._batch_is_processing:
                    self.root.after(0, lambda n=len(remaining_urls):
                        self.status_var.set(f"Scraping remaining {n} chapter(s)..."))
                    remaining_chapters = _scrape_url_subset(remaining_urls)
                    remaining_chapters = [ch for ch in remaining_chapters if ch.get('content', '').strip()]
                    chapters.extend(remaining_chapters)

                if not chapters:
                    raise ValueError("All scraped chapters are empty.")

                total_steps = len(chapters) + (len(chapters) + audio_batch_size - 1) // audio_batch_size
                done_steps = 0

                def _advance(msg):
                    nonlocal done_steps
                    done_steps += 1
                    pct = done_steps / total_steps * 100
                    self.root.after(0, lambda p=pct: self.batch_progress_var.set(p))
                    self.root.after(0, lambda m=msg: self._batch_log(m))
                    self.root.after(0, lambda m=msg: self.status_var.set(m))

                # Create EPUBs
                self.root.after(0, lambda: self._batch_log("\n📄 Creating EPUBs..."))
                epub_paths = []
                for i, chapter in enumerate(chapters, 1):
                    if not self._batch_is_processing:
                        _cancel_batch_run("⏹ Batch processing stopped during EPUB generation.")
                        return
                    ch_name = f"{output_name}_chapter_{i:03d}"
                    ep = app.ebook_gen.create_epub([chapter], ch_name, config.epub_author)
                    epub_paths.append(str(ep))
                    _advance(f"  ✓ EPUB chapter {i}/{len(chapters)}: {ep}")

                # Audio batches
                self.root.after(0, lambda: self._batch_log("\n🔊 Generating audio batches..."))
                kwargs = {
                    'voice': config.kokoro_voice,
                    'lang_code': config.kokoro_lang_code,
                    'speed': config.kokoro_speed,
                }
                audio_chapters = app._prepare_chapters_for_audio(chapters)
                batches = [
                    audio_chapters[s:s + audio_batch_size]
                    for s in range(0, len(audio_chapters), audio_batch_size)
                ]
                audio_files = []
                for b_num, batch in enumerate(batches, 1):
                    if not self._batch_is_processing:
                        _cancel_batch_run("⏹ Batch processing stopped during audio generation.")
                        return
                    b_start = (b_num - 1) * audio_batch_size + 1
                    b_end = b_start + len(batch) - 1
                    b_file = (
                        f"{output_name}_audio_batch_{b_num:03d}"
                        f"_ch{b_start:03d}-{b_end:03d}.wav"
                    )
                    text = '\n\n'.join(ch['content'] for ch in batch)
                    ap = app.tts.generate_audio(text, b_file, **kwargs)
                    audio_files.append(str(ap))
                    _advance(
                        f"  ✓ Audio batch {b_num}/{len(batches)} "
                        f"(ch {b_start}-{b_end}): {ap}"
                    )

                result = {
                    'status': 'complete',
                    'chapters': len(chapters),
                    'epub_files': epub_paths,
                    'audio_files': audio_files,
                }
                self.root.after(0, lambda r=result: self._batch_done(r))

            except Exception as exc:
                self.root.after(0, lambda e=str(exc): self._batch_failed(e))

        threading.Thread(target=_run, daemon=True).start()

    def stop_batch_process(self):
        """Signal the batch processing loop to stop."""
        self._batch_is_processing = False
        self.batch_stop_button.config(state=tk.DISABLED)
        self.batch_start_button.config(state=tk.NORMAL)
        self.batch_progress_var.set(0)
        self.status_var.set("Batch stopped")
        self._batch_log("\n⏹ Batch processing stopped by user\n")

    def _batch_done(self, result):
        """Handle successful batch completion."""
        self._batch_is_processing = False
        self.batch_progress_var.set(100)
        self.batch_start_button.config(state=tk.NORMAL)
        self.batch_stop_button.config(state=tk.DISABLED)
        self.status_var.set("Batch complete!")
        self._batch_log(
            f"\n✅ Batch processing complete!\n"
            f"   Chapters : {result['chapters']}\n"
            f"   EPUBs    : {len(result['epub_files'])}\n"
            f"   Audio    : {len(result['audio_files'])}\n"
        )
        messagebox.showinfo(
            "Batch Complete",
            f"Batch processing finished!\n\n"
            f"Chapters processed: {result['chapters']}\n"
            f"EPUBs created: {len(result['epub_files'])}\n"
            f"Audio batches: {len(result['audio_files'])}"
        )

    def _batch_failed(self, error_msg):
        """Handle batch processing failure."""
        self._batch_is_processing = False
        self.batch_progress_var.set(0)
        self.batch_start_button.config(state=tk.NORMAL)
        self.batch_stop_button.config(state=tk.DISABLED)
        self.status_var.set("Batch failed")
        self._batch_log(f"\n❌ Batch processing failed:\n{error_msg}\n")
        messagebox.showerror("Batch Failed", f"Batch processing failed:\n{error_msg}")

    def _batch_cancelled(self, message):
        """Handle user/system cancellation during batch workflow."""
        self._batch_is_processing = False
        self.batch_start_button.config(state=tk.NORMAL)
        self.batch_stop_button.config(state=tk.DISABLED)
        self.status_var.set("Batch cancelled")
        self._batch_log(f"\n{message}\n")


def main():
    """Main entry point"""
    # On Windows, declare per-monitor DPI awareness before creating any window
    # so that the OS scales the application correctly on high-DPI displays.
    # This must be done before tk.Tk() is called.
    if _IS_WINDOWS:
        try:
            from ctypes import windll
            # PROCESS_PER_MONITOR_DPI_AWARE (2) — recommended for modern Windows
            windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            pass

    # Route early/pre-GUI logging to a rotating log file so no output appears
    # in any console window.  Crash details are written to logs/gui_crash_*.log
    # by write_gui_crash_log().
    _log_dir = APP_DIR / "logs"
    try:
        import logging.handlers
        _log_dir.mkdir(exist_ok=True)
        _file_handler = logging.handlers.RotatingFileHandler(
            _log_dir / "app.log",
            maxBytes=10 * 1024 * 1024,  # 10 MB
            backupCount=3,
            encoding="utf-8",
        )
        logging.basicConfig(
            level=logging.DEBUG,
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            handlers=[_file_handler],
            force=True,
        )
    except Exception:
        # If we can't write to a file (e.g., read-only install), fall back
        # to a NullHandler so nothing is emitted to the console.
        logging.basicConfig(
            level=logging.DEBUG,
            handlers=[logging.NullHandler()],
            force=True,
        )
    logger = logging.getLogger(__name__)

    try:
        logger.info("Starting GUI application")
        root = tk.Tk()
        logger.info("Tkinter root window created")

        try:
            app = EbookConverterGUI(root)
            logger.info("GUI initialized successfully")
            root.mainloop()
        except Exception as e:
            logger.error(f"Error during GUI initialization or runtime: {e}", exc_info=True)
            log_file = write_gui_crash_log(e)
            # Show error to user if root window exists
            try:
                messagebox.showerror(
                    "Application Error",
                    f"Failed to initialize application:\n\n{str(e)}\n\n"
                    f"Please check the log file:\n{log_file}\n\n"
                    f"Common causes:\n"
                    f"• Missing dependencies (run installer.py)\n"
                    f"• Python version incompatibility\n"
                    f"• Corrupted installation"
                )
            except Exception:
                pass
            raise
    except tk.TclError as e:
        logger.error(f"Tkinter error: {e}", exc_info=True)
        log_file = write_gui_crash_log(e)
        try:
            messagebox.showerror(
                "GUI System Error",
                f"A display error occurred:\n\n{str(e)}\n\n"
                f"This usually means tkinter is not installed properly "
                f"or no display is available.\n\nCheck the log file:\n{log_file}"
            )
        except Exception:
            pass
        sys.exit(1)
    except ImportError as e:
        logger.error(f"Import error: {e}", exc_info=True)
        log_file = write_gui_crash_log(e)
        try:
            messagebox.showerror(
                "Missing Dependencies",
                f"A required module could not be imported:\n\n{str(e)}\n\n"
                f"Please ensure all dependencies are installed:\n"
                f"  python installer.py\n\nCheck the log file:\n{log_file}"
            )
        except Exception:
            pass
        sys.exit(1)
    except Exception as e:
        logger.critical(f"Unexpected error: {e}", exc_info=True)
        log_file = write_gui_crash_log(e)
        try:
            messagebox.showerror(
                "Unexpected Error",
                f"An unexpected error occurred:\n\n{str(e)}\n\n"
                f"Check the log file:\n{log_file}"
            )
        except Exception:
            pass
        sys.exit(1)


if __name__ == '__main__':
    main()
