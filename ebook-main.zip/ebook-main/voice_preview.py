#!/usr/bin/env python3
"""
Voice Preview Tool - Generate sample audio for Kokoro TTS voices

This script helps users choose their preferred voice by:
1. Listing all available Kokoro TTS voices
2. Generating sample audio files for each voice
3. Providing information about voice characteristics
"""

import logging
from pathlib import Path
from tts_engine import TTSEngine
from kokoro_voice_catalog import KOKORO_VOICE_CATALOG

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger(__name__)


# Sample text for voice preview
SAMPLE_TEXT = """
Hello! This is a sample of this voice.
I'm reading this text so you can hear how I sound.
Consider the tone, clarity, and naturalness of my speech.
This will help you choose the best voice for your audiobook.
"""


class VoicePreview:
    """Generate voice samples for Kokoro TTS"""

    def __init__(self, output_dir: str = 'voice_samples'):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)

    def preview_kokoro_voices(self):
        """Generate samples for all Kokoro TTS voices"""
        print("\n" + "="*60)
        print("🎤 KOKORO TTS VOICE PREVIEW")
        print("="*60)

        kokoro_voices = [
            {
                'name': name,
                'description': f"{meta['gender'].title()} voice - {meta['description']}",
                'gender': meta['gender'].title(),
                'lang_code': meta['lang_code'],
            }
            for name, meta in KOKORO_VOICE_CATALOG.items()
        ]

        print(f"\nFound {len(kokoro_voices)} Kokoro TTS voices:\n")

        try:
            tts = TTSEngine(output_dir=str(self.output_dir))

            for i, voice in enumerate(kokoro_voices):
                # Display voice info
                name = voice['name']
                description = voice['description']
                gender = voice['gender']
                lang_code = voice['lang_code']

                print(f"[{i}] {name}")
                print(f"    Description: {description}")
                print(f"    Gender: {gender}")
                print(f"    Language: {lang_code}")

                # Generate sample
                try:
                    output_file = f"kokoro_{name}.wav"
                    print(f"    Generating sample... (this may take a minute)")
                    sample_path = tts.generate_audio(
                        SAMPLE_TEXT,
                        output_file,
                        voice=name,
                        lang_code=lang_code,
                        speed=1.0
                    )
                    print(f"    ✓ Sample: {sample_path}")
                except Exception as e:
                    print(f"    ✗ Failed to generate sample: {e}")

                print()

            print(f"\n✅ Generated {len(kokoro_voices)} voice samples in: {self.output_dir}")
            print(f"   Listen to each sample to find your preferred voice!")

        except ImportError:
            print("❌ Failed to import bundled Kokoro TTS.")
            print("   Ensure the kokoro_tts directory is present in the project")
            print("   Also ensure espeak-ng is installed on your system")
        except Exception as e:
            logger.error(f"❌ Error with Kokoro TTS: {e}")

    @staticmethod
    def _sanitize_filename(name: str) -> str:
        """Convert voice name to safe filename"""
        return "".join(c if c.isalnum() else "_" for c in name)[:30]

    def show_recommendations(self):
        """Show voice recommendations"""
        print("\n" + "="*60)
        print("💡 VOICE RECOMMENDATIONS")
        print("="*60)

        print("""
🎯 QUICK RECOMMENDATIONS:

For Audiobook Narration:
  • Warm Female: af_heart, af_nicole
  • Professional Female: af_sarah, af_jessica
  • Clear Male: am_adam, am_liam
  • Professional Male: am_michael, am_eric
  • British Female: bf_emma, bf_isabella, bf_alice
  • British Male: bm_george, bm_lewis, bm_daniel

For Different Moods:
  • Friendly/Warm: af_heart, af_nicole, am_santa
  • Professional: af_sarah, am_michael
  • Deep/Authoritative: am_fenrir, bm_lewis
  • Elegant: bf_isabella

⚙️  CONFIGURATION TIPS:

Language Support:
  • Kokoro supports 9 languages
  • American English (a), British English (b)
  • Spanish (e), French (f), Hindi (h)
  • Italian (i), Japanese (j), Portuguese (p), Chinese (z)
  • Set language code in config.yaml

Speed Control:
  • 0.5 - 2.0: Speaking speed multiplier
  • 1.0 = normal speed
  • 0.8 = slower for clarity
  • 1.2 = faster for energy

Testing:
  • Use max_chapters: 1 to test one chapter first
  • Start with speed: 1.0 for initial tests
  • Adjust speed based on preferences
        """)

    def run_full_preview(self):
        """Run complete voice preview"""
        print("\n" + "="*60)
        print("🎵 VOICE PREVIEW TOOL")
        print("="*60)
        print("\nThis tool will help you choose the best voice for your audiobook.")
        print("It will generate sample audio files for all available Kokoro TTS voices.\n")

        print("⚠️  Note: Generating samples may take several minutes.")
        print("   Kokoro TTS provides high-quality, natural-sounding voices.")
        print("   First-time use will download models automatically.\n")

        # Preview Kokoro
        self.preview_kokoro_voices()

        # Show recommendations
        self.show_recommendations()

        print("\n" + "="*60)
        print("✅ PREVIEW COMPLETE")
        print("="*60)
        print(f"\n📁 All samples saved to: {self.output_dir.absolute()}")
        print("\n📝 Next steps:")
        print("   1. Listen to the voice samples")
        print("   2. Note your preferred voice name")
        print("   3. Update config.yaml with your choice:")
        print("      kokoro_voice: 'af_heart'")
        print("   4. Choose your language:")
        print("      kokoro_lang_code: 'a'")
        print("   5. Set your speed preference:")
        print("      kokoro_speed: 1.0")
        print("   6. Run your ebook conversion!")
        print()


def main():
    """Main entry point"""
    preview = VoicePreview()
    preview.run_full_preview()


if __name__ == '__main__':
    main()
