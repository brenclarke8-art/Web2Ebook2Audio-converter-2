# Web to Ebook Converter - User Guide

A comprehensive tool to convert web content into EPUB books and audio files using text-to-speech.

## Table of Contents
- [Installation](#installation)
- [Quick Start](#quick-start)
- [Using the GUI](#using-the-gui)
- [Configuration](#configuration)
- [Usage Examples](#usage-examples)
- [Voice Selection](#voice-selection)
- [Advanced Features](#advanced-features)
  - [Synchronized Text Display with Audio](#synchronized-text-display-with-audio)
  - [Visual Order Extraction](#visual-order-extraction)
  - [Custom CSS for EPUB](#custom-css-for-epub)
  - [Batch Processing](#batch-processing-multiple-books)
- [Troubleshooting](#troubleshooting)

## Installation

### Prerequisites
- Windows packaged install: no preinstalled Python required
- Source install: Python 3.8+ and pip
- 3GB free disk space (for Kokoro TTS models and temporary files)
- Internet connection (for initial model download)

### Basic Installation

**Windows packaged install (recommended):**
1. Download `WebToEbookInstaller.exe` from GitHub Releases.
2. Run the installer.
3. Launch from Start Menu/Desktop shortcut.

**Source install (all platforms):**
```bash
git clone https://github.com/brenclarke8-art/ebook.git
cd ebook
python installer.py
```

The installer provides:
- Automatic dependency installation
- PyTorch setup with optimized CPU-only pre-built wheels
- Kokoro TTS installation
- Interactive configuration
- Clear instructions for first-time setup

Source launcher/install scripts:
- Linux/macOS install helper: `./install_app.sh`
- Windows source launcher: `run_app.bat`
- Linux/macOS source launcher: `./run_app.sh`

After installation, launch the app with:
- Windows: `run_app.bat`
- Linux/macOS: `./run_app.sh`

### First-Time Setup - Model Download

**IMPORTANT:** When you first use Kokoro TTS (by running voice_preview.py or generating your first audiobook), the system will automatically download the voice models.

**What to expect:**
- **Download size**: ~2GB
- **Time required**: 5-10 minutes (depends on internet speed)
- **Location**: Models are cached in your local cache directory
- **Frequency**: One-time download; cached for all future use
- **Requirements**: Stable internet connection during download

**When does the download happen?**
- First time you run `python voice_preview.py`
- First time you generate audio through GUI or command line
- The download is automatic - no manual steps needed

**After the first download:**
- All voice models are cached locally
- Future audio generation is much faster
- No internet connection needed for audio generation
- Models persist across sessions

### Manual Package Installation

```bash
# Install required packages
pip install requests beautifulsoup4 ebooklib PyYAML torch soundfile numpy huggingface_hub loguru misaki[en] transformers
```

**Note:** Kokoro TTS is bundled in the project (in the `kokoro_tts/` directory), so you don't need to install it via pip.

## Quick Start

### 1. Using the Graphical Interface (Recommended)

The easiest way to use the converter is through the GUI:

```bash
# Linux/macOS
./run_app.sh
# Windows
run_app.bat
```

**First-time GUI users:** If you haven't run voice_preview.py yet, the model download will happen when you first start audio conversion. The GUI will show progress, but the first conversion may take 5-10 minutes longer than usual due to the download.

**GUI Features:**
- **Converter Tab**: Main interface for converting web pages
  - URL input area (paste multiple URLs, one per line)
  - Book information (title, author, output directory)
  - TTS settings with visual controls
  - Speech rate slider
  - Voice preview button
  - Real-time progress display with logs

- **Advanced Settings Tab**:
  - Chapter and duration limits
  - CSS selector customization
  - Load/save configuration files

**Quick Workflow:**
1. Launch the GUI: `run_app.bat` (Windows) or `./run_app.sh` (Linux/macOS)
2. Paste your URLs in the URL input area
3. Configure book title and author
4. (Optional) Click "Preview Voices" to choose your preferred voice
5. Select TTS engine and voice settings
6. Click "Start Conversion"
7. Monitor progress in the log area
8. Find your files in the output directory

### 2. Basic Usage with Python Code

```python
from config import Config
from main import WebToEbookApp

# Create configuration
config = Config(
    kokoro_voice='Claribel Dervla',
    kokoro_lang_code='a',
    kokoro_speed=1.0,
    epub_title='My Book',
    epub_author='Author Name'
)

# Initialize app
app = WebToEbookApp(config)

# Process URLs
urls = [
    'https://example.com/chapter1',
    'https://example.com/chapter2',
]

result = app.process(urls, output_name='My Book')
```

### 3. Using Configuration File (For Command Line)

Create a `config.yaml` file:

```yaml
# Book Information
epub_title: "My Awesome Book"
epub_author: "John Doe"

# Kokoro TTS Settings
kokoro_voice: "af_heart"  # Voice name
kokoro_lang_code: "a"             # Language code
kokoro_speed: 1.0                 # Speed multiplier (0.5 to 2.0)

# Speech Rate (for synchronized text)
speech_rate: 150       # Words per minute (100-300)

# Output Settings
output_dir: "output"

# Stop Conditions
max_chapters: 10       # Stop after X chapters (0 = no limit)
max_duration: 0        # Stop after X minutes (0 = no limit)

# CSS Selectors for Content Extraction
css_selectors:
  - "article"
  - ".content"
  - ".post-content"
  - "main"
```

Then load it in your script:

```python
from config import Config
from main import WebToEbookApp

# Load config from YAML
config = Config.from_yaml('config.yaml')
app = WebToEbookApp(config)

# Process URLs
urls = ['https://example.com/chapter1']
result = app.process(urls)
```

## Configuration

### Voice Selection with Kokoro TTS

Coqui TTS Kokoro TTS provides high-quality, natural-sounding voices with multilingual support.

#### Finding Available Voices

Run the voice preview script to hear samples of all available voices:

```bash
python voice_preview.py
```

This will:
1. Trigger the automatic model download (~2GB) on first run
2. List all available Kokoro TTS voices
3. Generate sample audio files for each voice
4. Create sample files in the `voice_samples` directory

**First run note:** The first time you run this command, it will download the Kokoro TTS models (~2GB). This is a one-time download that may take 5-10 minutes. Subsequent runs will be much faster.

Listen to the samples and note the voice name you prefer.

#### Popular Kokoro TTS Voices

**Female Voices:**
- `Claribel Dervla` - Clear and professional
- `Daisy Studious` - Young and energetic
- `Gracie Wise` - Warm and friendly
- `Tammie Ema` - Smooth narrator
- `Alison Dietlinde` - Professional and clear
- `Ana Florence` - Soft and pleasant

**Male Voices:**
- `Andrew Chipper` - Energetic and young
- `Badr Odhiambo` - Deep and resonant
- `Dionisio Schuyler` - Professional
- `Royston Min` - Clear narrator
- `Viktor Eka` - Authoritative
- `Torcull Diarmuid` - British accent

#### Supported Languages

Kokoro TTS supports 14+ languages including:
- English (en), Spanish (es), French (fr), German (de)
- Italian (it), Portuguese (pt), Polish (pl), Turkish (tr)
- Russian (ru), Dutch (nl), Czech (cs), Arabic (ar)
- Chinese (zh-cn), Japanese (ja)

### Voice Configuration

Configure voice settings in `config.yaml`:

```yaml
kokoro_voice: "af_heart"  # Voice name
kokoro_lang_code: "a"             # Language code
kokoro_speed: 1.0                 # Speed multiplier (0.5-2.0)
```

### Speed and Playback Settings

Adjust `speech_rate` to control speaking speed:
- **100-130**: Slow, clear pronunciation
- **130-170**: Normal conversational speed
- **170-250**: Fast, for experienced listeners
- **250+**: Very fast, challenging to follow

### Chapter and Time Limits

Control how much content is processed:

```yaml
max_chapters: 5        # Process only first 5 chapters
max_duration: 60       # Stop after 60 minutes of audio
```

**Use cases**:
- **max_chapters**: Sample first few chapters before committing to a full book
- **max_duration**: Create podcast-length content for commutes

### Cloudflare and Existing Browser Mode

If Cloudflare keeps flagging automated browser traffic, use your own Edge session and let the scraper attach to it.

#### Step 1: Start Edge with remote debugging

- **Windows**
  ```bash
  msedge.exe --remote-debugging-port=9222 --guest
  ```
- **Linux**
  ```bash
  microsoft-edge --remote-debugging-port=9222 --guest
  ```
- **macOS**
  ```bash
  /Applications/Microsoft\ Edge.app/Contents/MacOS/Microsoft\ Edge --remote-debugging-port=9222 --guest
  ```

#### Step 2: Open the target site manually

In that same Edge window:
- Open the website
- Complete Cloudflare challenge/login
- Keep the browser open

#### Step 3: Enable attach mode in config

```yaml
use_existing_browser: true
browser_cdp_url: "http://127.0.0.1:9222"
manual_cloudflare_bypass: true   # optional fallback if attach fails
```

The scraper will reuse that authenticated browser session across chapters.

## Usage Examples

### Example 1: Convert a Blog Series to Audiobook

```python
from config import Config
from main import WebToEbookApp

config = Config.from_yaml('config.yaml')
app = WebToEbookApp(config)

urls = [
    'https://myblog.com/post/part-1',
    'https://myblog.com/post/part-2',
    'https://myblog.com/post/part-3',
]

result = app.process(urls, output_name='Blog Series')
print(f"Created {result['chapters']} chapters")
print(f"EPUB: {result['epub']}")
print(f"Audio: {result['audio']}")
```

### Example 2: Convert Documentation to Audio Guide

```python
config = Config(
    kokoro_voice='Royston Min',
    kokoro_lang_code='a',
    kokoro_speed=1.1,
    epub_title='API Documentation',
    epub_author='Tech Team',
    css_selectors=['.documentation', '.doc-content']
)

app = WebToEbookApp(config)
urls = ['https://docs.example.com/getting-started']
result = app.process(urls)
```

### Example 3: Create Sample Preview

```python
# Test first 3 chapters with 30-minute limit
config = Config.from_yaml('config.yaml')
config.max_chapters = 3
config.max_duration = 30

app = WebToEbookApp(config)
result = app.process(urls, output_name='Preview')
```

### Example 4: Custom CSS Selectors

For websites with unique layouts:

```python
config = Config(
    css_selectors=[
        '.story-content',    # Main content
        '.chapter-text',      # Chapter text
        '#main-article'       # Article ID
    ]
)
```

## Advanced Features

### Synchronized Text Display with Audio

The converter automatically generates an interactive HTML file that synchronizes the text with audio playback, allowing you to read along as the audio plays.

#### Features

- **Word-level highlighting**: Each word is highlighted as it's being spoken (default mode)
- **Sentence-level highlighting**: The entire sentence is highlighted while being read
- **Auto-scrolling**: The page automatically scrolls to keep the current position in view
- **Toggle modes**: Switch between word, sentence, or no highlighting
- **Responsive design**: Works on desktop, tablet, and mobile devices

#### How to Use

1. After conversion, locate the generated `{book_name}_sync.html` file in the output directory
2. Open the HTML file in any modern web browser
3. The audio player will be embedded at the top of the page
4. Click play to start the audio and watch the text highlight in sync

#### Highlight Modes

- **Word Mode** (default): Highlights individual words as they're spoken
  - Best for: Following along word-by-word, language learning
  - Visual: Yellow highlight on current word

- **Sentence Mode**: Highlights the entire sentence being read
  - Best for: Understanding context, less visual distraction
  - Visual: Light yellow background on current sentence

- **Off Mode**: Disables highlighting but keeps audio synced
  - Best for: Reading at your own pace while audio plays

#### Customization

The timing is automatically calculated based on your configured speech rate:
- Faster speech rates (180+ WPM) result in quicker transitions
- Slower speech rates (120-150 WPM) give more time per word
- Punctuation adds natural pauses between sentences

#### Tips

- Use headphones for the best audio experience
- Switch to sentence mode if word highlighting is too distracting
- The HTML file is self-contained and can be shared or saved for offline use
- Kokoro TTS provides high-quality, natural-sounding narration

### Visual Order Extraction

Some websites use CSS positioning (flexbox, grid, absolute positioning) that causes text to appear in a different order than the HTML source code. This can result in ebooks where sidebars, navigation, or other elements are mixed into the main content in the wrong order.

#### The Problem

Modern websites often use CSS to position elements visually:
- Sidebars that appear on the right but are defined first in HTML
- Grid layouts where visual order differs from DOM order
- Absolute/fixed positioning for headers, footers, and callouts
- Flexbox with order properties that change visual flow

When scraping these sites, the text may be extracted in HTML order rather than visual reading order.

#### The Solution

Enable **Visual Order Extraction** to analyze the page layout and extract text in the order it appears visually (top-to-bottom, left-to-right).

#### How to Enable

**Via GUI:**
1. Open the Advanced Settings tab
2. Check "Use Visual Order (for pages with incorrect HTML order)"
3. Run your conversion

**Via Configuration File:**
```yaml
use_visual_order: true
```

**Via Python Code:**
```python
from config import Config
from main import WebToEbookApp

config = Config(
    use_visual_order=True,
    # ... other settings
)
app = WebToEbookApp(config)
result = app.process(urls)
```

#### How It Works

The visual order extractor:
1. **Analyzes CSS positioning** from inline styles and class names
2. **Detects layout hints** like 'left', 'right', 'top', 'bottom' in classes
3. **Parses position values** from inline styles (top, left properties)
4. **Sorts elements** by their estimated visual position (top-to-bottom, left-to-right)
5. **Preserves block structure** for paragraphs, headings, and lists

#### When to Use

Enable this feature if:
- Your ebook has text in the wrong order
- Sidebar content appears mixed with main content
- Navigation or footer text appears in the middle of chapters
- The website uses complex CSS layouts (grid, flexbox)
- Visual layout differs significantly from HTML structure

#### Limitations

This is a heuristic approach that works well for common layouts. For complex layouts or websites heavily reliant on JavaScript rendering, the results may vary. The extractor:
- Works best with inline styles and semantic CSS classes
- Cannot execute JavaScript or fully render the page
- Uses position hints rather than actual computed layout

For more accurate results with complex layouts, consider using the site's RSS feed or reader view if available.

### Custom CSS for EPUB

Create custom styling for your ebook:

```python
custom_css = """
body {
    font-family: 'Arial', sans-serif;
    font-size: 14pt;
    background-color: #f5f5f5;
}
h1 {
    color: #0066cc;
    text-align: center;
}
"""

epub_path = ebook_gen.create_epub(
    chapters,
    'My Book',
    'Author',
    custom_css=custom_css
)
```

### Batch Processing Multiple Books

```python
books = [
    {
        'name': 'Book 1',
        'urls': ['https://site.com/book1/ch1', 'https://site.com/book1/ch2']
    },
    {
        'name': 'Book 2',
        'urls': ['https://site.com/book2/ch1', 'https://site.com/book2/ch2']
    }
]

for book in books:
    result = app.process(book['urls'], output_name=book['name'])
    print(f"✓ Completed {book['name']}")
```

### Error Handling

```python
try:
    result = app.process(urls)
except requests.exceptions.RequestException as e:
    print(f"Network error: {e}")
except Exception as e:
    print(f"Processing error: {e}")
```

## Troubleshooting

### Common Issues

#### 1. "No module named 'TTS'"
```bash
pip install TTS torch torchaudio
```

#### 2. Torch installation issues on Windows
Use the installer.py script which handles torch installation automatically, or install manually:
```bash
pip install torch torchaudio --index-url https://download.pytorch.org/whl/cpu
pip install TTS
```

#### 3. First audio generation takes very long
This is expected on first run! Kokoro TTS is downloading the voice models (~2GB). This happens once:
- **First time**: 5-10 minutes (includes model download + audio generation)
- **Subsequent times**: Much faster (only audio generation)
- **Solution**: Be patient during first run, ensure stable internet connection

#### 4. Model download fails or times out
If the automatic model download fails:
- Check your internet connection
- Ensure you have 3GB free disk space
- Try running voice_preview.py again - it will resume the download
- Check firewall settings aren't blocking the download

#### 5. "Failed to extract content"
- Check your CSS selectors
- Try using default selectors (remove custom ones)
- Inspect the webpage structure

#### 6. Audio file is silent or corrupted
- Verify Kokoro TTS voice name is correct (use voice_preview.py)
- Check that torch and TTS are properly installed
- Ensure sufficient disk space (3GB+)
- Verify models downloaded completely on first run

#### 7. EPUB doesn't open properly
- Update epub reader application
- Check that all URLs were scraped successfully
- Verify chapter content is not empty

### Getting Help

- Check existing issues: https://github.com/brenclarke8-art/ebook/issues
- Create a new issue with:
  - Python version
  - Error message
  - Sample URL (if public)
  - Configuration used

## Best Practices

1. **Test with one URL first** before processing many chapters
2. **Use voice_preview.py** to find your preferred voice
3. **Start with default CSS selectors**, customize only if needed
4. **Set max_chapters during testing** to avoid long processing times
5. **Keep URLs from the same website** for consistent formatting
6. **Check robots.txt** and respect website terms of service
7. **Add delays between requests** for large batches (modify scraper.py)

## Output Files

All generated files are saved in the `output` directory:
- `{book_name}.epub` - EPUB ebook file
- `{book_name}.wav` - Audio file (WAV format)
- `voice_samples/` - Sample voice previews (if generated)

## Performance Tips

- **Kokoro TTS**: First run downloads models (~2GB), subsequent runs are faster
- **Large books**: Consider splitting into volumes or using chapter ranges
- **Audio quality**: WAV files are large; convert to MP3 if needed
- **Processing time**: Expect 1-3 minutes per chapter depending on length and hardware

## License

MIT License - See repository for details

## Contributing

Contributions welcome! Please submit pull requests or issues on GitHub.
