#!/usr/bin/env bash
# Uninstaller launcher for Web to Ebook Converter (Linux / macOS)
set -eu

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

run_uninstaller() {
    local python_cmd="$1"
    echo "Running uninstaller with $python_cmd..."
    "$python_cmd" "$SCRIPT_DIR/uninstaller.py"
    return $?
}

# Prefer the app-local virtual environment, then fall back to system Python.
if [ -f "$SCRIPT_DIR/.venv/bin/python3" ]; then
    run_uninstaller "$SCRIPT_DIR/.venv/bin/python3"
    exit $?
fi

if command -v python3 >/dev/null 2>&1; then
    run_uninstaller python3
    exit $?
fi

if command -v python >/dev/null 2>&1; then
    run_uninstaller python
    exit $?
fi

echo "[!] Python interpreter not found."
echo "    Install Python 3 and run: python3 uninstaller.py"
exit 1
