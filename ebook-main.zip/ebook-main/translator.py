#!/usr/bin/env python3
"""
Translation Module for Web to Ebook Converter

Supports AI-powered translation with custom rules for character names,
pronouns, and other translation preferences.
Includes context-aware pronoun analysis for intelligent pronoun handling.
"""

import logging
import re
from typing import Dict, List, Optional
from dataclasses import dataclass, field
from pronoun_analyzer import PronounAnalyzer, CharacterProfile

logger = logging.getLogger(__name__)


@dataclass
class TranslationRule:
    """Custom translation rule"""
    pattern: str  # Text to find (can be regex)
    replacement: str  # Text to replace with
    is_regex: bool = False
    case_sensitive: bool = True


@dataclass
class TranslationConfig:
    """Translation configuration"""
    enabled: bool = False
    source_language: str = 'auto'  # auto-detect or specific language code
    target_language: str = 'en'

    # AI Translation settings
    api_url: str = 'http://localhost:5000/translate'  # Local AI translator
    api_key: Optional[str] = None

    # Custom rules for consistent translation
    custom_rules: List[TranslationRule] = field(default_factory=list)

    # Common rule presets
    preserve_honorifics: bool = True  # Keep -san, -kun, -sama, etc.
    preserve_names: bool = True  # Don't translate character names

    # Pronoun analysis settings
    enable_pronoun_analysis: bool = True  # Analyze and fix pronouns automatically
    character_genders: Optional[Dict[str, str]] = None  # Manual character gender mapping
    auto_detect_characters: bool = True  # Automatically detect character names


class LanguageDetector:
    """Simple language detection"""

    # Common words in different languages for basic detection
    LANGUAGE_PATTERNS = {
        'ja': ['の', 'は', 'を', 'に', 'で', 'と', 'が', 'も', 'から', 'まで'],
        'zh': ['的', '了', '是', '在', '我', '有', '和', '人', '这', '中'],
        'ko': ['은', '는', '이', '가', '을', '를', '의', '에', '와', '과'],
        'ru': ['и', 'в', 'не', 'на', 'я', 'что', 'с', 'он', 'а', 'как'],
        'es': ['de', 'la', 'que', 'el', 'en', 'y', 'a', 'los', 'se', 'del'],
        'fr': ['de', 'la', 'le', 'et', 'des', 'les', 'du', 'un', 'une', 'dans'],
        'de': ['der', 'die', 'und', 'in', 'den', 'von', 'zu', 'das', 'mit', 'sich'],
    }

    @staticmethod
    def detect_language(text: str) -> str:
        """Detect language from text sample"""
        if not text or len(text) < 50:
            return 'unknown'

        # Check for ASCII-only (likely English)
        try:
            text.encode('ascii')
            # Contains only ASCII - likely English
            return 'en'
        except UnicodeEncodeError:
            pass

        # Count matches for each language
        text_lower = text.lower()
        scores = {}

        for lang, patterns in LanguageDetector.LANGUAGE_PATTERNS.items():
            score = sum(1 for pattern in patterns if pattern in text_lower)
            if score > 0:
                scores[lang] = score

        if not scores:
            return 'unknown'

        # Return language with highest score
        return max(scores, key=scores.get)


class Translator:
    """AI-powered translator with custom rules and context-aware pronoun analysis"""

    def __init__(self, config: TranslationConfig):
        logger.debug("Initializing Translator")
        self.config = config
        logger.debug(f"Translation config: enabled={config.enabled}, source={config.source_language}, target={config.target_language}")
        self.detector = LanguageDetector()
        logger.debug("LanguageDetector initialized")
        self.pronoun_analyzer = PronounAnalyzer() if config.enable_pronoun_analysis else None
        if self.pronoun_analyzer:
            logger.debug("PronounAnalyzer initialized")
        else:
            logger.debug("Pronoun analysis disabled")

    def translate_text(self, text: str) -> str:
        """Translate text using AI translator"""
        logger.debug(f"translate_text called: text_length={len(text)}")
        if not self.config.enabled:
            logger.debug("Translation disabled, returning original text")
            return text

        if not text or not text.strip():
            logger.debug("Empty text provided, returning as-is")
            return text

        # Detect language if auto-detect is enabled
        source_lang = self.config.source_language
        if source_lang == 'auto':
            logger.debug("Auto-detecting source language")
            source_lang = self.detector.detect_language(text)
            logger.info(f"Detected language: {source_lang}")

        # Skip if already in target language
        if source_lang == self.config.target_language:
            logger.info(f"Text already in target language ({self.config.target_language}), skipping translation")
            return text

        # Skip if language is unknown
        if source_lang == 'unknown':
            logger.warning("Could not detect language, skipping translation")
            return text

        # Translate using AI
        try:
            logger.debug(f"Calling AI translator: {source_lang} -> {self.config.target_language}")
            translated = self._call_ai_translator(text, source_lang, self.config.target_language)
            logger.debug(f"Translation received: {len(translated)} characters")

            # Apply custom rules
            logger.debug("Applying custom translation rules")
            translated = self._apply_custom_rules(translated)
            logger.debug("Custom rules applied")

            return translated
        except Exception as e:
            logger.error(f"Translation failed: {e}")
            logger.debug(f"Exception type: {type(e).__name__}")
            logger.warning("Returning original text")
            return text

    def translate_chapters(self, chapters: List[Dict]) -> List[Dict]:
        """Translate all chapters with pronoun analysis"""
        logger.debug(f"translate_chapters called with {len(chapters)} chapters")
        if not self.config.enabled:
            logger.debug("Translation disabled, returning original chapters")
            return chapters

        logger.info(f"🌐 Translating {len(chapters)} chapters...")

        # Step 1: Perform pronoun analysis on all translated content
        if self.pronoun_analyzer and self.config.enable_pronoun_analysis:
            logger.debug("Pronoun analysis enabled")
            logger.info("📊 Analyzing pronouns and character relationships...")
            logger.debug("Starting pronoun analysis on all chapters")
            self._analyze_pronouns_in_chapters(chapters)
            logger.debug("Pronoun analysis complete")

        # Step 2: Translate chapters
        logger.debug("Starting chapter translation loop")
        translated_chapters = []
        for i, chapter in enumerate(chapters, 1):
            logger.debug(f"Translating chapter {i}/{len(chapters)}")
            logger.info(f"[{i}/{len(chapters)}] Translating: {chapter.get('title', 'Untitled')}")

            logger.debug(f"Translating title: '{chapter['title']}'")
            translated_title = self.translate_text(chapter['title'])
            logger.debug(f"Title translated to: '{translated_title}'")

            logger.debug(f"Translating content: {len(chapter['content'])} characters")
            translated_content = self.translate_text(chapter['content'])
            logger.debug(f"Content translated: {len(translated_content)} characters")

            translated_chapter = {
                'url': chapter['url'],
                'title': translated_title,
                'content': translated_content
            }

            translated_chapters.append(translated_chapter)
            logger.info(f"✓ Translated chapter {i}")

        # Step 3: Apply pronoun corrections if analysis was done
        if self.pronoun_analyzer and self.config.enable_pronoun_analysis:
            logger.info("🔧 Applying pronoun corrections based on analysis...")
            logger.debug("Starting pronoun correction process")
            translated_chapters = self._apply_pronoun_corrections(translated_chapters)
            logger.debug("Pronoun corrections applied")

        logger.info("✅ Translation complete!")
        logger.debug(f"Returning {len(translated_chapters)} translated chapters")
        return translated_chapters

    def _analyze_pronouns_in_chapters(self, chapters: List[Dict]):
        """Analyze pronouns across all chapters to build character profiles"""
        logger.debug("Starting pronoun analysis across all chapters")
        # Combine all chapter content for analysis
        combined_text = '\n\n'.join([ch['content'] for ch in chapters])
        logger.debug(f"Combined text for analysis: {len(combined_text)} characters")

        # Get known characters if configured
        known_characters = None
        if self.config.character_genders:
            known_characters = list(self.config.character_genders.keys())
            logger.debug(f"Using {len(known_characters)} known characters from config: {known_characters}")
        else:
            logger.debug("No character gender configuration provided")

        # Perform analysis
        logger.debug("Calling pronoun analyzer")
        self.pronoun_analyzer.analyze_text(combined_text, known_characters=known_characters)

        # Log analysis results
        logger.info(f"Found {len(self.pronoun_analyzer.characters)} characters")
        logger.debug(f"Characters found: {list(self.pronoun_analyzer.characters.keys())}")

        # Generate pronoun correction rules based on character gender mappings
        if self.config.character_genders:
            logger.debug("Generating pronoun correction rules from character genders")
            correction_rules = self.pronoun_analyzer.get_pronoun_correction_rules(
                self.config.character_genders
            )

            # Add these rules to custom rules
            logger.debug(f"Adding {len(correction_rules)} pronoun correction rules")
            for rule in correction_rules:
                self.add_rule(
                    pattern=rule['pattern'],
                    replacement=rule['replacement'],
                    is_regex=rule['is_regex'],
                    case_sensitive=rule.get('case_sensitive', True)
                )

            logger.info(f"Generated {len(correction_rules)} pronoun correction rules")
        else:
            logger.debug("No character gender mappings configured, skipping rule generation")

    def _apply_pronoun_corrections(self, chapters: List[Dict]) -> List[Dict]:
        """Apply pronoun corrections to translated chapters"""
        corrected_chapters = []

        for chapter in chapters:
            corrected_chapter = {
                'url': chapter['url'],
                'title': chapter['title'],
                'content': self._apply_custom_rules(chapter['content'])
            }
            corrected_chapters.append(corrected_chapter)

        return corrected_chapters

    def get_pronoun_analysis_report(self) -> Optional[str]:
        """Get a report of pronoun analysis results"""
        if self.pronoun_analyzer:
            return self.pronoun_analyzer.generate_report()
        return None

    def get_character_profiles(self) -> Dict[str, CharacterProfile]:
        """Get detected character profiles"""
        if self.pronoun_analyzer:
            return self.pronoun_analyzer.characters
        return {}

    def _call_ai_translator(self, text: str, source_lang: str, target_lang: str) -> str:
        """Call AI translation API"""
        # Try using requests if available
        try:
            import requests

            payload = {
                'text': text,
                'source': source_lang,
                'target': target_lang
            }

            headers = {}
            if self.config.api_key:
                headers['Authorization'] = f'Bearer {self.config.api_key}'

            response = requests.post(
                self.config.api_url,
                json=payload,
                headers=headers,
                timeout=300  # 5 minutes for long texts
            )

            response.raise_for_status()
            result = response.json()

            # Handle different API response formats
            if 'translated_text' in result:
                return result['translated_text']
            elif 'translation' in result:
                return result['translation']
            elif 'text' in result:
                return result['text']
            else:
                raise ValueError(f"Unexpected API response format: {result}")

        except ImportError:
            logger.error("requests library not available")
            raise
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {e}")
            raise

    def _apply_custom_rules(self, text: str) -> str:
        """Apply custom translation rules"""
        if not self.config.custom_rules:
            return text

        result = text
        for rule in self.config.custom_rules:
            try:
                if rule.is_regex:
                    flags = 0 if rule.case_sensitive else re.IGNORECASE
                    result = re.sub(rule.pattern, rule.replacement, result, flags=flags)
                else:
                    if rule.case_sensitive:
                        result = result.replace(rule.pattern, rule.replacement)
                    else:
                        # Case-insensitive replacement
                        pattern = re.compile(re.escape(rule.pattern), re.IGNORECASE)
                        result = pattern.sub(rule.replacement, result)
            except Exception as e:
                logger.warning(f"Failed to apply rule '{rule.pattern}' -> '{rule.replacement}': {e}")

        return result

    def add_rule(self, pattern: str, replacement: str, is_regex: bool = False, case_sensitive: bool = True):
        """Add a custom translation rule"""
        rule = TranslationRule(
            pattern=pattern,
            replacement=replacement,
            is_regex=is_regex,
            case_sensitive=case_sensitive
        )
        self.config.custom_rules.append(rule)
        logger.info(f"Added translation rule: '{pattern}' -> '{replacement}'")

    def clear_rules(self):
        """Clear all custom rules"""
        self.config.custom_rules.clear()
        logger.info("Cleared all custom translation rules")


# Preset rule builders for common use cases
class TranslationRulePresets:
    """Common translation rule presets"""

    @staticmethod
    def character_name_rule(original_name: str, translated_name: str) -> TranslationRule:
        """Create rule to consistently translate a character name"""
        return TranslationRule(
            pattern=f"\\b{re.escape(original_name)}\\b",
            replacement=translated_name,
            is_regex=True,
            case_sensitive=True
        )

    @staticmethod
    def pronoun_rule(source_pronoun: str, target_pronoun: str) -> TranslationRule:
        """Create rule to fix pronoun translation"""
        return TranslationRule(
            pattern=f"\\b{re.escape(source_pronoun)}\\b",
            replacement=target_pronoun,
            is_regex=True,
            case_sensitive=False
        )

    @staticmethod
    def honorific_preservation_rules() -> List[TranslationRule]:
        """Rules to preserve Japanese honorifics"""
        honorifics = ['-san', '-kun', '-chan', '-sama', '-senpai', '-sensei', '-dono']
        rules = []
        for honorific in honorifics:
            # Prevent translation of honorifics
            rules.append(TranslationRule(
                pattern=honorific,
                replacement=honorific,
                is_regex=False,
                case_sensitive=True
            ))
        return rules

    @staticmethod
    def term_consistency_rule(original_term: str, preferred_translation: str) -> TranslationRule:
        """Create rule for consistent term translation"""
        return TranslationRule(
            pattern=f"\\b{re.escape(original_term)}\\b",
            replacement=preferred_translation,
            is_regex=True,
            case_sensitive=False
        )


def create_translator_from_dict(config_dict: dict) -> Translator:
    """Create translator from configuration dictionary"""
    # Extract custom rules if present
    rules = []
    if 'custom_rules' in config_dict:
        for rule_data in config_dict['custom_rules']:
            rules.append(TranslationRule(**rule_data))
        config_dict = config_dict.copy()
        config_dict['custom_rules'] = rules

    translation_config = TranslationConfig(**config_dict)
    return Translator(translation_config)


# Example usage
if __name__ == '__main__':
    # Example: Basic translation
    config = TranslationConfig(
        enabled=True,
        source_language='ja',
        target_language='en',
        api_url='http://localhost:5000/translate'
    )

    translator = Translator(config)

    # Add custom rules
    translator.add_rule('Naruto', 'Naruto', is_regex=False)  # Keep name unchanged
    translator.add_rule('\\bhe\\b', 'she', is_regex=True, case_sensitive=False)  # Fix pronoun

    # Example translation
    text = "これは日本語のテキストです。"
    translated = translator.translate_text(text)
    print(f"Original: {text}")
    print(f"Translated: {translated}")
