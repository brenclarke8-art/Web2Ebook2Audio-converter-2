#!/usr/bin/env python3
"""Build Windows distribution folder with Nuitka."""

from __future__ import annotations

import argparse
import importlib.util
import platform
import shutil
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.resolve()
ENTRYPOINT = PROJECT_ROOT / "app.py"
BUILD_ROOT = PROJECT_ROOT / "build" / "nuitka"
NUITKA_OUTPUT_ROOT = BUILD_ROOT / "output"
DIST_DIR = PROJECT_ROOT / "dist"

EXTRA_DIRS = ("models", "assets", "config", "qt")
EXTRA_FILES = ("config.yaml",)


def run_command(command: list[str], step_name: str) -> None:
    print(f"[RUN] {step_name}: {' '.join(command)}")
    try:
        subprocess.run(command, check=True)
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(f"{step_name} failed with exit code {exc.returncode}") from exc


def clean_directories() -> None:
    for path in (BUILD_ROOT, DIST_DIR):
        if path.exists():
            shutil.rmtree(path)


def build_with_nuitka(minimal_models: bool) -> Path:
    if not ENTRYPOINT.exists():
        raise FileNotFoundError(f"Entrypoint not found: {ENTRYPOINT}")

    if importlib.util.find_spec("nuitka") is None:
        raise RuntimeError(
            "Nuitka is not installed. Install it first with: "
            f"{sys.executable} -m pip install nuitka"
        )

    NUITKA_OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    command: list[str] = [
        sys.executable,
        "-m",
        "nuitka",
        str(ENTRYPOINT),
        "--standalone",
        "--assume-yes-for-downloads",
        "--follow-imports",
        "--enable-plugin=tk-inter",
        "--windows-console-mode=disable",
        f"--output-dir={NUITKA_OUTPUT_ROOT}",
        "--output-filename=app.exe",
        # Disable torch JIT for faster compilation and smaller binary
        "--module-parameter=torch-disable-jit=yes",
        # Explicitly disable spacy plugin (not used in this project)
        "--nofollow-import-to=spacy",
    ]

    # On non-Windows, use MinGW to cross-compile for Windows
    if platform.system() != "Windows":
        command.append("--mingw64")

    if importlib.util.find_spec("PySide6") is not None:
        command.append("--enable-plugin=pyside6")

    if not minimal_models:
        models_dir = PROJECT_ROOT / "models"
        if models_dir.is_dir():
            command.append(f"--include-data-dir={models_dir}=models")

    for directory_name in EXTRA_DIRS:
        if directory_name == "models":
            continue
        directory = PROJECT_ROOT / directory_name
        if directory.is_dir():
            command.append(f"--include-data-dir={directory}={directory_name}")

    run_command(command, "Nuitka compilation")

    app_dist_dir = NUITKA_OUTPUT_ROOT / "app.dist"
    if not app_dist_dir.is_dir():
        raise RuntimeError(f"Nuitka output folder not found: {app_dist_dir}")
    return app_dist_dir


def _copy_tree_contents(source_dir: Path, target_dir: Path) -> None:
    for child in source_dir.iterdir():
        destination = target_dir / child.name
        if child.is_dir():
            shutil.copytree(child, destination, dirs_exist_ok=True)
        else:
            shutil.copy2(child, destination)


def assemble_distribution(app_dist_dir: Path, minimal_models: bool) -> None:
    DIST_DIR.mkdir(parents=True, exist_ok=True)
    _copy_tree_contents(app_dist_dir, DIST_DIR)

    for directory_name in EXTRA_DIRS:
        if minimal_models and directory_name == "models":
            continue
        source = PROJECT_ROOT / directory_name
        destination = DIST_DIR / directory_name
        if source.is_dir() and source.resolve() != destination.resolve():
            shutil.copytree(source, destination, dirs_exist_ok=True)
        elif not source.exists():
            # Keep a predictable dist layout for installer packaging,
            # even when optional source directories are absent in the repository.
            destination.mkdir(parents=True, exist_ok=True)

    for file_name in EXTRA_FILES:
        source = PROJECT_ROOT / file_name
        destination = DIST_DIR / file_name
        if source.is_file() and source.resolve() != destination.resolve():
            shutil.copy2(source, destination)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build dist/ with Nuitka.")
    parser.add_argument(
        "--minimal-models",
        action="store_true",
        help="Do not bundle project-local models/ into dist/.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    clean_directories()
    app_dist_dir = build_with_nuitka(minimal_models=args.minimal_models)
    assemble_distribution(app_dist_dir, minimal_models=args.minimal_models)
    print(f"Build complete: {DIST_DIR}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
