#!/usr/bin/env python3
"""Build Windows installer using PyInstaller bootstrap or Nuitka and Inno Setup."""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.resolve()
ISS_FILE = PROJECT_ROOT / "windows_installer.iss"
DIST_DIR = PROJECT_ROOT / "dist"
INSTALLER_OUTPUT_DIR = PROJECT_ROOT / "installer_output"
PYINSTALLER_BOOTSTRAP_SCRIPT = PROJECT_ROOT / "build_pyinstaller_bootstrap.py"


def run_command(command: list[str]) -> None:
    print("Running:", " ".join(command))
    subprocess.run(command, check=True)


def resolve_iscc() -> str:
    env_path = os.environ.get("INNO_SETUP_COMPILER")
    if env_path and Path(env_path).exists():
        return env_path

    path_candidate = shutil.which("iscc")
    if path_candidate:
        return path_candidate

    default_paths = [
        Path(r"C:\Program Files (x86)\Inno Setup 6\ISCC.exe"),
        Path(r"C:\Program Files\Inno Setup 6\ISCC.exe"),
    ]
    for candidate in default_paths:
        if candidate.exists():
            return str(candidate)

    raise FileNotFoundError(
        "Inno Setup Compiler (ISCC.exe) not found. "
        "Install Inno Setup and/or set INNO_SETUP_COMPILER."
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build Windows installer.")
    parser.add_argument(
        "--method",
        choices=["pyinstaller", "nuitka"],
        default="pyinstaller",
        help=(
            "Build method: pyinstaller (fast, lightweight bootstrap) or "
            "nuitka (slow, full bundle). Default: pyinstaller"
        ),
    )
    parser.add_argument(
        "--skip-build",
        action="store_true",
        help="Skip build step and use existing output (for nuitka method only).",
    )
    parser.add_argument(
        "--minimal-models",
        action="store_true",
        help="Pass --minimal-models to build_nuitka.py (for nuitka method only).",
    )
    parser.add_argument(
        "--version",
        default=os.environ.get("APP_VERSION", "1.0.0"),
        help="Installer version metadata (default: APP_VERSION or 1.0.0).",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    if args.method == "pyinstaller":
        # PyInstaller bootstrap method - fast and lightweight, can run on Linux or Windows
        print("[*] Using PyInstaller bootstrap method (fast, lightweight)")
        if not PYINSTALLER_BOOTSTRAP_SCRIPT.exists():
            raise FileNotFoundError(
                f"PyInstaller bootstrap script not found: {PYINSTALLER_BOOTSTRAP_SCRIPT}"
            )

        # Build the bootstrap installer with PyInstaller
        pyinstaller_cmd = [sys.executable, str(PYINSTALLER_BOOTSTRAP_SCRIPT)]
        run_command(pyinstaller_cmd)

        # The PyInstaller output is already the final installer
        INSTALLER_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

        # PyInstaller creates .exe on Windows, no extension on Linux/Mac
        pyinstaller_exe = DIST_DIR / "WebToEbookInstaller.exe"
        if not pyinstaller_exe.exists():
            pyinstaller_exe = DIST_DIR / "WebToEbookInstaller"

        if not pyinstaller_exe.exists():
            raise FileNotFoundError(
                f"PyInstaller output not found: {pyinstaller_exe}"
            )

        final_output = INSTALLER_OUTPUT_DIR / "WebToEbookInstaller.exe"
        shutil.copy2(pyinstaller_exe, final_output)

        print(f"[+] Bootstrap installer ready: {final_output}")
        print(f"[+] Size: {final_output.stat().st_size / (1024 * 1024):.2f} MB")
        print("\n[*] This lightweight installer downloads dependencies at runtime.")
        print("[*] User installation time: 8-30 minutes (one-time, internet required)")

    elif args.method == "nuitka":
        # Nuitka method - slow but everything bundled
        print("[*] Using Nuitka method (slow build, everything bundled)")

        if not args.skip_build:
            nuitka_cmd = [sys.executable, str(PROJECT_ROOT / "build_nuitka.py")]
            if args.minimal_models:
                nuitka_cmd.append("--minimal-models")
            run_command(nuitka_cmd)
        elif not DIST_DIR.exists():
            raise FileNotFoundError(
                "dist/ directory not found. Re-run this command without --skip-build "
                'or run "python build_nuitka.py" first.'
            )

        # Inno Setup packaging step (Windows-only in practice; CI will run this on a Windows job)
        iscc_path = resolve_iscc()
        INSTALLER_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        iscc_cmd = [
            iscc_path,
            str(ISS_FILE),
            f"/DMyAppVersion={args.version}",
            f"/DDistDir={DIST_DIR}",
            f"/DOutputDir={INSTALLER_OUTPUT_DIR}",
        ]
        run_command(iscc_cmd)
        print(f"[+] Installer build complete: {INSTALLER_OUTPUT_DIR}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
