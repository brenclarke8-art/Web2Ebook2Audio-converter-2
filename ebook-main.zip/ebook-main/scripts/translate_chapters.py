#!/usr/bin/env python3
"""Placeholder translation step that copies chapters as-is."""

from __future__ import annotations

import argparse
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Translate chapter text files.")
    parser.add_argument("--input-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--device", default="auto")
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    files = sorted(input_dir.glob("*.txt"))
    if not files:
        raise FileNotFoundError(f"No .txt files found in {input_dir}")

    for src in files:
        dst = output_dir / src.name
        dst.write_text(src.read_text(encoding="utf-8", errors="ignore"), encoding="utf-8")
        print(f"Wrote: {dst}")

    print(f"Device requested: {args.device}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
