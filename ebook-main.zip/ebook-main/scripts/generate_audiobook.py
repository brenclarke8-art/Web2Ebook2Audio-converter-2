#!/usr/bin/env python3
"""Generate placeholder WAV files from chapter text files."""

from __future__ import annotations

import argparse
from pathlib import Path
import wave


def write_silence_wav(path: Path, seconds: int = 1, sample_rate: int = 22050) -> None:
    frames = b"\x00\x00" * (sample_rate * seconds)
    with wave.open(str(path), "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(sample_rate)
        wav.writeframes(frames)


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate audiobook WAV files.")
    parser.add_argument("--input-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--voice", default="default")
    parser.add_argument("--device", default="auto")
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    files = sorted(input_dir.glob("*.txt"))
    if not files:
        raise FileNotFoundError(f"No .txt files found in {input_dir}")

    for idx, _ in enumerate(files, 1):
        dst = output_dir / f"chapter_{idx:03d}.wav"
        write_silence_wav(dst)
        print(f"Wrote: {dst}")

    combined = output_dir / "complete.wav"
    write_silence_wav(combined, seconds=max(1, len(files)))
    print(f"Wrote: {combined}")
    print(f"Voice requested: {args.voice}")
    print(f"Device requested: {args.device}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
