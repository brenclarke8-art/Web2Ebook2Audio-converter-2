#!/usr/bin/env python3
"""Scrape a source URL into plain-text chapter files."""

from __future__ import annotations

import argparse
from pathlib import Path
import re

import requests
from bs4 import BeautifulSoup


def _extract_text(html: str) -> str:
    soup = BeautifulSoup(html, "html.parser")

    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()

    text = soup.get_text("\n")
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def main() -> int:
    parser = argparse.ArgumentParser(description="Scrape chapter text from a URL.")
    parser.add_argument("--source-url", required=True, help="Source chapter URL")
    parser.add_argument("--output-dir", required=True, help="Directory for chapter text files")
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    response = requests.get(args.source_url, timeout=60)
    response.raise_for_status()

    content = _extract_text(response.text)
    if not content:
        raise RuntimeError(f"No text extracted from URL: {args.source_url}")

    out_file = output_dir / "chapter_001.txt"
    out_file.write_text(content, encoding="utf-8")

    print(f"Wrote: {out_file}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
