#!/usr/bin/env python3
"""Build an EPUB from chapter text files."""

from __future__ import annotations

import argparse
from pathlib import Path

from ebook_generator import EbookGenerator


def main() -> int:
    parser = argparse.ArgumentParser(description="Build EPUB from chapter text files.")
    parser.add_argument("--input-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--title", required=True)
    parser.add_argument("--author", required=True)
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    files = sorted(input_dir.glob("*.txt"))
    if not files:
        raise FileNotFoundError(f"No .txt files found in {input_dir}")

    chapters = []
    for idx, src in enumerate(files, 1):
        chapters.append(
            {
                "title": f"Chapter {idx}",
                "content": src.read_text(encoding="utf-8", errors="ignore"),
            }
        )

    generator = EbookGenerator(args.output_dir)
    output = generator.create_epub(chapters, args.title, args.author)
    print(f"Created EPUB: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
