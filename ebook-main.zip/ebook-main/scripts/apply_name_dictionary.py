#!/usr/bin/env python3
"""Apply a JSON dictionary of text replacements to chapter files."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def load_mapping(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Dictionary JSON must be an object mapping string to string")
    return {str(k): str(v) for k, v in data.items()}


def main() -> int:
    parser = argparse.ArgumentParser(description="Apply custom name dictionary.")
    parser.add_argument("--input-dir", required=True)
    parser.add_argument("--dict-file", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    mapping = load_mapping(Path(args.dict_file))

    files = sorted(input_dir.glob("*.txt"))
    if not files:
        raise FileNotFoundError(f"No .txt files found in {input_dir}")

    for src in files:
        text = src.read_text(encoding="utf-8", errors="ignore")
        for old, new in mapping.items():
            text = text.replace(old, new)
        dst = output_dir / src.name
        dst.write_text(text, encoding="utf-8")
        print(f"Wrote: {dst}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
