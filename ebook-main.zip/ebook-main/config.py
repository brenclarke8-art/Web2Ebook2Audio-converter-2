from dataclasses import dataclass
from typing import List, Optional, Dict, Any
import yaml
from pathlib import Path


@dataclass
class Config:
    """Application configuration"""
    # Kokoro TTS settings
    kokoro_voice: str = 'af_heart'  # Voice name
    kokoro_lang_code: str = 'a'  # Language code: a=American English, b=British English, e=Spanish, f=French, h=Hindi, i=Italian, j=Japanese, p=Portuguese, z=Mandarin
    kokoro_speed: float = 1.0  # Speaking speed multiplier (0.5 to 2.0)
    tts_device: str = 'auto'  # Device for TTS processing: 'auto', 'cuda', 'cpu', or 'mps'
    preload_voices: Optional[List[str]] = None  # Voices to preload at startup for multi-speaker support

    # Character Voice Settings
    enable_character_voices: bool = False  # Enable separate voices for characters
    narrator_voice: str = 'af_heart'  # Voice for narration (non-dialogue text)
    auto_assign_character_voices: bool = True  # Auto-assign voices based on gender
    character_voice_mappings: Optional[Dict[str, str]] = None  # Character name -> voice name mapping
    default_male_voice: str = 'am_adam'  # Default voice for male characters
    default_female_voice: str = 'af_bella'  # Default voice for female characters
    dialogue_pause: float = 0.3  # Pause duration between speakers in seconds

    # Dialogue Detector LLM settings (Ollama)
    enable_dialogue_llm: bool = False  # Deprecated: full mode is always enforced.
    dialogue_llm_mode: str = "full"    # Dialogue mode is fixed to "full"
    dialogue_llm_model: str = 'mistral:instruct'  # Ollama model tag
    dialogue_llm_url: str = 'http://localhost:11434/api/chat'  # Ollama chat endpoint
    dialogue_llm_timeout: int = 200  # Request timeout in seconds
    dialogue_llm_strict_quotes: bool = False  # If true, only double-quoted text can be dialogue in LLM outputs
    character_manual_review: bool = False  # Always show character review prompt before DB update
    character_review_low_confidence_threshold: float = 0.7  # Prompt review for low-confidence new characters

    output_dir: str = 'output'
    epub_title: str = 'My Book'
    epub_author: str = 'Unknown'
    speech_rate: int = 150  # For compatibility with sync text generator
    max_chapters: int = 0  # 0 = no limit
    max_duration: int = 0  # minutes, 0 = no limit

    # Chapter range settings
    start_chapter: int = 1  # Starting chapter number (1-based)
    end_chapter: int = 0  # Ending chapter number (0 = process all remaining)
    generate_per_chapter_audio: bool = False  # Generate separate audio files per chapter

    # Translation settings
    enable_translation: bool = False
    source_language: str = 'auto'  # auto-detect or language code (ja, zh, ko, etc.)
    target_language: str = 'en'
    translation_api_url: str = 'http://localhost:5000/translate'
    translation_api_key: Optional[str] = None
    translation_rules: Optional[List[Dict[str, Any]]] = None
    character_genders: Optional[Dict[str, str]] = None  # Character name -> gender mapping

    # CSS Selectors for content extraction
    css_selectors: Optional[List[str]] = None

    # Visual layout extraction
    use_visual_order: bool = False  # Extract text based on visual layout instead of HTML order

    # Browser scraper settings
    wait_for_js: bool = True  # Wait for JavaScript-rendered content
    use_existing_browser: bool = True  # Attach to an already-opened Edge via CDP
    browser_cdp_url: str = 'http://127.0.0.1:9222'  # CDP endpoint for existing Edge
    allow_edge_signin: bool = False  # Launch Edge with a temporary profile so the user can sign in
    remove_overlays: bool = True  # Remove anti-copy overlays
    browser_timeout: int = 30  # Timeout for browser operations (seconds)

    # Content filtering - CSS selectors for elements to exclude
    exclude_selectors: Optional[List[str]] = None

    # GitHub updater settings
    github_token: Optional[str] = None  # GitHub API token for private repos (or use GITHUB_TOKEN env var)

    def __post_init__(self):
        if self.css_selectors is None:
            self.css_selectors = [
                'article',
                '.content',
                '.post-content',
                'main',
            ]
        if self.exclude_selectors is None:
            self.exclude_selectors = [
                'button',
                '.reader-settings',
                '.navigation',
                '.tools',
                '[role="navigation"]',
                'aside',
                'header',
            ]
        if self.preload_voices is None:
            self.preload_voices = []
        if self.character_voice_mappings is None:
            self.character_voice_mappings = {}
        if self.dialogue_llm_mode != "full":
            self.dialogue_llm_mode = "full"
        try:
            self.character_review_low_confidence_threshold = float(self.character_review_low_confidence_threshold)
        except (TypeError, ValueError):
            self.character_review_low_confidence_threshold = 0.7
        self.character_review_low_confidence_threshold = max(
            0.0,
            min(1.0, self.character_review_low_confidence_threshold),
        )

    @classmethod
    def from_yaml(cls, yaml_path: str) -> 'Config':
        """Load configuration from YAML file"""
        path = Path(yaml_path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {yaml_path}")

        with open(path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)

        # Create config with loaded data
        return cls(**{k: v for k, v in data.items() if v is not None})
