# Web to Ebook Converter

Convert web articles and blog posts into EPUB ebooks and audiobooks with high-quality TTS using Kokoro TTS.

## Features

- 🌐 Scrape content from any website
- 🌐 **User browser integration** - Uses your own browser session to bypass authentication and protection
- 📕 Generate professional EPUB ebooks
- 🔊 Create audiobooks with natural-sounding text-to-speech powered by **Kokoro TTS**
- ⚡ **GPU acceleration** - 5-10x faster audio processing with NVIDIA CUDA or Apple Metal
- 🎭 **Multi-speaker support** - Pre-load multiple voices for faster switching
- 🔐 **Optional Edge sign-in for CDP launches** - Use a temporary Edge profile when a site needs your Edge account
- ⚡ **Instant voice & speed preview** - Test settings before full conversion
- 📖 **Chapter text preview** - Review scraped content before TTS generation
- 📊 **Real-time progress feedback** - Track conversion status step-by-step
- 📄 **Interactive synchronized text display** with word/sentence highlighting
- 📚 **Chapter separation** with per-chapter audio and resume capability
- 📐 **Visual order extraction** for websites with incorrect HTML order
- 🌍 **Multilingual support** - 9 languages including English, Spanish, French, Italian, and more
- 🎤 25+ built-in voices with diverse accents and styles
- 🌍 **AI-powered translation** with custom rules
- ⚙️ Easy configuration with YAML
- 🎚️ Adjustable speed control and voice selection
- 📊 Chapter and time limits for previews
- 🎵 Voice preview tool to test all available voices
- 🖥️ **Graphical User Interface** for easy operation

## Quick Start

### Installation

**Windows (recommended): portable zip**

1. Download the latest `ebook-windows-x64-v<version>.zip` from [GitHub Releases](https://github.com/brenclarke8-art/ebook/releases/latest).
2. Extract the zip to any folder (e.g. `C:\Apps\ebook`).
3. Run `app.exe` inside the extracted folder.

No installer or system Python needed – everything is bundled.

**What's included in the zip:**
- `app.exe` – launch the GUI directly
- Python runtime and all required libraries (bundled by PyInstaller)
- Kokoro TTS engine
- `config.yaml` – default configuration (edit as needed)

> **Note:** On first launch Kokoro TTS will download its voice models (~200 MB).
> Ensure you have an internet connection and `espeak-ng` installed separately —
> the portable bundle does **not** include espeak-ng.
> Download the Windows installer from the
> [espeak-ng releases page](https://github.com/espeak-ng/espeak-ng/releases/latest)
> and run it once before launching the app.

**Install from source (Linux/macOS or development):**

```bash
git clone https://github.com/brenclarke8-art/ebook.git
cd ebook
./install_app.sh
```

Or run the Python installer directly:

```bash
python installer.py
```

**After source installation, launch the app:**
- Windows: `run_app.bat`
- Linux/macOS: `./run_app.sh`

### Build the Windows Portable Bundle

The release zip is built automatically by GitHub Actions on every release
publication (`.github/workflows/release-windows.yml`).

To build locally:

```bash
pip install pyinstaller
pyinstaller app.spec --noconfirm
# The portable folder is dist/app/ — zip it and distribute
```

Automated release builds:
- Workflow: `.github/workflows/release-windows.yml`
- Trigger: release publication (and manual `workflow_dispatch`)
- Output: `ebook-windows-x64-v<version>.zip` attached to the GitHub release

**What happens on first run:**
When you first generate audio or run the voice preview tool, Kokoro TTS will automatically download the voice models. This download happens once and is cached locally for all future use. Ensure you have:
- A stable internet connection
- espeak-ng installed on your system (required for Kokoro TTS)
- 2-3 minutes for the initial setup

After the first run, all subsequent audio generations will be significantly faster.

**Manual install (for advanced users):**

```bash
git clone https://github.com/brenclarke8-art/ebook.git
cd ebook
# Install core packages
pip install requests beautifulsoup4 ebooklib PyYAML
# Install PyTorch with CPU support (use official PyTorch index for pre-built wheels)
pip install torch --index-url https://download.pytorch.org/whl/cpu
# Install Kokoro TTS dependencies (Kokoro source is bundled in the project)
pip install soundfile numpy huggingface_hub loguru misaki[en] transformers
```

> **Note:** Kokoro TTS requires `espeak-ng`:
> - The interactive installer can attempt automatic installation when missing
> - **Linux:** `sudo apt-get install espeak-ng`
> - **macOS:** `brew install espeak-ng`
> - **Windows:** Automatically installed by the packaged installer or by `python installer.py` (latest release `.msi`)
> - If Windows MSI installation fails (network/admin policy), manually install from the espeak-ng releases page and re-run the installer

### Updating to the Latest Version

To update your installation to the latest GitHub release:

```bash
python updater.py
```

You can also update from the GUI:
- Open the **Updater** tab
- Click **Check for Updates** or **Install Latest Update**
- Enable **detailed debug output** to see step-by-step updater diagnostics in the tab output panel

Or use launcher scripts:
- Windows: `update_app.bat`
- Linux/macOS: `./update_app.sh`

To check for updates without installing:

```bash
python updater.py --check-only
```

The updater will:
- Check for the latest release on GitHub
- Download and install the latest version
- Backup your `config.yaml` file automatically
- Preserve your output files, logs, and backups
- Reinstall dependencies to match the new version
- Show a final success/failure prompt before closing

**Your configuration and generated files are safe!** The updater preserves:
- `config.yaml` - Your settings (automatically backed up and restored)
- `output/` - Your generated ebooks and audiobooks
- `logs/` - Your log files
- `backups/` - Your configuration backups

### Uninstalling

To completely remove the application, run the uninstaller from the installation directory:

- **Windows:** double-click `uninstall.bat` (or run it from a terminal)
- **Linux/macOS:** `./uninstall.sh`

Or run the uninstaller script directly:

```bash
python uninstaller.py
```

The uninstaller will:
- Show a summary of what will be removed and the approximate size
- Offer to back up your `config.yaml` and `output/` folder before deletion
- Remove the application, Python runtime, virtual environment, and all app files
- Optionally uninstall `espeak-ng` (Windows only; it is system-wide on other platforms)

> **Note:** The Hugging Face model cache (`~/.cache/huggingface` on Linux/macOS or
> `%USERPROFILE%\.cache\huggingface` on Windows) is stored outside the install directory
> and must be deleted manually if you want to reclaim that space.

### Getting Started with Kokoro TTS

**Step 1: Preview Available Voices (Recommended)**

Before converting your first book, preview the available voices to find your favorite:

```bash
python voice_preview.py
```

This will:
- Trigger the automatic model download on first run
- Generate sample audio for multiple voices
- Help you choose the best voice for your audiobook

**Step 2: Use the Application**

Once voices are downloaded, you can start converting web content to audiobooks:

#### Using the GUI (Recommended)

Simply run the GUI application:

```bash
# Linux/macOS
./run_app.sh
# Windows
run_app.bat
```

The GUI provides:
- Easy URL input (paste multiple URLs, one per line)
- Visual configuration of all settings
- **⚡ Instant Preview** - Test voice & speed before converting
- **Kokoro TTS voice and language selection**
- **Translation tab** with language selection and custom rules
- **Dedicated Multi-Speaker tab** for narrator/dialogue voice setup
- Voice preview integration
- **Real-time progress display** with detailed status updates
- Load/save configuration files
- Advanced settings (chapter limits, CSS selectors)

**Quick Tip: Testing Voice Settings**

Use the "⚡ Test Voice & Speed (Instant Preview)" button to:
1. Select a voice from the dropdown
2. Adjust the speed slider
3. Click the instant preview button
4. Listen to a quick sample
5. Adjust and test again until you find the perfect settings

See [INSTANT_PREVIEW_GUIDE.md](INSTANT_PREVIEW_GUIDE.md) for detailed documentation.

#### Using the Command Line

1. **Choose your voice** (if you haven't run voice_preview.py yet):
   ```bash
   python voice_preview.py
   ```
   This generates sample audio files for all available Kokoro TTS voices.

2. **Configure settings**:
   Edit `config.yaml` to set your preferences:
   ```yaml
   epub_title: "My Book"
   kokoro_voice: "af_heart"  # or any other available voice
   kokoro_lang_code: "a"     # a=American English, b=British English, e=Spanish, f=French, etc.
   kokoro_speed: 1.0         # 0.5 to 2.0
   ```

3. **Convert content**:
   ```python
   from config import Config
   from main import WebToEbookApp

   config = Config.from_yaml('config.yaml')
   app = WebToEbookApp(config)

   urls = ['https://example.com/article']
   result = app.process(urls)
   ```

## Configuration

Create or edit `config.yaml`:

```yaml
# Book settings
epub_title: "My Book"
epub_author: "Author Name"

# Kokoro TTS settings
kokoro_voice: "af_heart"      # Voice name
kokoro_lang_code: "a"         # Language code
kokoro_speed: 1.0             # Speaking speed (0.5 to 2.0)

# GPU Acceleration (new!)
tts_device: "auto"            # Device: 'auto', 'cuda', 'cpu', or 'mps'
preload_voices: []            # Pre-load voices for multi-speaker audiobooks

# Limits (0 = no limit)
max_chapters: 0               # Stop after X chapters
max_duration: 0               # Stop after X minutes

# Browser settings
wait_for_js: true             # Wait for JavaScript content
use_existing_browser: true    # Attach to your already-opened Edge via CDP (required)
browser_cdp_url: "http://127.0.0.1:9222"
allow_edge_signin: false      # Launch Edge with a temporary profile so you can sign in first
remove_overlays: true         # Remove anti-copy overlays
```

### GPU Acceleration ⚡

The app now supports GPU acceleration for **5-10x faster audio processing**:

**Device Options:**
- `auto` (default): Automatically uses CUDA if available, otherwise CPU
- `cuda`: Force NVIDIA GPU acceleration (requires CUDA-enabled PyTorch)
- `cpu`: Force CPU-only processing
- `mps`: Use Apple Metal Performance Shaders (Mac with Apple Silicon)

**Installation:**
During installation, the installer will detect your GPU and offer to install the appropriate PyTorch version:
- **CUDA version**: For NVIDIA GPUs (5-10x faster)
- **CPU version**: Works on all systems (slower but compatible)

**Requirements for GPU Acceleration:**
- NVIDIA GPU with CUDA support
- CUDA Toolkit 11.8 or compatible (install from [NVIDIA CUDA](https://developer.nvidia.com/cuda-downloads))
- GPU drivers up to date

The bundled Kokoro ALBERT model uses the compatible eager Transformers attention path automatically to avoid fused CUDA kernel crashes on some GPU and driver combinations during audio generation.
When eager attention is active, the app also disables CUDA fused SDP attention kernels and forces the safe math backend to prevent runtime failures like `kernel ... is for sm80-sm100, but was built for sm37`.
If you want to try a different backend on a known-good setup, set `TRANSFORMERS_ATTENTION_IMPLEMENTATION` before launching the app (for example, `export TRANSFORMERS_ATTENTION_IMPLEMENTATION=sdpa` on Linux/macOS or `set TRANSFORMERS_ATTENTION_IMPLEMENTATION=sdpa` on Windows).

**Example Performance:**
- CPU: ~30-60 seconds per 1000 words
- GPU (CUDA): ~3-6 seconds per 1000 words

The app automatically detects and uses your GPU if available. No manual configuration needed!

### Multi-Speaker Support 🎭

Pre-load multiple voices for faster multi-speaker audiobooks:

```yaml
preload_voices: ['af_heart', 'am_adam', 'bf_emma']
```

Benefits:
- Voices are loaded in parallel at startup
- Instant switching between speakers
- Perfect for dialogue-heavy content or multi-narrator audiobooks

**Note:** This is a preparation feature for future multi-speaker implementations. Currently, all text uses the primary `kokoro_voice` setting.

### Browser Scraping

The scraper uses your own browser session (via Playwright) for robust web scraping:

**Handles:**
- ✅ JavaScript-rendered content
- ✅ Authentication and login sessions
- ✅ Protected sites (you handle authentication in your browser)
- ✅ Fragmented DOM (text split across many `<span>` elements)
- ✅ Zero-width character obfuscation
- ✅ Anti-copy CSS overlays
- ✅ High z-index blocking layers

**Installation:**
Browser scraping requires Playwright:
```bash
pip install playwright
python -m playwright install msedge
```

`python installer.py` now installs advanced scraper support automatically.

**How to use:**
1. Start Edge with remote debugging enabled:
   - **Windows (Edge)**:
     ```bash
     msedge.exe --remote-debugging-port=9222 --guest
     ```
   - **Linux**:
     ```bash
     microsoft-edge --remote-debugging-port=9222 --guest
     ```
   - **macOS**:
     ```bash
     /Applications/Microsoft\ Edge.app/Contents/MacOS/Microsoft\ Edge --remote-debugging-port=9222 --guest
     ```
2. Open the target site in that browser window and handle any authentication or challenges yourself.
3. The scraper will attach to your browser session and use your authenticated session.
4. Run conversion. The scraper reuses that same browser session across all chapters.

**Or use the GUI button:**
The GUI includes an "Open Browser with CDP" button that automatically launches your browser with the correct settings.

**Performance:**
- ~10-15 seconds per page (depending on page complexity)
- Configurable timeouts for different site requirements

## Available Voices

Kokoro TTS includes 25+ built-in voices:

- **Female voices (American)**: af_heart, af_alloy, af_aoede, af_bella, af_jessica, af_kore, af_nicole, af_nova, af_river, af_sarah, af_sky
- **Male voices (American)**: am_adam, am_echo, am_eric, am_fenrir, am_liam, am_michael, am_onyx, am_puck, am_santa
- **Female voices (British)**: bf_alice, bf_emma, bf_isabella, bf_lily
- **Male voices (British)**: bm_daniel, bm_fable, bm_george, bm_lewis

You can also provide a local `.pt` filename or an absolute path to a `.pt` voice file anywhere a voice name is accepted.

**Recommended voices for audiobooks:**
- **af_heart**: Warm and clear female voice
- **am_adam**: Clear male narrator voice
- **bf_emma**: British female accent
- **bm_lewis**: British male, authoritative

## Supported Languages

Kokoro TTS supports 9 languages:
- American English (a)
- British English (b)
- Spanish (e)
- French (f)
- Hindi (h)
- Italian (i)
- Japanese (j)
- Brazilian Portuguese (p)
- Mandarin Chinese (z)

## Speed Control

Adjust speaking speed from 0.5x to 2.0x:
- **0.5** - Very slow (half speed)
- **0.8** - Slower (for clarity)
- **1.0** - Normal speed (recommended)
- **1.2** - Faster (more energetic)
- **2.0** - Very fast (double speed)

## Documentation

See [USER_GUIDE.md](USER_GUIDE.md) for comprehensive documentation including:
- Detailed installation instructions
- Voice selection guide
- Configuration options
- Usage examples
- Troubleshooting tips
- Best practices

See [TRANSLATION_GUIDE.md](TRANSLATION_GUIDE.md) for translation setup:
- Translation API options (LibreTranslate, DeepL, etc.)
- Language detection and configuration
- Custom translation rules for character names and pronouns
- Step-by-step setup instructions

## Tools

- **gui.py** - Graphical user interface for easy operation
- **voice_preview.py** - Generate sample audio files for all available Kokoro TTS voices
- **updater.py** - Update to the latest GitHub release (preserves config and output files)
- **installer.py** - Interactive dependency installer
- **translator.py** - AI-powered translation module with custom rules
- **config.yaml** - Easy configuration file for all settings
- **USER_GUIDE.md** - Complete documentation
- **TRANSLATION_GUIDE.md** - Translation setup guide

## Output

All files are saved in the `output/` directory:
- `{book_name}.epub` - EPUB ebook
- `{book_name}.wav` - Audio file
- `{book_name}_sync.html` - Interactive synchronized text display
- `{book_name}_character_checklist.txt` - Detected character checklist
- `{book_name}_character_preview.html` - Color-coded dialogue preview
- `character_db/{book_name}.json` - Per-book character database used as dialogue detection hints
- `voice_samples/` - Voice preview samples

### Synchronized Text Display

The generated HTML file provides an interactive reading experience:
- **Word Highlighting**: Highlights each word as it's being spoken
- **Sentence Highlighting**: Highlights the current sentence
- **Auto-scrolling**: Automatically scrolls to keep the current position in view
- **Toggle Modes**: Switch between word, sentence, or no highlighting
- **Responsive Design**: Works on desktop and mobile devices

Simply open the `_sync.html` file in any web browser to read along with the audio!

### Chapter Separation & Resume

Process specific chapter ranges and generate per-chapter audio files for easier navigation and resuming:

- **Chapter Range Selection**: Start from any chapter and process only the chapters you need
- **Per-Chapter Audio**: Generate separate audio files for each chapter
- **Chapter Navigation**: Interactive UI with buttons to jump between chapters
- **Resume Reading**: Continue from where you left off
- Enable via GUI "Chapter Range & Audio Options" or config settings

**Configuration Options:**
```yaml
start_chapter: 5      # Start from chapter 5
end_chapter: 10       # Stop at chapter 10
generate_per_chapter_audio: true  # Create separate audio files
```

**When to use:**
- Processing long series of chapters
- Want to listen to specific chapters
- Need to resume from a particular chapter
- Prefer chapter-by-chapter navigation

### Visual Order Extraction

Some websites use CSS positioning (flexbox, grid, absolute positioning) that causes the text to appear in a different order than the HTML source. Enable **Visual Order** in the Advanced Settings tab to extract text based on visual layout:

- **Analyzes element positioning** from inline styles and CSS classes
- **Sorts content** top-to-bottom, left-to-right
- **Handles common layouts** like sidebars, columns, and positioned elements
- Enable via GUI checkbox or set `use_visual_order: true` in config.yaml

**When to use**: If your generated ebook has text in the wrong order (e.g., sidebar content mixed with main content), enable this feature.

## Requirements

- **Python 3.8 or higher** (tested with Python 3.8-3.12)
- requests
- beautifulsoup4
- ebooklib
- PyYAML
- torch
- soundfile
- numpy
- huggingface_hub
- loguru
- misaki[en]
- transformers
- **espeak-ng** (system dependency)

**Note:** Kokoro TTS is bundled directly in this project (in the `kokoro_tts/` directory) for stable, reproducible setup. The installer handles Python dependencies automatically and can also attempt automatic `espeak-ng` installation when it is missing.

## About Kokoro TTS

Kokoro TTS is an open-weight, lightweight text-to-speech system with 82 million parameters. Despite its small size, it delivers high-quality, natural-sounding speech, making it ideal for audiobook generation.

**Key Features:**
- **Official repo**: https://github.com/hexgrad/kokoro
- **Model**: Kokoro-82M from HuggingFace
- **Bundled**: Kokoro source code is bundled directly in this project for stability
- **Automatic setup**: Models download automatically on first use
- **Lightweight**: 82M parameters - much faster than larger TTS systems
- **Languages**: Supports 9 languages with clear pronunciation
- **Voices**: 25+ built-in voices with diverse accents and styles
- **Quality**: Professional audiobook-grade output
- **License**: Apache-licensed for production and personal use

**System Requirements:**
- Python 3.8 or higher
- espeak-ng (system dependency)
- 2GB free disk space (for models and temporary files)
- Internet connection (only for initial model download)
- CPU-only system is sufficient (GPU not required)

## License

MIT License

## Contributing

Issues and pull requests welcome!
