#!/usr/bin/env python3
"""
Updater for Web to Ebook Converter.
Downloads and installs the latest version from GitHub.
"""

import subprocess
import sys
import logging
import traceback
import shutil
import tempfile
import zipfile
import requests
from pathlib import Path
from datetime import datetime
from typing import Optional

try:
    from installer_manifest import UPDATER_REQUIRED_FILES
except ModuleNotFoundError:
    # Fallback for older installs that shipped updater.py without
    # installer_manifest.py. Keep updater bootable so it can self-heal.
    UPDATER_REQUIRED_FILES = [
        "installer.py",
        "main.py",
        "gui.py",
        "scraper.py",
        "character_database.py",
        "multispeaker_debug.py",
    ]


def setup_update_logger(debug_console: bool = False) -> logging.Logger:
    """
    Set up logging for the updater.
    Logs to both console and a log file.
    """
    logger = logging.getLogger("updater")
    logger.setLevel(logging.DEBUG)

    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG if debug_console else logging.INFO)
    console_formatter = logging.Formatter('%(levelname)s: %(message)s')
    console_handler.setFormatter(console_formatter)

    # File handler
    log_dir = Path(__file__).parent / "logs"
    log_dir.mkdir(exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = log_dir / f"updater_{timestamp}.log"

    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    file_handler.setFormatter(file_formatter)

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

    logger.info(f"Updater logger initialized. Log file: {log_file}")
    return logger


def prompt_yes_no(
    message: str,
    default: bool = True,
    *,
    non_interactive: bool = False,
    assume_yes: bool = False,
    logger: Optional[logging.Logger] = None,
) -> bool:
    """Prompt user for yes/no answer."""
    if non_interactive:
        decision = assume_yes or default
        status = "yes" if decision else "no"
        note = f"{message} -> {status} (non-interactive mode)"
        print(note)
        if logger:
            logger.info(note)
        return decision

    suffix = "[Y/n]" if default else "[y/N]"
    value = input(f"{message} {suffix} ").strip().lower()
    if not value:
        return default
    return value in {"y", "yes"}


def confirm_close_with_result(exit_code: int):
    """Show final status and wait for user confirmation before closing."""
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        return

    status = "SUCCESS" if exit_code == 0 else "FAILURE"
    icon = "✅" if exit_code == 0 else "❌"
    print(f"\n{icon} Updater finished with status: {status}")
    input("Press Enter to close...")


def get_latest_release_info(logger: logging.Logger, token: Optional[str] = None) -> dict:
    """
    Get the latest release information from GitHub.

    Args:
        logger: Logger instance
        token: Optional GitHub API token for private repos

    Returns:
        dict with 'tag_name', 'name', 'zipball_url', 'published_at'
    """
    import os
    
    repo_owner = "brenclarke8-art"
    repo_name = "ebook"
    api_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/releases/latest"

    logger.info(f"Fetching latest release info from GitHub API: {api_url}")

    # Get token from parameter, environment, or None
    auth_token = token or os.getenv("GITHUB_TOKEN")
    
    headers = {
        'User-Agent': 'Web-to-Ebook-Updater/1.0',
        'Accept': 'application/vnd.github.v3+json'
    }
    
    if auth_token:
        headers['Authorization'] = f'token {auth_token}'
        logger.info("Using GitHub token for authentication")

    try:
        response = requests.get(api_url, headers=headers, timeout=10)

        if response.status_code == 404:
            logger.warning("No releases found for this repository")
            print("\n⚠️  No releases found for this repository.")
            print("   This updater requires at least one release to be published on GitHub.")
            print("   Please check: https://github.com/brenclarke8-art/ebook/releases")
            return None

        if response.status_code == 403:
            logger.error("GitHub API rate limit exceeded or access forbidden")
            print("\n⚠️  Unable to check for updates (GitHub API access limited).")
            print("   Possible causes:")
            print("   • GitHub API rate limit reached (authenticated requests have higher limits)")
            print("   • Repository is private and requires authentication")
            print("\n   Solutions:")
            print("   • Set GITHUB_TOKEN environment variable with a personal access token")
            print("   • Or run: python updater.py with GITHUB_TOKEN set")
            print("   • Create token at: https://github.com/settings/tokens")
            print("\n   Manual update:")
            print("   https://github.com/brenclarke8-art/ebook/releases")
            return None

        response.raise_for_status()
        release_data = response.json()

        info = {
            'tag_name': release_data.get('tag_name', 'unknown'),
            'name': release_data.get('name', 'unknown'),
            'zipball_url': release_data.get('zipball_url', ''),
            'published_at': release_data.get('published_at', 'unknown'),
        }

        logger.info(f"Latest release: {info['name']} ({info['tag_name']})")
        logger.info(f"Published at: {info['published_at']}")

        return info
    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to fetch release info: {e}")
        print("\n⚠️  Unable to connect to GitHub API.")
        print("   Please check your internet connection or try again later.")
        print("   You can manually check for updates at:")
        print("   https://github.com/brenclarke8-art/ebook/releases")
        return None


def download_and_extract_release(zipball_url: str, extract_to: Path, logger: logging.Logger) -> Path:
    """
    Download and extract the latest release.

    Args:
        zipball_url: URL to the release zipball
        extract_to: Directory to extract files to
        logger: Logger instance

    Returns:
        Path to the extracted directory
    """
    logger.info(f"Downloading release from {zipball_url}")

    try:
        # Download the zipball
        response = requests.get(zipball_url, timeout=60, stream=True)
        response.raise_for_status()

        # Save to temporary file
        temp_zip = extract_to / "release.zip"
        with open(temp_zip, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

        logger.info(f"Downloaded to {temp_zip}")

        # Extract the zipball
        logger.info("Extracting release...")
        with zipfile.ZipFile(temp_zip, 'r') as zip_ref:
            zip_ref.extractall(extract_to)

        # Find the extracted directory (GitHub creates a directory with repo name + commit hash)
        extracted_dirs = [d for d in extract_to.iterdir() if d.is_dir()]
        if not extracted_dirs:
            raise RuntimeError("No directory found after extraction")

        extracted_dir = extracted_dirs[0]
        logger.info(f"Extracted to {extracted_dir}")

        # Clean up the zip file
        temp_zip.unlink()

        return extracted_dir
    except Exception as e:
        logger.error(f"Failed to download and extract release: {e}")
        raise


def backup_config(app_dir: Path, logger: logging.Logger) -> Path:
    """
    Backup the current config.yaml file.

    Returns:
        Path to the backup file
    """
    config_file = app_dir / "config.yaml"
    if not config_file.exists():
        logger.info("No config.yaml to backup")
        return None

    backup_dir = app_dir / "backups"
    backup_dir.mkdir(exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_file = backup_dir / f"config_{timestamp}.yaml"

    shutil.copy2(config_file, backup_file)
    logger.info(f"Backed up config.yaml to {backup_file}")

    return backup_file


def restore_config(backup_file: Path, app_dir: Path, logger: logging.Logger):
    """Restore config.yaml from backup."""
    if backup_file is None or not backup_file.exists():
        logger.info("No config backup to restore")
        return

    config_file = app_dir / "config.yaml"
    shutil.copy2(backup_file, config_file)
    logger.info(f"Restored config.yaml from {backup_file}")


def update_app_files(source_dir: Path, target_dir: Path, logger: logging.Logger):
    """
    Update application files from source to target directory.
    Preserves certain files like config.yaml, output/, logs/, backups/.
    """
    logger.info(f"Updating app files from {source_dir} to {target_dir}")

    # Verify source directory has expected files
    missing_files = [f for f in UPDATER_REQUIRED_FILES if not (source_dir / f).exists()]

    if missing_files:
        logger.error(f"Source directory missing required files: {missing_files}")
        raise RuntimeError(f"Source directory missing required files: {missing_files}")

    # Files and directories to preserve
    preserve = {
        'config.yaml',
        'output',
        'logs',
        'backups',
        '__pycache__',
        '.git',
    }

    # Copy all files except preserved ones
    copied_files = []
    for item in source_dir.iterdir():
        if item.name in preserve:
            logger.info(f"Preserving: {item.name}")
            continue

        target_item = target_dir / item.name

        if item.is_file():
            shutil.copy2(item, target_item)
            logger.debug(f"Copied file: {item.name}")
            copied_files.append(item.name)
        elif item.is_dir():
            if target_item.exists():
                shutil.rmtree(target_item)
            shutil.copytree(item, target_item)
            logger.debug(f"Copied directory: {item.name}")
            copied_files.append(item.name)

    logger.info(f"App files updated successfully: copied {len(copied_files)} items")

    # Verify critical files were copied
    for required_file in UPDATER_REQUIRED_FILES:
        target_file = target_dir / required_file
        if not target_file.exists():
            logger.error(f"Failed to copy required file: {required_file}")
            raise RuntimeError(f"Failed to copy required file: {required_file}")

    logger.info("All required files verified in target directory")


def run_installer(app_dir: Path, logger: logging.Logger) -> bool:
    """
    Run the installer to reinstall dependencies.

    Returns:
        True if installation succeeded, False otherwise
    """
    installer_path = app_dir / "installer.py"
    if not installer_path.exists():
        logger.error(f"Installer not found at {installer_path}")
        return False

    logger.info("Running installer to update dependencies...")

    try:
        # Run installer in non-interactive mode by providing 'y' responses
        result = subprocess.run(
            [sys.executable, str(installer_path)],
            input="y\ny\n",  # Answer yes to prompts
            text=True,
            capture_output=True,
            timeout=600  # 10 minute timeout
        )

        if result.returncode == 0:
            logger.info("Installer completed successfully")
            return True
        else:
            logger.error(f"Installer failed with exit code {result.returncode}")
            logger.error(f"Installer output: {result.stdout}")
            logger.error(f"Installer errors: {result.stderr}")
            return False
    except subprocess.TimeoutExpired:
        logger.error("Installer timed out after 10 minutes")
        return False
    except Exception as e:
        logger.error(f"Failed to run installer: {e}")
        logger.error(f"Traceback:\n{traceback.format_exc()}")
        return False


def run_updater() -> int:
    """Main updater function."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Update Web to Ebook Converter to the latest GitHub release"
    )
    parser.add_argument(
        '--check-only',
        action='store_true',
        help='Only check for updates without installing'
    )
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Enable verbose updater output in the console'
    )
    parser.add_argument(
        '--non-interactive',
        action='store_true',
        help='Run without interactive prompts'
    )
    parser.add_argument(
        '--yes',
        action='store_true',
        help='Automatically answer yes to all prompts (implies --non-interactive)'
    )
    args = parser.parse_args()

    non_interactive = args.non_interactive or args.yes
    logger = setup_update_logger(debug_console=args.debug)

    print("=" * 60)
    print("Web to Ebook Converter - Updater")
    print("=" * 60)

    if args.check_only:
        print("\nChecking for updates...")
        logger.info("Running in check-only mode")

        import os
        token = os.getenv("GITHUB_TOKEN")
        release_info = get_latest_release_info(logger, token=token)

        if release_info is None:
            logger.info("No release information available")
            return 1

        print(f"\n✅ Latest release available:")
        print(f"   Version: {release_info['tag_name']}")
        print(f"   Name: {release_info['name']}")
        print(f"   Published: {release_info['published_at']}")
        print(f"\nTo update, run: python updater.py")
        return 0

    print("\nThis updater will:")
    print("  • Check for the latest version on GitHub")
    print("  • Download and install the latest release")
    print("  • Backup your config.yaml file")
    print("  • Reinstall dependencies")
    print("  • Preserve your output files and logs")

    logger.info("Starting updater")

    if not prompt_yes_no(
        "\nProceed with update?",
        True,
        non_interactive=non_interactive,
        assume_yes=args.yes,
        logger=logger,
    ):
        print("Update cancelled.")
        logger.info("Update cancelled by user")
        return 0

    app_dir = Path(__file__).parent.resolve()
    logger.info(f"App directory: {app_dir}")

    import os
    token = os.getenv("GITHUB_TOKEN")
    if not token:
        logger.info("No GITHUB_TOKEN found in environment")

    try:
        # Step 1: Get latest release info
        print("\n" + "=" * 60)
        print("Step 1: Checking for Latest Release")
        print("=" * 60)

        release_info = get_latest_release_info(logger, token=token)

        if release_info is None:
            print("\nUpdate cancelled - no releases available.")
            logger.info("Update cancelled - no releases available")
            return 0

        print(f"\n✅ Latest release found:")
        print(f"   Version: {release_info['tag_name']}")
        print(f"   Name: {release_info['name']}")
        print(f"   Published: {release_info['published_at']}")

        if not prompt_yes_no(
            f"\nDownload and install {release_info['tag_name']}?",
            True,
            non_interactive=non_interactive,
            assume_yes=args.yes,
            logger=logger,
        ):
            print("Update cancelled.")
            logger.info("User declined to install the latest version")
            return 0

        # Step 2: Backup config
        print("\n" + "=" * 60)
        print("Step 2: Backing Up Configuration")
        print("=" * 60)

        backup_file = backup_config(app_dir, logger)
        if backup_file:
            print(f"✅ Config backed up to: {backup_file.name}")

        # Step 3: Download and extract
        print("\n" + "=" * 60)
        print("Step 3: Downloading Latest Release")
        print("=" * 60)

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            extracted_dir = download_and_extract_release(
                release_info['zipball_url'],
                temp_path,
                logger
            )

            print("✅ Release downloaded and extracted")

            # Step 4: Update files
            print("\n" + "=" * 60)
            print("Step 4: Updating Application Files")
            print("=" * 60)

            update_app_files(extracted_dir, app_dir, logger)
            print("✅ Application files updated")

        # Step 5: Restore config
        print("\n" + "=" * 60)
        print("Step 5: Restoring Configuration")
        print("=" * 60)

        restore_config(backup_file, app_dir, logger)
        print("✅ Configuration restored")

        # Step 6: Run installer
        print("\n" + "=" * 60)
        print("Step 6: Reinstalling Dependencies")
        print("=" * 60)

        if run_installer(app_dir, logger):
            print("✅ Dependencies reinstalled successfully")
        else:
            print("⚠️  Warning: Dependency installation may have failed")
            print("   Check the logs for details")
            logger.warning("Installer completed with warnings or errors")

        # Success
        print("\n" + "=" * 60)
        print("🎉 Update Complete!")
        print("=" * 60)
        print(f"\n✅ Successfully updated to {release_info['tag_name']}")
        print("\nYour application is now running the latest version.")
        print("You can start using it with: python gui.py")

        logger.info("Update completed successfully")
        return 0

    except Exception as e:
        logger.critical(f"Critical error during update: {e}")
        logger.critical(f"Full traceback:\n{traceback.format_exc()}")
        print(f"\n❌ CRITICAL ERROR during update: {e}")
        print(f"Check the log file for full details.")

        # Try to restore config if we backed it up
        if 'backup_file' in locals() and backup_file:
            print("\nAttempting to restore configuration...")
            try:
                restore_config(backup_file, app_dir, logger)
                print("✅ Configuration restored")
            except Exception as restore_error:
                print(f"⚠️  Failed to restore config: {restore_error}")

        return 1


if __name__ == "__main__":
    try:
        exit_code = run_updater()
        confirm_close_with_result(exit_code)
        raise SystemExit(exit_code)
    except Exception as e:
        # Catastrophic failure
        try:
            logger = logging.getLogger("updater")
            if not logger.handlers:
                log_dir = Path(__file__).parent / "logs"
                log_dir.mkdir(exist_ok=True)
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                log_file = log_dir / f"updater_crash_{timestamp}.log"
                logging.basicConfig(
                    filename=log_file,
                    level=logging.DEBUG,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
                )
                logger = logging.getLogger("updater")

            logger.critical(f"Catastrophic updater failure: {e}")
            logger.critical(f"Full traceback:\n{traceback.format_exc()}")
            print(f"\n❌ CATASTROPHIC ERROR: {e}")
            print(f"Check the crash log in the logs/ directory for full details.")
        except:
            print(f"\n❌ CATASTROPHIC ERROR: {e}")
            print("Failed to write crash log.")
        confirm_close_with_result(1)
        raise SystemExit(1)
