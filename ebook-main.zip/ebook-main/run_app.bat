@echo off
setlocal
set SCRIPT_DIR=%~dp0
cd /d "%SCRIPT_DIR%"

REM Add locally installed espeak-ng to PATH (if present)
if exist "%SCRIPT_DIR%\espeak-ng" (
  for /r "%SCRIPT_DIR%\espeak-ng" %%F in (espeak-ng.exe) do (
    set "ESPEAK_DIR=%%~dpF"
    goto :EspeakPathReady
  )
)
:EspeakPathReady
if defined ESPEAK_DIR (
  set "PATH=%ESPEAK_DIR%;%PATH%"
)

REM Use pythonw.exe (no console window) wherever possible.
REM Fall back to python.exe only when pythonw.exe is absent.

REM App-local virtual environment
if exist "%SCRIPT_DIR%\.venv\Scripts\pythonw.exe" (
  start "" "%SCRIPT_DIR%\.venv\Scripts\pythonw.exe" "%SCRIPT_DIR%\gui.py"
  exit /b 0
)
if exist "%SCRIPT_DIR%\.venv\Scripts\python.exe" (
  start "" "%SCRIPT_DIR%\.venv\Scripts\python.exe" "%SCRIPT_DIR%\gui.py"
  exit /b 0
)

REM Bundled Python directory
if exist "%SCRIPT_DIR%\python\pythonw.exe" (
  set "PATH=%SCRIPT_DIR%\python;%SCRIPT_DIR%\python\Scripts;%PATH%"
  start "" "%SCRIPT_DIR%\python\pythonw.exe" "%SCRIPT_DIR%\gui.py"
  exit /b 0
)
if exist "%SCRIPT_DIR%\python\python.exe" (
  set "PATH=%SCRIPT_DIR%\python;%SCRIPT_DIR%\python\Scripts;%PATH%"
  start "" "%SCRIPT_DIR%\python\python.exe" "%SCRIPT_DIR%\gui.py"
  exit /b 0
)

REM System Python
where pythonw >nul 2>&1
if not errorlevel 1 (
  start "" pythonw "%SCRIPT_DIR%\gui.py"
  exit /b 0
)
where python >nul 2>&1
if not errorlevel 1 (
  start "" python "%SCRIPT_DIR%\gui.py"
  exit /b 0
)

REM No Python found — show a GUI error and exit
powershell -Command "Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show('Python interpreter not found.`n`nInstall the app with WebToEbookInstaller.exe from GitHub releases,`nor run python installer.py if you are running from source.', 'Web to Ebook Converter', 'OK', 'Error')" >nul 2>&1
exit /b 1
