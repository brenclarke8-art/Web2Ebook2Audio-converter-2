#!/usr/bin/env python3
"""
Interactive installer for Web to Ebook Converter.
"""

import subprocess
import sys
import logging
import traceback
import time
import os
import json
import shutil
import tempfile
import urllib.request
import urllib.error
import zipfile
from pathlib import Path
from datetime import datetime
import platform

from installer_manifest import (
    INSTALLATION_VALIDATION_DIRECTORIES,
    INSTALLATION_VALIDATION_FILES,
    PYINSTALLER_DEPLOY_DIRECTORIES,
    PYINSTALLER_DEPLOY_FILES,
)

# GitHub repository coordinates used to download the latest release source.
GITHUB_REPO_OWNER = "brenclarke8-art"
GITHUB_REPO_NAME = "ebook"

# Python 3.11 NuGet package used to provision a portable runtime at install time.
# This replaces the old approach of bundling python-runtime inside the installer exe.
_PYTHON_NUGET_VERSION = "3.11.9"
_PYTHON_NUGET_URL = (
    f"https://api.nuget.org/v3-flatcontainer/python/{_PYTHON_NUGET_VERSION}"
    f"/python.{_PYTHON_NUGET_VERSION}.nupkg"
)
_PYTHON_NUGET_TOOLS_PREFIX = "tools/"

CORE_PACKAGES = [
    "requests",
    "beautifulsoup4",
    "ebooklib",
    "PyYAML",
]

# Optional advanced scraping packages (for sites with anti-scraping protection)
ADVANCED_SCRAPER_PACKAGES = [
    "playwright",
]

# Kokoro TTS requirements
# Note: Kokoro is bundled directly in the project, not installed via pip
# PyTorch needs to be installed from a special index, other packages from PyPI
TORCH_PACKAGES = [
    "torch",
]

OTHER_KOKORO_PACKAGES = [
    "soundfile",
    "numpy",
    "huggingface_hub",
    "loguru",
    "misaki[en]",
    "transformers",
]

GUI_STARTUP_CHECK_DELAY_SECONDS = 5  # seconds
GUI_STARTUP_POLL_INTERVAL_SECONDS = 0.2  # seconds
GUI_DIAGNOSTIC_TIMEOUT_SECONDS = 3  # seconds
ESPEAK_NG_RELEASE_API_URL = "https://api.github.com/repos/espeak-ng/espeak-ng/releases/latest"
PYTHON_RUNTIME_DIRNAME = "python-runtime"
APP_VENV_DIR_NAME = ".venv"
WINDOWS_RUN_SCRIPT_NAME = "run_app.bat"
UNIX_RUN_SCRIPT_NAME = "run_app.sh"
WINDOWS_LAUNCHER_NAME = "Web to Ebook Converter.bat"
WINDOWS_EXE_LAUNCHER_NAME = "Web to Ebook Converter.exe"
WINDOWS_SHORTCUT_LAUNCHER_NAME = "Web to Ebook Converter.lnk"
UNIX_LAUNCHER_NAME = "Web to Ebook Converter.sh"
AUTO_CONFIRM_PROMPTS = False


def safe_encode_for_logging(text: str) -> str:
    """
    Safely encode text for logging and console output on Windows.
    Replaces non-ASCII characters with ASCII equivalents to avoid encoding errors.

    Args:
        text: Input text that may contain non-ASCII characters

    Returns:
        ASCII-safe version of the text
    """
    if not text:
        return text

    # Try to encode as ASCII, replacing non-ASCII chars with '?'
    try:
        # First check if text is already ASCII-safe
        text.encode('ascii')
        return text
    except UnicodeEncodeError:
        # Replace non-ASCII characters with ASCII-safe equivalents
        return text.encode('ascii', errors='replace').decode('ascii')


def choose_install_directory_gui(default_install_dir: Path) -> Path | None:
    """Use a native folder picker when tkinter is available."""
    try:
        import tkinter as tk
        from tkinter import filedialog
    except Exception:
        return None

    root = None
    try:
        initial_dir = default_install_dir if default_install_dir.exists() else default_install_dir.parent
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        selected = filedialog.askdirectory(
            parent=root,
            title="Choose installation folder for Web to Ebook Converter",
            initialdir=str(initial_dir),
            mustexist=False,
        )
        if selected:
            return Path(selected)
    except Exception:
        return None
    finally:
        if root is not None:
            try:
                root.destroy()
            except Exception:
                pass

    return None



def get_install_directory() -> Path:
    """
    Determine or prompt for installation directory.
    When running as a PyInstaller executable, ask the user where to install.
    When running as a script, use the script's directory.
    """
    # Check if we're running as a PyInstaller frozen executable
    if getattr(sys, 'frozen', False):
        # Running as compiled executable
        if platform.system() == "Windows":
            default_local_base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
            default_install_dir = Path(default_local_base) / "Web to Ebook Converter"
        elif platform.system() == "Darwin":
            default_install_dir = Path.home() / "Applications" / "Web to Ebook Converter"
        else:
            default_install_dir = Path.home() / ".local" / "share" / "web-to-ebook-converter"

        selected_dir = choose_install_directory_gui(default_install_dir)
        if selected_dir:
            install_dir = selected_dir
            print(f"\n[*] Installation directory selected: {install_dir}")
        else:
            print(f"\n[*] Default installation directory: {default_install_dir}")
            use_default = prompt_yes_no("Use this directory?", True)

            if use_default:
                install_dir = default_install_dir
            else:
                custom_path = input("Enter installation directory path: ").strip()
                if not custom_path:
                    print("[!] No path provided. Using default.")
                    install_dir = default_install_dir
                else:
                    install_dir = Path(custom_path)

        # Create the directory if it doesn't exist
        try:
            install_dir.mkdir(parents=True, exist_ok=True)
            print(f"[+] Installation directory: {install_dir}")
            return install_dir
        except Exception as e:
            print(f"[X] Failed to create directory {install_dir}: {e}")
            print(f"   Using temporary directory instead...")
            temp_dir = Path(tempfile.gettempdir()) / "web-to-ebook-converter"
            temp_dir.mkdir(parents=True, exist_ok=True)
            return temp_dir
    else:
        # Running as a regular Python script - use current directory
        return Path(__file__).parent.resolve()


def deploy_application_files(
    logger: logging.Logger,
    install_dir: Path,
) -> bool:
    """Deploy bundled application files from PyInstaller bundle to installation directory.

    When running as a frozen PyInstaller executable, application files are extracted to
    a temporary directory (sys._MEIPASS). This function copies them to the permanent
    installation directory.

    Args:
        logger: Logger instance
        install_dir: Target installation directory

    Returns:
        True if deployment succeeded, False otherwise
    """
    # Only needed when running as frozen executable
    if not getattr(sys, 'frozen', False):
        logger.info("Running as script - application files already in place")
        return True

    bundle_dir = Path(getattr(sys, '_MEIPASS', Path(__file__).parent))
    logger.info(f"Deploying application files from {bundle_dir} to {install_dir}")
    print(f"\n[*] Deploying application files to {install_dir}...")

    deployed_count = 0
    failed_count = 0

    # Deploy individual files
    for filename in PYINSTALLER_DEPLOY_FILES:
        source = bundle_dir / filename
        dest = install_dir / filename

        if not source.exists():
            logger.warning(f"Bundled file not found: {source}")
            continue

        try:
            # Ensure parent directory exists
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, dest)
            deployed_count += 1
            logger.debug(f"Deployed: {filename}")
        except Exception as e:
            logger.error(f"Failed to deploy {filename}: {e}")
            failed_count += 1

    # Deploy directories
    for dirname in PYINSTALLER_DEPLOY_DIRECTORIES:
        source = bundle_dir / dirname
        dest = install_dir / dirname

        if not source.exists():
            logger.warning(f"Bundled directory not found: {source}")
            continue

        try:
            # Remove existing directory if it exists
            if dest.exists():
                shutil.rmtree(dest)

            # Copy entire directory tree
            shutil.copytree(source, dest)
            deployed_count += 1
            logger.debug(f"Deployed directory: {dirname}")
        except Exception as e:
            logger.error(f"Failed to deploy directory {dirname}: {e}")
            failed_count += 1

    print(f"[+] Deployed {deployed_count} files/directories")
    if failed_count > 0:
        print(f"[!] Failed to deploy {failed_count} items (check log for details)")
        logger.warning(f"Deployment completed with {failed_count} failures")
        return False

    logger.info(f"Application files deployed successfully: {deployed_count} items")
    return True


def download_python_runtime_to_dir(install_dir: Path, logger: logging.Logger) -> bool:
    """Download and extract a portable Python 3.11 runtime to install_dir/python-runtime.

    Uses the official Python NuGet package from api.nuget.org, which contains a full
    Python installation (including venv, tkinter, and standard library) in its tools/
    subdirectory.  This replaces the old approach of bundling python-runtime inside the
    installer executable.

    Args:
        install_dir: Target installation directory. The runtime is placed at
                     install_dir/python-runtime/.
        logger: Logger instance.

    Returns:
        True if the runtime was successfully provisioned, False otherwise.
    """
    runtime_dir = install_dir / PYTHON_RUNTIME_DIRNAME
    python_exe = runtime_dir / "python.exe"

    if python_exe.exists():
        logger.info(f"Python runtime already present at {runtime_dir}")
        print(f"[*] Python runtime already present: {runtime_dir}")
        return True

    print(f"\n[*] Downloading portable Python {_PYTHON_NUGET_VERSION} runtime...")
    logger.info(f"Downloading Python NuGet package from: {_PYTHON_NUGET_URL}")

    try:
        with tempfile.TemporaryDirectory(prefix="python_nuget_") as tmp_dir:
            nupkg_path = Path(tmp_dir) / f"python.{_PYTHON_NUGET_VERSION}.nupkg"

            print(f"[*] Downloading python.{_PYTHON_NUGET_VERSION}.nupkg (approx 25 MB) – please wait...")
            request = urllib.request.Request(
                _PYTHON_NUGET_URL,
                headers={"User-Agent": "web-to-ebook-installer"},
            )
            with urllib.request.urlopen(request, timeout=120) as resp:
                with open(nupkg_path, "wb") as fout:
                    while True:
                        chunk = resp.read(65536)
                        if not chunk:
                            break
                        fout.write(chunk)

            print("[*] Extracting Python runtime...")
            logger.info(f"Extracting NuGet tools/ to {runtime_dir}")

            if runtime_dir.exists():
                shutil.rmtree(runtime_dir)
            runtime_dir.mkdir(parents=True, exist_ok=True)

            with zipfile.ZipFile(nupkg_path, "r") as zf:
                for member in zf.namelist():
                    if not member.startswith(_PYTHON_NUGET_TOOLS_PREFIX):
                        continue
                    # Strip the leading 'tools/' prefix.
                    rel = member[len(_PYTHON_NUGET_TOOLS_PREFIX):]
                    if not rel:
                        continue
                    target = runtime_dir / rel
                    if member.endswith("/"):
                        target.mkdir(parents=True, exist_ok=True)
                    else:
                        target.parent.mkdir(parents=True, exist_ok=True)
                        with zf.open(member) as src, open(target, "wb") as dst:
                            shutil.copyfileobj(src, dst)

        if not python_exe.exists():
            logger.error(f"Python executable not found after extraction: {python_exe}")
            print(f"\n[X] Python runtime extraction succeeded but python.exe not found at {python_exe}")
            return False

        print(f"[+] Python runtime ready: {runtime_dir}")
        logger.info(f"Python runtime provisioned: {python_exe}")
        return True

    except (urllib.error.URLError, urllib.error.HTTPError) as e:
        logger.error(f"Network error downloading Python runtime: {e}")
        print(f"\n[X] Failed to download Python runtime: {e}")
        print("    Check your internet connection and try again.")
        return False
    except Exception as e:
        logger.error(f"Unexpected error downloading Python runtime: {e}")
        logger.error(f"Traceback:\n{traceback.format_exc()}")
        print(f"\n[X] Failed to provision Python runtime: {e}")
        return False


def download_and_deploy_release_source(install_dir: Path, logger: logging.Logger) -> bool:
    """Download the latest GitHub release source archive and deploy it to install_dir.

    This replaces deploy_application_files() for frozen (PyInstaller) builds.  Instead
    of extracting files that were baked into the installer exe, we download the current
    release's source directly from GitHub so the same installer exe works for every
    release without needing to be rebuilt.

    Args:
        install_dir: Target installation directory.
        logger: Logger instance.

    Returns:
        True on success, False otherwise.
    """
    api_url = (
        f"https://api.github.com/repos/{GITHUB_REPO_OWNER}/{GITHUB_REPO_NAME}/releases/latest"
    )

    print("\n[*] Fetching latest release information from GitHub...")
    logger.info(f"Fetching latest release metadata: {api_url}")

    zipball_url: str
    tag_name: str
    try:
        req = urllib.request.Request(api_url, headers={"User-Agent": "web-to-ebook-installer"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            release_data = json.loads(resp.read().decode("utf-8"))
            tag_name = release_data.get("tag_name", "unknown")
            zipball_url = release_data.get("zipball_url") or (
                f"https://api.github.com/repos/{GITHUB_REPO_OWNER}/{GITHUB_REPO_NAME}/zipball"
            )
    except urllib.error.HTTPError as e:
        if e.code == 404:
            logger.warning("No releases found (404); falling back to default branch archive")
            zipball_url = (
                f"https://api.github.com/repos/{GITHUB_REPO_OWNER}/{GITHUB_REPO_NAME}/zipball"
            )
            tag_name = "latest"
        elif e.code == 403:
            logger.error("GitHub API rate limit exceeded (403)")
            print("\n[X] Cannot reach GitHub API (rate limit or access denied).")
            print("    Please check your internet connection and try again.")
            return False
        else:
            logger.error(f"HTTP error fetching release info: {e}")
            print(f"\n[X] Failed to fetch release information: {e}")
            return False
    except (urllib.error.URLError, Exception) as e:
        logger.error(f"Error fetching release info: {e}")
        print(f"\n[X] Failed to fetch release information: {e}")
        print("    Check your internet connection and try again.")
        return False

    print(f"[*] Downloading source archive for release {tag_name}...")
    logger.info(f"Downloading source archive: {zipball_url}")

    try:
        with tempfile.TemporaryDirectory(prefix="ebook_release_") as tmp_dir:
            zip_path = Path(tmp_dir) / "release.zip"

            req = urllib.request.Request(
                zipball_url, headers={"User-Agent": "web-to-ebook-installer"}
            )
            with urllib.request.urlopen(req, timeout=180) as resp:
                with open(zip_path, "wb") as fout:
                    while True:
                        chunk = resp.read(65536)
                        if not chunk:
                            break
                        fout.write(chunk)

            print("[*] Extracting application files...")
            logger.info(f"Extracting release archive to {install_dir}")

            # GitHub wraps everything in a top-level directory named
            # "{owner}-{repo}-{short_sha}/" – strip it when extracting.
            skip_prefixes = {".git/", "__pycache__/"}

            with zipfile.ZipFile(zip_path, "r") as zf:
                names = zf.namelist()
                # Identify the single top-level directory prefix.
                top_dirs: set[str] = set()
                for name in names:
                    parts = name.split("/", 1)
                    if parts[0]:
                        top_dirs.add(parts[0])
                prefix = (sorted(top_dirs)[0] + "/") if len(top_dirs) == 1 else ""

                extracted = 0
                for member in names:
                    if not member.startswith(prefix):
                        continue
                    rel = member[len(prefix):]
                    if not rel:
                        continue
                    # Skip version-control and cache noise.
                    if any(
                        rel.startswith(p) or ("/" + p) in rel
                        for p in skip_prefixes
                    ):
                        continue
                    target = install_dir / rel
                    if member.endswith("/"):
                        target.mkdir(parents=True, exist_ok=True)
                    else:
                        target.parent.mkdir(parents=True, exist_ok=True)
                        with zf.open(member) as src, open(target, "wb") as dst:
                            shutil.copyfileobj(src, dst)
                        extracted += 1

        print(f"[+] Deployed {extracted} application files from release {tag_name}")
        logger.info(f"Application files deployed from release {tag_name}: {extracted} files")
        return True

    except (urllib.error.URLError, urllib.error.HTTPError) as e:
        logger.error(f"Network error downloading release source: {e}")
        print(f"\n[X] Failed to download release source: {e}")
        print("    Check your internet connection and try again.")
        return False
    except Exception as e:
        logger.error(f"Unexpected error deploying release source: {e}")
        logger.error(f"Traceback:\n{traceback.format_exc()}")
        print(f"\n[X] Failed to deploy application files: {e}")
        return False


def get_log_directory() -> Path:
    """
    Get a writable directory for crash logs.
    Uses system temp directory or user's AppData on Windows.
    """
    if platform.system() == "Windows":
        # Use AppData on Windows
        appdata = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA")
        if appdata:
            log_dir = Path(appdata) / "WebToEbookConverter" / "logs"
        else:
            log_dir = Path(tempfile.gettempdir()) / "WebToEbookConverter" / "logs"
    else:
        # Use temp directory on Unix-like systems
        log_dir = Path(tempfile.gettempdir()) / "WebToEbookConverter" / "logs"

    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        return log_dir
    except Exception:
        # Last resort - use system temp
        fallback = Path(tempfile.gettempdir()) / "installer_logs"
        fallback.mkdir(parents=True, exist_ok=True)
        return fallback


def setup_crash_logger() -> logging.Logger:
    """
    Set up crash logging for the installer.
    Logs to both console and a crash log file.
    """
    logger = logging.getLogger("installer")
    logger.setLevel(logging.DEBUG)

    # Console handler - show all messages to help user see what's happening
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_formatter = logging.Formatter('%(levelname)s: %(message)s')
    console_handler.setFormatter(console_formatter)

    # File handler - log everything to crash log file
    try:
        log_dir = get_log_directory()
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = log_dir / f"installer_{timestamp}.log"

        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)
        file_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        file_handler.setFormatter(file_formatter)

        logger.addHandler(console_handler)
        logger.addHandler(file_handler)

        logger.info(f"Installer logger initialized. Log file: {log_file}")
        print(f"[*] Installer log: {log_file}")
    except Exception as e:
        # If logging setup fails, at least show console output
        logger.addHandler(console_handler)
        logger.warning(f"Failed to set up file logging: {e}")
        print(f"[!] Could not create log file: {e}")

    return logger


def prompt_yes_no(message: str, default: bool = True) -> bool:
    if AUTO_CONFIRM_PROMPTS:
        print(f"{message} [Y/n] y (auto)")
        return True
    suffix = "[Y/n]" if default else "[y/N]"
    value = input(f"{message} {suffix} ").strip().lower()
    if not value:
        return default
    return value in {"y", "yes"}


def choose_install_mode() -> bool:
    """Prompt user to choose installation mode.

    Returns:
        True for Fast Install mode, False for Guided Install mode.
    """
    print("\n" + "=" * 60)
    print("Installation Mode")
    print("=" * 60)
    print("1. Fast Install (auto-answers Yes to all prompts after this step)")
    print("2. Guided Install (recommended for custom choices)")

    while True:
        choice = input("\nSelect option [1/2] (default: 1): ").strip()
        if not choice or choice == "1":
            return True
        if choice == "2":
            return False
        print("[!] Invalid option. Please enter 1 or 2.")


def check_espeak_ng(logger: logging.Logger) -> bool:
    """Check if espeak-ng is installed and available.

    Args:
        logger: Logger instance

    Returns:
        True if espeak-ng is found, False otherwise
    """
    try:
        result = subprocess.run(
            ["espeak-ng", "--version"],
            check=False,
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            version = result.stdout.strip().split('\n')[0] if result.stdout else "unknown version"
            logger.info(f"espeak-ng found: {version}")
            return True
        else:
            logger.warning("espeak-ng command exists but returned non-zero exit code")
            return False
    except FileNotFoundError:
        logger.warning("espeak-ng not found in PATH")
        return False
    except subprocess.TimeoutExpired:
        logger.warning("espeak-ng check timed out")
        return False
    except Exception as e:
        logger.warning(f"Error checking for espeak-ng: {e}")
        return False


def _add_directory_to_path(directory: Path) -> None:
    current_path = os.environ.get("PATH", "")
    normalized_entries = [entry.strip() for entry in current_path.split(os.pathsep) if entry.strip()]
    directory_str = str(directory)
    if directory_str not in normalized_entries:
        os.environ["PATH"] = f"{directory_str}{os.pathsep}{current_path}"


def _find_windows_installed_espeak_executable() -> Path | None:
    espeak_bin = shutil.which("espeak-ng")
    if espeak_bin:
        return Path(espeak_bin)

    candidate_paths = []
    env_roots = [
        os.environ.get("ProgramFiles"),
        os.environ.get("ProgramFiles(x86)"),
        os.environ.get("LOCALAPPDATA"),
    ]
    for root in env_roots:
        if not root:
            continue
        base = Path(root)
        candidate_paths.extend(
            [
                base / "eSpeak NG" / "espeak-ng.exe",
                base / "eSpeak NG" / "command_line" / "espeak-ng.exe",
                base / "Programs" / "eSpeak NG" / "espeak-ng.exe",
                base / "Programs" / "eSpeak NG" / "command_line" / "espeak-ng.exe",
            ]
        )

    for candidate in candidate_paths:
        if candidate.exists() and candidate.is_file():
            return candidate

    return None


def _select_windows_espeak_asset(assets: list[dict]) -> dict | None:
    """Pick the best Windows x64 espeak-ng MSI asset from a GitHub release."""
    ranked_assets = []
    for asset in assets:
        name = str(asset.get("name", ""))
        lower_name = name.lower()
        if not lower_name.endswith(".msi"):
            continue
        if any(token in lower_name for token in ["source", "src", "debug", "symbols"]):
            continue

        score = 0
        if "espeak-ng" in lower_name:
            score += 2
        if "win64" in lower_name or "windows" in lower_name:
            score += 5
        if "x64" in lower_name or "amd64" in lower_name:
            score += 4
        elif "win" in lower_name:
            score += 2

        if score > 0:
            ranked_assets.append((score, asset))

    if not ranked_assets:
        return None

    ranked_assets.sort(key=lambda item: item[0], reverse=True)
    return ranked_assets[0][1]


def install_espeak_ng_windows(logger: logging.Logger, project_dir: Path | None = None) -> bool:
    """Download and install latest espeak-ng MSI on Windows.

    project_dir is retained for backward-compatible call signatures.
    """
    installed_executable = _find_windows_installed_espeak_executable()
    if installed_executable:
        _add_directory_to_path(installed_executable.parent)
        logger.info(f"Found existing espeak-ng installation at: {installed_executable}")
        return check_espeak_ng(logger)

    try:
        print("\n[*] Downloading espeak-ng for Windows...")
        logger.info("Downloading latest espeak-ng MSI release metadata")
        request = urllib.request.Request(
            ESPEAK_NG_RELEASE_API_URL,
            headers={"User-Agent": "web-to-ebook-installer"}
        )
        with urllib.request.urlopen(request, timeout=30) as response:
            release_data = json.loads(response.read().decode("utf-8"))

        assets = release_data.get("assets", [])
        selected_asset = _select_windows_espeak_asset(assets)
        if not selected_asset:
            logger.error("No compatible Windows espeak-ng MSI asset found in latest release")
            return False

        asset_name = selected_asset["name"]
        download_url = selected_asset["browser_download_url"]
        logger.info(f"Selected espeak-ng asset: {asset_name}")

        with tempfile.TemporaryDirectory(prefix="espeak_ng_") as temp_dir:
            installer_path = Path(temp_dir) / asset_name
            print(f"[*] Downloading: {asset_name}")
            urllib.request.urlretrieve(download_url, installer_path)

            print("[*] Installing espeak-ng...")
            install_cmd = ["msiexec", "/i", str(installer_path), "/qn", "/norestart"]
            result = subprocess.run(
                install_cmd,
                check=False,
                capture_output=True,
                text=True
            )
            if result.returncode != 0:
                logger.error(f"espeak-ng MSI installation failed with code {result.returncode}")
            if result.stdout:
                logger.error(f"msiexec stdout: {safe_encode_for_logging(result.stdout.strip())}")
            if result.stderr:
                logger.error(f"msiexec stderr: {safe_encode_for_logging(result.stderr.strip())}")
            return False

        installed_executable = _find_windows_installed_espeak_executable()
        if installed_executable:
            _add_directory_to_path(installed_executable.parent)
            logger.info(f"espeak-ng installed at: {installed_executable}")

        return check_espeak_ng(logger)
    except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError) as e:
        logger.error(f"Failed to download/install espeak-ng: {e}")
        logger.error(f"Traceback:\n{traceback.format_exc()}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error during Windows espeak-ng install: {e}")
        logger.error(f"Traceback:\n{traceback.format_exc()}")
        return False


def check_and_install_espeak_ng(logger: logging.Logger, step_number: str = "") -> int:
    """Check for espeak-ng and optionally install it if missing.

    This function handles the complete espeak-ng check workflow including:
    - Checking if espeak-ng is installed
    - Prompting user for automatic installation if missing
    - Providing manual installation instructions
    - Allowing user to continue without espeak-ng (with warning)

    Args:
        logger: Logger instance
        step_number: Optional step number to display (e.g., "2" or "4")

    Returns:
        0 on success or user choice to continue, 1 if user cancels installation
    """
    step_label = f"Step {step_number}: " if step_number else ""
    print("\n" + "=" * 60)
    print(f"{step_label}Checking for espeak-ng")
    print("=" * 60)
    logger.info(f"Checking for espeak-ng installation ({step_label.strip()})")

    espeak_found = check_espeak_ng(logger)

    if espeak_found:
        print("\n[+] espeak-ng is installed and available!")
        logger.info("espeak-ng verification successful")
        return 0

    print("\n[X] espeak-ng is NOT installed or not found in PATH")
    print("\n[!] IMPORTANT: espeak-ng is required for Kokoro TTS")
    print("   Audio generation will not work without it.")

    if prompt_yes_no("\nAttempt automatic espeak-ng installation now?", True):
        logger.info("User requested automatic espeak-ng installation")
        if install_espeak_ng(logger):
            espeak_found = check_espeak_ng(logger)

    if espeak_found:
        print("\n[+] espeak-ng installed successfully.")
        logger.info("espeak-ng installed successfully")
        return 0

    print("\n[X] Automatic espeak-ng installation failed or was skipped.")
    print("\nManual installation instructions:")
    print("  - Linux: sudo apt-get install espeak-ng")
    print("  - macOS: brew install espeak-ng")
    print("  - Windows: Download from https://github.com/espeak-ng/espeak-ng/releases")
    print("             After installation, add espeak-ng to your PATH")

    if not prompt_yes_no("\nContinue installation anyway? (Not recommended)", False):
        print("\nInstallation cancelled. Please install espeak-ng and try again.")
        logger.info("Installation cancelled due to missing espeak-ng")
        if platform.system() == "Windows":
            input("\nPress Enter to exit...")
        return 1

    print("\n[!] WARNING: Continuing without espeak-ng")
    print("   Remember to install it before generating audio!")
    logger.warning("User chose to continue without espeak-ng")
    return 0


def install_espeak_ng(logger: logging.Logger, project_dir: Path | None = None) -> bool:
    """Attempt to install espeak-ng automatically for the current platform.

    project_dir is kept for backward compatibility with older callers.
    """
    if sys.platform == "win32":
        return install_espeak_ng_windows(logger, project_dir)

    if sys.platform == "darwin":
        if not shutil.which("brew"):
            print("\nHomebrew is not installed. Install Homebrew first:")
            print('/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"')
            return False
        if not prompt_yes_no("\nInstall espeak-ng via Homebrew now?", True):
            return False
        result = subprocess.run(["brew", "install", "espeak-ng"], check=False)
        return result.returncode == 0

    if sys.platform.startswith("linux"):
        install_cmd = None
        if shutil.which("apt-get"):
            install_cmd = ["apt-get", "install", "espeak-ng"]
        elif shutil.which("dnf"):
            install_cmd = ["dnf", "install", "espeak-ng"]
        elif shutil.which("pacman"):
            install_cmd = ["pacman", "-S", "espeak-ng"]

        if not install_cmd:
            print("\nNo supported package manager detected for automatic espeak-ng installation.")
            return False

        is_root = hasattr(os, "geteuid") and os.geteuid() == 0
        if not is_root and shutil.which("sudo"):
            install_cmd = ["sudo"] + install_cmd

        print("\nThis will run:")
        print(f"  {' '.join(install_cmd)}")
        if not prompt_yes_no("Proceed with automatic espeak-ng installation?", True):
            return False

        result = subprocess.run(install_cmd, check=False)
        return result.returncode == 0

    print("\nAutomatic espeak-ng installation is not supported on this platform.")
    return False


def _stream_subprocess(
    cmd: list[str],
    logger: logging.Logger,
) -> int:
    """Run a command and stream its combined stdout/stderr to the console and logger.

    Returns the process exit code.
    """
    process = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=False,  # Read as bytes to avoid encoding errors
        bufsize=1,
    )
    if process.stdout is None:
        process.wait()
        return process.returncode
    for raw_line_bytes in process.stdout:
        # Decode bytes with error handling to avoid Windows 'charmap' codec errors
        try:
            raw_line = raw_line_bytes.decode('utf-8', errors='replace')
        except Exception:
            # Fallback: try system encoding with replace errors
            raw_line = raw_line_bytes.decode(errors='replace')
        line = safe_encode_for_logging(raw_line.rstrip("\n"))
        print(line)
        logger.debug(line)
    process.wait()
    return process.returncode


def _venv_python_path(venv_dir: Path) -> Path:
    """Return the Python executable path for a venv directory."""
    if platform.system() == "Windows":
        return venv_dir / "Scripts" / "python.exe"
    return venv_dir / "bin" / "python3"


def ensure_app_local_venv(
    logger: logging.Logger,
    install_dir: Path,
    base_python_executable: Path,
) -> tuple[bool, Path]:
    """Create and prepare app-local virtual environment when missing."""
    venv_dir = install_dir / APP_VENV_DIR_NAME
    venv_python = _venv_python_path(venv_dir)

    if not venv_python.exists():
        print(f"\n[*] Creating app-local virtual environment: {venv_dir}")
        logger.info(f"Creating app-local virtual environment: {venv_dir}")
        create_cmd = [str(base_python_executable), "-m", "venv", str(venv_dir)]
        returncode = _stream_subprocess(create_cmd, logger)
        if returncode != 0:
            print(f"\n[X] Failed to create app-local virtual environment (exit code {returncode}).")
            logger.error(f"Failed to create venv at {venv_dir}; exit code {returncode}")
            return False, venv_python

    if not venv_python.exists():
        print(f"\n[X] Virtual environment Python not found at {venv_python}")
        logger.error(f"Virtual environment Python missing: {venv_python}")
        return False, venv_python

    print("\n[*] Ensuring pip is available in app-local virtual environment...")
    logger.info("Ensuring pip is available in app-local virtual environment")
    ensurepip_cmd = [str(venv_python), "-m", "ensurepip", "--upgrade"]
    ensurepip_returncode = _stream_subprocess(ensurepip_cmd, logger)
    if ensurepip_returncode != 0:
        logger.warning(f"ensurepip returned non-zero ({ensurepip_returncode}); continuing to pip upgrade")

    print("[*] Upgrading pip in app-local virtual environment...")
    logger.info("Upgrading pip in app-local virtual environment")
    pip_upgrade_cmd = [str(venv_python), "-m", "pip", "install", "--upgrade", "pip"]
    pip_returncode = _stream_subprocess(pip_upgrade_cmd, logger)
    if pip_returncode != 0:
        print(f"\n[X] Failed to upgrade pip in app-local virtual environment (exit code {pip_returncode}).")
        logger.error(f"Failed to upgrade pip in app-local venv; exit code {pip_returncode}")
        return False, venv_python

    return True, venv_python


def install_python_packages(
    packages: list[str],
    logger: logging.Logger,
    python_executable: Path,
    index_url: str = None
) -> bool:
    """Install Python packages with live output streaming.

    Args:
        packages: List of package names to install
        logger: Logger instance
        python_executable: Python executable path used to install packages
        index_url: Optional index URL for pip (e.g., for PyTorch packages)

    Returns:
        True if installation succeeded, False otherwise
    """
    print(f"\nInstalling: {', '.join(packages)}")
    print("[*] This may take several minutes for large packages - please wait...")
    logger.info(f"Installing packages: {', '.join(packages)}")

    cmd = [str(python_executable), "-m", "pip", "install"]
    if index_url:
        cmd.extend(["--index-url", index_url])
    cmd.extend(packages)

    try:
        returncode = _stream_subprocess(cmd, logger)
        if returncode == 0:
            logger.info(f"Successfully installed: {', '.join(packages)}")
            return True
        logger.error(f"Failed to install packages: {', '.join(packages)} (exit code {returncode})")
        print(f"\n[X] Failed to install: {', '.join(packages)} (exit code {returncode})")
        return False
    except Exception as e:
        logger.error(f"Unexpected exception while installing {', '.join(packages)}: {e}")
        logger.error(f"Traceback:\n{traceback.format_exc()}")
        print(f"\n[X] Unexpected error during installation: {e}")
        return False


def check_tkinter_support(
    logger: logging.Logger,
    python_executable: Path
) -> tuple[bool, str]:
    """Check whether tkinter is available in the current Python runtime."""
    try:
        result = subprocess.run(
            [str(python_executable), "-c", "import tkinter"],
            check=False,
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            return True, ""

        stderr_text = safe_encode_for_logging((result.stderr or "").strip())
        stdout_text = safe_encode_for_logging((result.stdout or "").strip())
        error_text = "\n".join(part for part in [stderr_text, stdout_text] if part)
        logger.error(f"tkinter availability check failed: {error_text}")
        return False, error_text
    except Exception as e:
        logger.error(f"Unexpected error while checking tkinter availability: {e}")
        logger.error(f"Traceback:\n{traceback.format_exc()}")
        return False, str(e)


def validate_installation(
    logger: logging.Logger,
    project_dir: Path,
) -> tuple[bool, list[str]]:
    """Validate that all required application files exist in the installation directory.

    Args:
        logger: Logger instance
        project_dir: Installation directory to validate

    Returns:
        Tuple of (success: bool, missing_files: list[str])
    """
    logger.info(f"Validating installation in {project_dir}")
    print("\n[*] Validating installation...")

    missing_files = []

    # Check required files
    for filename in INSTALLATION_VALIDATION_FILES:
        filepath = project_dir / filename
        if not filepath.exists():
            missing_files.append(filename)
            logger.error(f"Required file missing: {filename}")

    # Check required directories
    for dirname in INSTALLATION_VALIDATION_DIRECTORIES:
        dirpath = project_dir / dirname
        if not dirpath.exists() or not dirpath.is_dir():
            missing_files.append(f"{dirname}/")
            logger.error(f"Required directory missing: {dirname}")

    if missing_files:
        print(f"[X] Validation failed - missing {len(missing_files)} required files:")
        for missing in missing_files:
            print(f"    - {missing}")
        logger.error(f"Installation validation failed: {len(missing_files)} files missing")
        return False, missing_files

    print(f"[+] Validation successful - all required files present")
    logger.info("Installation validation successful")
    return True, []


def _escape_ps_path(path: Path) -> str:
    """Return a path string safe for use inside a PowerShell single-quoted string.

    Single-quoted PowerShell strings expand nothing, so only a literal single
    quote needs escaping (by doubling it).
    """
    return str(path).replace("'", "''")


def _create_windows_shortcut(
    logger: logging.Logger,
    target_exe: Path,
    shortcut_path: Path,
    working_dir: Path,
) -> bool:
    """Create a Windows .lnk shortcut using PowerShell's WScript.Shell COM object.

    Returns True when the shortcut was created successfully, False otherwise.
    """
    try:
        # Use PowerShell single-quoted strings so that backslashes and dollar
        # signs in Windows paths are treated as literals (no variable expansion,
        # no escape sequences).  Single quotes inside the path are doubled.
        ps_cmd = (
            f"$ws = New-Object -ComObject WScript.Shell; "
            f"$sc = $ws.CreateShortcut('{_escape_ps_path(shortcut_path)}'); "
            f"$sc.TargetPath = '{_escape_ps_path(target_exe)}'; "
            f"$sc.WorkingDirectory = '{_escape_ps_path(working_dir)}'; "
            f"$sc.Description = 'Web to Ebook Converter'; "
            f"$sc.Save()"
        )
        subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                ps_cmd,
            ],
            check=True,
            capture_output=True,
            text=True,
            timeout=30,
        )
        if shortcut_path.exists():
            logger.info(f"Created Windows shortcut at: {shortcut_path}")
            return True
        logger.warning(f"PowerShell ran without error but shortcut not found: {shortcut_path}")
        return False
    except Exception as e:
        logger.warning(f"Failed to create Windows shortcut: {e}")
        logger.debug(f"Shortcut creation traceback:\n{traceback.format_exc()}")
        return False


def create_post_install_launcher(
    logger: logging.Logger,
    project_dir: Path,
) -> Path | None:
    """Create a post-install launcher.

    On Windows this creates a desktop .lnk shortcut pointing to app.exe in the
    installation directory when app.exe is available, otherwise falls back to a
    .bat launcher.  On Unix-like systems it creates a .sh launcher.
    The launcher is created on the user's Desktop when available, otherwise in the
    installation directory.
    """
    try:
        run_script = WINDOWS_RUN_SCRIPT_NAME if sys.platform == "win32" else UNIX_RUN_SCRIPT_NAME
        run_script_path = project_dir / run_script
        if not run_script_path.exists():
            logger.warning(f"Launcher target missing: {run_script_path}")
            return None

        desktop_dir = Path.home() / "Desktop"
        target_dir = desktop_dir if desktop_dir.exists() else project_dir

        if sys.platform == "win32":
            app_exe_path = project_dir / "app.exe"
            if app_exe_path.exists():
                shortcut_path = target_dir / WINDOWS_SHORTCUT_LAUNCHER_NAME
                if _create_windows_shortcut(logger, app_exe_path, shortcut_path, project_dir):
                    return shortcut_path
                # Fall through to .bat if shortcut creation failed.

            launcher_path = target_dir / WINDOWS_LAUNCHER_NAME
            launcher_content = (
                "@echo off\n"
                f"set \"RUN_SCRIPT={run_script_path}\"\n"
                "call \"%RUN_SCRIPT%\"\n"
            )
        else:
            launcher_path = target_dir / UNIX_LAUNCHER_NAME
            launcher_content = (
                "#!/usr/bin/env bash\n"
                f"\"{run_script_path}\"\n"
            )

        launcher_path.write_text(launcher_content, encoding="utf-8")
        if sys.platform != "win32":
            launcher_path.chmod(0o755)

        logger.info(f"Created launcher at: {launcher_path}")
        return launcher_path
    except Exception as e:
        logger.warning(f"Failed to create launcher: {e}")
        logger.debug(f"Launcher creation traceback:\n{traceback.format_exc()}")
        return None


def _finish_installation(
    logger: logging.Logger,
    project_dir: Path,
    python_executable: Path,
) -> int:
    """Print success summary, next-step hints, and optionally launch the GUI.

    Returns 0 on success, 1 on failure.
    """
    print("\n[+] Installation complete.")
    logger.info("Installation completed successfully")

    # Show important first-run information
    print("\n" + "=" * 60)
    print("[*] Installation Successful!")
    print("=" * 60)
    print("\n[*] IMPORTANT - First Run Setup:")
    print("  When you first generate audio, Kokoro TTS will:")
    print("  - Automatically download required models")
    print("  - Cache them locally for future use")
    print("  - Models are much smaller than previous TTS systems")
    print("\n  [*] Tip: Ensure espeak-ng is installed on your system")
    print("  [*] First generation will be fast - Kokoro is lightweight!")

    # Show next steps
    print("\n" + "=" * 60)
    print("Next Steps")
    print("=" * 60)
    print("\n1. Ensure espeak-ng is installed (see instructions above)")
    print("\n2. Preview voices to choose your favorite (recommended):")
    print("   python voice_preview.py")
    print("\n3. Launch the GUI for easy conversion:")
    if sys.platform == "win32":
        print("   run_app.bat")
    else:
        print("   ./run_app.sh")
    print("\n4. Or use command line (see README.md for examples)")
    print("\n5. Check USER_GUIDE.md for detailed documentation")
    print("\n6. To uninstall later:")
    if sys.platform == "win32":
        print("   uninstall.bat")
    else:
        print("   ./uninstall.sh")

    launcher_path = create_post_install_launcher(logger, project_dir)
    if launcher_path:
        print("\n7. Launcher created:")
        print(f"   {launcher_path}")
    else:
        print("\n7. Launcher was not created automatically.")
        if sys.platform == "win32":
            print("   You can still launch with: run_app.bat")
        else:
            print("   You can still launch with: ./run_app.sh")
    print()

    # Auto-launch GUI
    if prompt_yes_no("\nLaunch GUI now?", True):
        print("\nLaunching GUI...")
        logger.info("Launching GUI")

        # Validate installation before attempting to launch
        validation_success, missing_files = validate_installation(logger, project_dir)
        if not validation_success:
            print("\n[!] Cannot launch GUI: Installation validation failed")
            print("    Required files are missing. This may indicate:")
            print("    - Installation was interrupted")
            print("    - File deployment failed")
            print("    - Incorrect installation directory")
            print("\n    Please try running the installer again.")
            logger.error(f"GUI launch aborted due to failed validation: {len(missing_files)} files missing")
            if platform.system() == "Windows":
                input("\nPress Enter to exit...")
            return 1

        tkinter_available, tkinter_error = check_tkinter_support(logger, python_executable)
        if not tkinter_available:
            print("\n[!] Failed to launch GUI: tkinter is not available in this Python installation.")
            print("This usually means your Python runtime does not include GUI support.")
            if tkinter_error:
                print(f"Details: {tkinter_error}")
            print("\nPlease install a full Python distribution with tkinter support and re-run installer.")
            logger.error("GUI launch aborted because tkinter is unavailable")

            # Keep console open on Windows
            if platform.system() == "Windows":
                input("\nPress Enter to exit...")
            return 1

        gui_path = project_dir / "gui.py"
        launch_cmd = [str(python_executable), str(gui_path)]
        try:
            gui_process = subprocess.Popen(launch_cmd, cwd=str(project_dir))
            startup_deadline = time.monotonic() + GUI_STARTUP_CHECK_DELAY_SECONDS
            while gui_process.poll() is None:
                remaining = startup_deadline - time.monotonic()
                if remaining <= 0:
                    break
                time.sleep(min(GUI_STARTUP_POLL_INTERVAL_SECONDS, remaining))

            # If still running after the startup monitoring window, treat as successful launch.
            if gui_process.poll() is None:
                logger.info("GUI launched successfully")
            else:
                logger.error(f"GUI process exited immediately with code {gui_process.returncode}")

                # Re-run once with captured output to provide actionable diagnostics.
                stderr_text = ""
                stdout_text = ""
                try:
                    diagnostic_result = subprocess.run(
                        launch_cmd,
                        check=False,
                        capture_output=True,
                        text=True,
                        timeout=GUI_DIAGNOSTIC_TIMEOUT_SECONDS,
                        cwd=str(project_dir)
                    )
                    stderr_text = safe_encode_for_logging((diagnostic_result.stderr or "").strip())
                    stdout_text = safe_encode_for_logging((diagnostic_result.stdout or "").strip())
                except subprocess.TimeoutExpired:
                    stderr_text = f"GUI diagnostic capture timed out after {GUI_DIAGNOSTIC_TIMEOUT_SECONDS} seconds."

                if stdout_text:
                    logger.error(f"GUI stdout: {stdout_text}")
                if stderr_text:
                    logger.error(f"GUI stderr: {stderr_text}")
                print(f"\n[!] GUI exited immediately with code {gui_process.returncode}.")
                if stderr_text:
                    print(f"Error: {stderr_text}")
                elif stdout_text:
                    print(f"Output: {stdout_text}")
                if sys.platform == "win32":
                    print("You can retry manually with: run_app.bat")
                else:
                    print("You can retry manually with: ./run_app.sh")

                # Keep console open on Windows
                if platform.system() == "Windows":
                    input("\nPress Enter to exit...")
                return 1
        except Exception as e:
            logger.error(f"Failed to launch GUI: {e}")
            logger.error(f"Traceback:\n{traceback.format_exc()}")
            print(f"\n[!] Failed to launch GUI: {e}")
            if sys.platform == "win32":
                print("You can manually launch it with: run_app.bat")
            else:
                print("You can manually launch it with: ./run_app.sh")

            # Keep console open on Windows
            if platform.system() == "Windows":
                input("\nPress Enter to exit...")
            return 1
    else:
        if sys.platform == "win32":
            print("\nTo launch the GUI later, run: run_app.bat")
        else:
            print("\nTo launch the GUI later, run: ./run_app.sh")
        logger.info("User declined to launch GUI")

    # Keep console open on Windows so user can read the output
    if platform.system() == "Windows":
        input("\nPress Enter to exit...")

    return 0


def run_installer() -> int:
    # Initialize crash logger first
    logger = setup_crash_logger()

    print("=" * 60)
    print("Web to Ebook Converter - Interactive Installer")
    print("=" * 60)
    print("\nThis installer will set up dependencies for Kokoro TTS,")
    print("which provides high-quality natural-sounding audiobook generation")
    print("with multilingual support.")
    print("\n[*] What will be installed:")
    print("  - Application source (downloaded from latest GitHub release)")
    print("  - Portable Python 3.11 runtime (downloaded from python.org)")
    print("  - Core dependencies (requests, beautifulsoup4, ebooklib, PyYAML)")
    print("  - PyTorch - Deep learning framework")
    print("  - Kokoro TTS dependencies (Kokoro source is bundled in the project)")
    print("  - Additional audio libraries (soundfile, numpy)")
    print("  - NLP libraries (huggingface_hub, transformers, loguru, misaki)")
    print("\n[*] Kokoro TTS Features:")
    print("  - 10+ natural-sounding voices (male and female)")
    print("  - 9 language support (English, Spanish, French, German, etc.)")
    print("  - Adjustable speaking speed (0.5x to 2.0x)")
    print("  - Professional audiobook-quality output")
    print("  - Lightweight (82M parameters) - faster than larger models")
    print("\n[*] First-run setup:")
    print("  - Models download automatically on first use")
    print("  - Requires espeak-ng to be installed on your system")
    print("  - Much smaller and faster than previous TTS systems")
    print("  - Kokoro is bundled directly in the project for stability")

    logger.info("Starting installer")

    # Determine installation directory
    project_dir = get_install_directory()
    logger.info(f"Installation directory: {project_dir}")

    fast_install = choose_install_mode()
    global AUTO_CONFIRM_PROMPTS
    AUTO_CONFIRM_PROMPTS = fast_install
    if fast_install:
        print("\n[*] Fast Install selected - all prompts will be auto-confirmed with Yes.")
        logger.info("Fast install mode enabled")
    else:
        print("\n[*] Guided Install selected.")
        logger.info("Guided install mode enabled")

    # Deploy application files.
    # When running as a frozen executable the installer no longer bundles the app
    # source files; instead, download them from the latest GitHub release so the
    # same installer.exe works for every release without needing to be rebuilt.
    if getattr(sys, 'frozen', False):
        if not download_and_deploy_release_source(project_dir, logger):
            print("\n[X] Failed to download application files.")
            print("    Check your internet connection and try again.")
            logger.error("Release source download failed")
            if platform.system() == "Windows":
                input("\nPress Enter to exit...")
            return 1
    else:
        # Running as a plain script – files are already in place.
        if not deploy_application_files(logger, project_dir):
            print("\n[X] Failed to deploy application files.")
            print("    Installation cannot continue.")
            logger.error("Application file deployment failed")
            return 1

    # When running as a PyInstaller frozen executable, provision the Python runtime
    # that will be used to create the app-local virtual environment.
    # The runtime is downloaded from NuGet at install time instead of being baked
    # into the installer exe, keeping the exe small and stable across releases.
    if getattr(sys, 'frozen', False):
        if platform.system() == "Windows":
            private_python = project_dir / PYTHON_RUNTIME_DIRNAME / "python.exe"
            if not private_python.exists():
                if not download_python_runtime_to_dir(project_dir, logger):
                    print("\n[X] Failed to provision Python runtime.")
                    print("    Check your internet connection and try again.")
                    logger.error("Python runtime download failed")
                    input("\nPress Enter to exit...")
                    return 1

            if not private_python.exists():
                print("\n[X] ERROR: Python runtime was not found after download.")
                print(f"    Expected: {private_python}")
                logger.error(f"Python runtime missing after download: {private_python}")
                input("\nPress Enter to exit...")
                return 1

            logger.info(f"Using Python runtime: {private_python}")
            venv_ok, venv_python = ensure_app_local_venv(logger, project_dir, private_python)
            if not venv_ok:
                input("\nPress Enter to exit...")
                return 1
            python_executable = venv_python
            logger.info(f"Using app-local virtual environment Python: {python_executable}")
        else:
            # Fallback for non-Windows frozen builds
            python_executable = shutil.which("python3") or shutil.which("python")
            if not python_executable:
                print("\n[X] ERROR: Cannot find Python interpreter on your system.")
                print("    The installer requires Python 3.8+ to be installed and available in PATH.")
                print("\n    Please install Python from https://www.python.org/downloads/")
                logger.error("Python interpreter not found in PATH when running as non-Windows frozen executable")
                return 1
            python_executable = Path(python_executable)
            logger.info(f"Found Python interpreter: {python_executable}")
    else:
        # Running as a script - use the current Python
        python_executable = Path(sys.executable)

    if not prompt_yes_no("\nProceed with installation?", True):
        print("Installation cancelled.")
        logger.info("Installation cancelled by user")
        return 0

    logger.info(f"Using Python executable: {python_executable}")

    logger.info("Starting guided installation flow")
    print("\n" + "=" * 60)
    print("Step 1: Installing Core Dependencies")
    print("=" * 60)
    if not install_python_packages(CORE_PACKAGES, logger, python_executable):
        print("\n[X] Failed to install core dependencies.")
        logger.error("Core package installation failed")

        # Keep console open on Windows
        if platform.system() == "Windows":
            input("\nPress Enter to exit...")
        return 1

    # Install advanced scraper features (always)
    print("\n" + "=" * 60)
    print("Step 2: Installing Advanced Web Scraper")
    print("=" * 60)
    print("\n[*] Advanced scraper handles challenging websites with:")
    print("  - Cloudflare protection and anti-bot challenges")
    print("  - JavaScript-rendered content")
    print("  - Fragmented DOM structures (text split across many spans)")
    print("  - Zero-width character obfuscation")
    print("  - Anti-copy CSS overlays")
    print("\n[*] This installs Playwright (headless browser)")
    print("  - Adds ~300MB of dependencies")
    print("  - Required for sites like NovelDex, protected web novels")

    logger.info("Installing advanced scraper packages")
    if not install_python_packages(ADVANCED_SCRAPER_PACKAGES, logger, python_executable):
        print("\n[X] Failed to install advanced scraper packages.")
        logger.error("Advanced scraper installation failed")

        # Keep console open on Windows
        if platform.system() == "Windows":
            input("\nPress Enter to exit...")
        return 1

    print("\n[+] Advanced scraper packages installed.")
    print("\n[*] Installing Playwright browsers (this may take a few minutes - please wait)...")
    logger.info("Installing Playwright browsers")
    try:
        returncode = _stream_subprocess(
            [str(python_executable), "-m", "playwright", "install", "msedge"],
            logger,
        )
        if returncode == 0:
            print("[+] Playwright Edge browser installed successfully.")
            logger.info("Playwright browsers installed successfully")
        else:
            print(f"\n[X] Failed to install Playwright browsers (exit code {returncode}).")
            print("Run this manually after fixing the issue:")
            print("   python -m playwright install msedge")
            logger.error(f"Playwright browser installation failed with exit code {returncode}")

            # Keep console open on Windows
            if platform.system() == "Windows":
                input("\nPress Enter to exit...")
            return 1
    except Exception as e:
        logger.error(f"Unexpected error installing Playwright browsers: {e}")
        print(f"\n[X] Error installing Playwright browsers: {e}")

        # Keep console open on Windows
        if platform.system() == "Windows":
            input("\nPress Enter to exit...")
        return 1

    # Install Kokoro TTS dependencies
    print("\n" + "=" * 60)
    print("Step 3: Installing Kokoro TTS Dependencies")
    print("=" * 60)
    print("\n[*] About Kokoro TTS:")
    print("  - Lightweight, fast TTS engine with 82M parameters")
    print("  - High-quality, natural-sounding voices")
    print("  - Much faster than larger TTS models")
    print("  - Apache-licensed for production use")
    print("  - Bundled directly in this project for stability")
    print("\n[*] GPU Acceleration:")
    print("  - CPU version: Works on all systems (slower)")
    print("  - CUDA version: 5-10x faster with NVIDIA GPU (requires CUDA)")
    print("  - The app will auto-detect and use GPU if available")
    print("\n[*] Installation time: 2-5 minutes depending on connection")
    print("=" * 60 + "\n")

    logger.info("Installing Kokoro TTS dependencies")

    # Ask user whether to install CUDA or CPU version
    install_cuda = False
    try:
        import torch
        if torch.cuda.is_available():
            print("\n[*] CUDA detected on your system!")
            install_cuda = prompt_yes_no(
                "Install CUDA-enabled PyTorch for GPU acceleration?",
                default=True
            )
        else:
            print("\n[*] No CUDA GPU detected. Installing CPU version.")
            cuda_choice = prompt_yes_no(
                "Do you want to install CUDA version anyway? (Only if you have an NVIDIA GPU)",
                default=False
            )
            if cuda_choice:
                install_cuda = True
                print("[!] Installing CUDA version. Make sure CUDA toolkit is installed.")
    except ImportError:
        # torch not installed yet, ask user
        print("\n[*] PyTorch not yet installed.")
        install_cuda = prompt_yes_no(
            "Do you have an NVIDIA GPU and want GPU acceleration? (10x faster)",
            default=False
        )

    try:
        # Install PyTorch
        if install_cuda:
            print("\n[*] Installing CUDA-enabled PyTorch (this may take a few minutes)...")
            pytorch_index = "https://download.pytorch.org/whl/cu118"  # CUDA 11.8
            logger.info("Installing CUDA-enabled PyTorch")
        else:
            print("\n[*] Installing CPU-only PyTorch (this may take a few minutes)...")
            pytorch_index = "https://download.pytorch.org/whl/cpu"
            logger.info("Installing CPU-only PyTorch")

        if not install_python_packages(TORCH_PACKAGES, logger, python_executable, index_url=pytorch_index):
            print("\n[X] Failed to install PyTorch.")
            if install_cuda:
                print("[*] TIP: CUDA installation failed. You may need:")
                print("   - NVIDIA GPU drivers installed")
                print("   - CUDA Toolkit 11.8 or compatible version")
                print("   - Try CPU version if you don't have an NVIDIA GPU")
            else:
                print("[*] TIP: If you're on Windows, you may need Visual Studio Build Tools.")
                print("   You can download them from: https://visualstudio.microsoft.com/downloads/")
            logger.error("PyTorch installation failed")

            # Keep console open on Windows
            if platform.system() == "Windows":
                input("\nPress Enter to exit...")
            return 1

        # Install other Kokoro dependencies from PyPI
        print("\n[*] Installing other Kokoro dependencies...")
        if not install_python_packages(OTHER_KOKORO_PACKAGES, logger, python_executable):
            print("\n[X] Failed to install Kokoro dependencies.")
            logger.error("Kokoro dependencies installation failed")

            # Keep console open on Windows
            if platform.system() == "Windows":
                input("\nPress Enter to exit...")
            return 1

        print("\n[+] Kokoro TTS dependencies installed successfully.")
        logger.info("Kokoro TTS dependencies installed successfully")

        # Check for espeak-ng (applies to Guided Install)
        result = check_and_install_espeak_ng(logger, step_number="4")
        if result != 0:
            return result

        print("=" * 60 + "\n")
    except Exception as e:
        logger.critical(f"Critical error during installation: {e}")
        logger.critical(f"Full traceback:\n{traceback.format_exc()}")
        print(f"\n[X] CRITICAL ERROR during installation: {e}")
        print(f"Check the log file for full details.")
        print(f"Traceback:\n{traceback.format_exc()}")

        # Keep console open on Windows
        if platform.system() == "Windows":
            input("\nPress Enter to exit...")
        return 1

    return _finish_installation(logger, project_dir, python_executable)


if __name__ == "__main__":
    try:
        raise SystemExit(run_installer())
    except Exception as e:
        # Catastrophic failure - try to log if possible
        try:
            logger = logging.getLogger("installer")
            if not logger.handlers:
                # Logger not initialized yet, create emergency logger
                log_dir = get_log_directory()
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                log_file = log_dir / f"installer_crash_{timestamp}.log"
                logging.basicConfig(
                    filename=log_file,
                    level=logging.DEBUG,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
                )
                logger = logging.getLogger("installer")
                print(f"[*] Emergency crash log: {log_file}")

            logger.critical(f"Catastrophic installer failure: {e}")
            logger.critical(f"Full traceback:\n{traceback.format_exc()}")
            print(f"\n[X] CATASTROPHIC ERROR: {e}")
            print(f"Check the crash log for full details.")
            print(f"Traceback:\n{traceback.format_exc()}")
        except:
            # Last resort - just print
            print(f"\n[X] CATASTROPHIC ERROR: {e}")
            print(f"Traceback:\n{traceback.format_exc()}")
            print("Failed to write crash log.")

        # Keep console window open on Windows
        if platform.system() == "Windows":
            input("\nPress Enter to exit...")
        raise SystemExit(1)
