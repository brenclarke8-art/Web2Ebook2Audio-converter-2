"""
Shared Kokoro voice catalog used by GUI, previews, and character assignment.
"""

from collections import OrderedDict
from typing import Dict, List


# Extended built-in Kokoro voice catalog (name -> metadata)
# Prefixes:
#   af/am = American female/male
#   bf/bm = British female/male
KOKORO_VOICE_CATALOG: Dict[str, Dict[str, str]] = OrderedDict([
    ("af_heart", {"gender": "female", "accent": "american", "lang_code": "a", "description": "Warm and clear"}),
    ("af_alloy", {"gender": "female", "accent": "american", "lang_code": "a", "description": "Balanced"}),
    ("af_aoede", {"gender": "female", "accent": "american", "lang_code": "a", "description": "Light and airy"}),
    ("af_bella", {"gender": "female", "accent": "american", "lang_code": "a", "description": "Expressive"}),
    ("af_jessica", {"gender": "female", "accent": "american", "lang_code": "a", "description": "Conversational"}),
    ("af_kore", {"gender": "female", "accent": "american", "lang_code": "a", "description": "Steady"}),
    ("af_nicole", {"gender": "female", "accent": "american", "lang_code": "a", "description": "Friendly"}),
    ("af_nova", {"gender": "female", "accent": "american", "lang_code": "a", "description": "Modern"}),
    ("af_river", {"gender": "female", "accent": "american", "lang_code": "a", "description": "Natural"}),
    ("af_sarah", {"gender": "female", "accent": "american", "lang_code": "a", "description": "Professional"}),
    ("af_sky", {"gender": "female", "accent": "american", "lang_code": "a", "description": "Bright"}),
    ("am_adam", {"gender": "male", "accent": "american", "lang_code": "a", "description": "Clear narrator"}),
    ("am_echo", {"gender": "male", "accent": "american", "lang_code": "a", "description": "Smooth"}),
    ("am_eric", {"gender": "male", "accent": "american", "lang_code": "a", "description": "Confident"}),
    ("am_fenrir", {"gender": "male", "accent": "american", "lang_code": "a", "description": "Deep"}),
    ("am_liam", {"gender": "male", "accent": "american", "lang_code": "a", "description": "Calm"}),
    ("am_michael", {"gender": "male", "accent": "american", "lang_code": "a", "description": "Professional"}),
    ("am_onyx", {"gender": "male", "accent": "american", "lang_code": "a", "description": "Rich"}),
    ("am_puck", {"gender": "male", "accent": "american", "lang_code": "a", "description": "Lively"}),
    ("am_santa", {"gender": "male", "accent": "american", "lang_code": "a", "description": "Warm"}),
    ("bf_alice", {"gender": "female", "accent": "british", "lang_code": "b", "description": "British"}),
    ("bf_emma", {"gender": "female", "accent": "british", "lang_code": "b", "description": "British accent"}),
    ("bf_isabella", {"gender": "female", "accent": "british", "lang_code": "b", "description": "British, elegant"}),
    ("bf_lily", {"gender": "female", "accent": "british", "lang_code": "b", "description": "British, soft"}),
    ("bm_daniel", {"gender": "male", "accent": "british", "lang_code": "b", "description": "British"}),
    ("bm_fable", {"gender": "male", "accent": "british", "lang_code": "b", "description": "British, storytelling"}),
    ("bm_george", {"gender": "male", "accent": "british", "lang_code": "b", "description": "British accent"}),
    ("bm_lewis", {"gender": "male", "accent": "british", "lang_code": "b", "description": "British, authoritative"}),
])


def get_kokoro_voice_names() -> List[str]:
    """Return catalog voice names in display order."""
    return list(KOKORO_VOICE_CATALOG.keys())
