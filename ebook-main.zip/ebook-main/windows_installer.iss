#define MyAppName "Web to Ebook Converter"
#ifndef MyAppVersion
  #define MyAppVersion "0.1.0"
#endif
#ifndef DistDir
  #define DistDir "dist"
#endif
#ifndef OutputDir
  #define OutputDir "installer_output"
#endif

[Setup]
AppId={{B0D895C3-7D77-4BA5-944B-1B79071C5AB3}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher=brenclarke8-art
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
OutputDir={#OutputDir}
OutputBaseFilename=WebToEbookInstaller
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional icons:"

[Files]
Source: "{#DistDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "install_espeak_ng.ps1"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\app.exe"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\app.exe"; Tasks: desktopicon

[Run]
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\install_espeak_ng.ps1"""; Description: "Install required espeak-ng runtime"; StatusMsg: "Installing espeak-ng runtime..."; Flags: waituntilterminated
Filename: "{app}\app.exe"; Description: "Launch {#MyAppName}"; Flags: nowait postinstall skipifsilent
