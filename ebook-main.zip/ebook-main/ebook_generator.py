from typing import Optional
from ebooklib import epub
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class EbookGenerator:
    """Generate EPUB files from chapters"""

    CUSTOM_CSS = """
    body {
        font-family: 'Georgia', serif;
        line-height: 1.8;
        color: #333;
        margin: 20px;
    }
    h1 {
        color: #2c3e50;
        border-bottom: 2px solid #3498db;
        padding-bottom: 10px;
        margin-top: 30px;
        font-size: 1.8em;
    }
    h2 {
        color: #34495e;
        margin-top: 25px;
        font-size: 1.4em;
    }
    p {
        margin-bottom: 15px;
        text-align: justify;
    }
    """

    def __init__(self, output_dir: str = 'output'):
        logger.debug(f"Initializing EbookGenerator with output_dir='{output_dir}'")
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        logger.debug(f"Output directory created/verified: {self.output_dir}")

    def create_epub(self, chapters: list, title: str, author: str,
                    custom_css: Optional[str] = None) -> Path:
        """Create EPUB from chapters"""
        logger.debug(f"Starting EPUB creation: title='{title}', author='{author}', chapters={len(chapters)}")

        logger.debug("Initializing EPUB book object")
        book = epub.EpubBook()
        book.set_identifier(f'web_to_ebook_{title}')
        book.set_title(title)
        book.set_language('en')
        book.add_author(author)
        logger.debug("Book metadata set")

        # Add CSS
        logger.debug("Adding CSS stylesheet")
        css_content = custom_css or self.CUSTOM_CSS
        style = epub.EpubItem()
        style.file_name = 'style/custom.css'
        style.media_type = 'text/css'
        style.content = css_content
        book.add_item(style)
        logger.debug(f"CSS added: {len(css_content)} characters")

        # Add chapters
        logger.debug(f"Adding {len(chapters)} chapters to EPUB")
        epub_chapters = []
        for i, chapter in enumerate(chapters):
            logger.debug(f"Processing chapter {i+1}/{len(chapters)}: '{chapter.get('title', 'Untitled')}'")
            c = epub.EpubHtml()
            c.file_name = f'chap_{i:02d}.xhtml'
            c.title = chapter.get('title', f'Chapter {i+1}')
            logger.debug(f"Chapter {i+1}: file_name='{c.file_name}', title='{c.title}', content_length={len(chapter['content'])}")
            c.content = f"""
            <html>
            <head>
                <link rel="stylesheet" type="text/css" href="../style/custom.css"/>
            </head>
            <body>
                <h1>{c.title}</h1>
                <p>{chapter['content']}</p>
            </body>
            </html>
            """
            book.add_item(c)
            epub_chapters.append(c)
            logger.debug(f"Chapter {i+1} added to book")

        # Set table of contents and spine
        logger.debug("Setting table of contents and spine")
        book.toc = epub_chapters
        book.spine = ['nav'] + epub_chapters
        book.add_item(epub.EpubNcx())
        book.add_item(epub.EpubNav())
        logger.debug("TOC and navigation added")

        # Write to file
        output_path = self.output_dir / f'{title}.epub'
        logger.debug(f"Writing EPUB to: {output_path}")
        epub.write_epub(output_path, book, {})
        logger.debug(f"EPUB file written successfully: {output_path}")

        print(f"✓ Created EPUB: {output_path}")
        return output_path
