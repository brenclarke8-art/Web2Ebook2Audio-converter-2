#!/usr/bin/env python3
"""Launch Web to Ebook Converter using the app-local Python environment.

This script is compiled into app.exe by launcher.spec (PyInstaller).  It
locates the Python interpreter that was installed alongside the application
and starts gui.py without opening a console window.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


def _find_base_dir() -> Path:
    """Return the directory that contains the installed application files."""
    if getattr(sys, "frozen", False):
        # Running as a PyInstaller-compiled executable: sys.executable is the
        # .exe path, so its parent is the installation directory.
        return Path(sys.executable).parent
    return Path(__file__).parent


def _find_python(base_dir: Path) -> Path | None:
    """Locate the Python interpreter bundled with the installation.

    Prefers pythonw.exe (no console window) over python.exe.
    """
    candidates = [
        base_dir / ".venv" / "Scripts" / "pythonw.exe",
        base_dir / ".venv" / "Scripts" / "python.exe",
        base_dir / "python" / "pythonw.exe",
        base_dir / "python" / "python.exe",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def _build_env(base_dir: Path) -> dict[str, str]:
    """Build the process environment, prepending the bundled espeak-ng path."""
    env = os.environ.copy()
    espeak_root = base_dir / "espeak-ng"
    if espeak_root.exists():
        for root, _dirs, files in os.walk(str(espeak_root)):
            if "espeak-ng.exe" in files:
                env["PATH"] = root + os.pathsep + env.get("PATH", "")
                break
    return env


def main() -> None:
    base_dir = _find_base_dir()
    python_exe = _find_python(base_dir)
    gui_script = base_dir / "gui.py"

    if python_exe is None or not gui_script.exists():
        try:
            import tkinter.messagebox as mb

            parts: list[str] = []
            if python_exe is None:
                parts.append("Python environment not found.")
            if not gui_script.exists():
                parts.append("Application script (gui.py) not found.")
            parts.append(f"\nExpected installation folder:\n{base_dir}")
            mb.showerror(
                "Web to Ebook Converter \u2014 Launch Error",
                "\n".join(parts),
            )
        except Exception:
            pass
        return

    try:
        kwargs: dict = {
            "env": _build_env(base_dir),
            "cwd": str(base_dir),
        }
        # On Windows hide the console window so no black terminal flashes up.
        if os.name == "nt":
            kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
        subprocess.Popen(
            [str(python_exe), str(gui_script)],
            **kwargs,
        )
    except Exception as exc:
        try:
            import tkinter.messagebox as mb

            mb.showerror(
                "Web to Ebook Converter \u2014 Launch Error",
                f"Failed to start the application:\n{exc}\n\nInstallation folder:\n{base_dir}",
            )
        except Exception:
            pass


if __name__ == "__main__":
    main()