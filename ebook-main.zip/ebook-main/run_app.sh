#!/usr/bin/env bash
# Remove pipefail so we can capture exit codes
set -eu

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

run_python() {
  local python_cmd="$1"
  echo "Starting application with $python_cmd..."
  "$python_cmd" "$SCRIPT_DIR/gui.py"
  local exitcode=$?
  if [ $exitcode -ne 0 ]; then
    echo ""
    echo "[!] Application exited with error code $exitcode"
    echo "Check the log files in the logs/ directory for details."
    echo ""
    echo "Press Enter to continue..."
    read -r
  fi
  return $exitcode
}

# Check for locally installed Python first (from bootstrap installer)
if [ -f "$SCRIPT_DIR/.venv/bin/python3" ]; then
  if run_python "$SCRIPT_DIR/.venv/bin/python3"; then
    exit 0
  fi
fi

if [ -f "$SCRIPT_DIR/python/bin/python3" ]; then
  if run_python "$SCRIPT_DIR/python/bin/python3"; then
    exit 0
  fi
fi

# Fall back to system Python
if command -v python3 >/dev/null 2>&1; then
  if run_python python3; then
    exit 0
  fi
fi

if command -v python >/dev/null 2>&1; then
  if run_python python; then
    exit 0
  fi
fi

echo "Python interpreter not found. Please run ./install_app.sh first."
echo "Press Enter to continue..."
read -r
exit 1
