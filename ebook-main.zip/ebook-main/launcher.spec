# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec for the Web to Ebook Converter desktop launcher.

Produces a small, console-free Windows executable (app.exe) that launches
gui.py through the app-local Python environment created by the bootstrap
installer.  The compiled exe is bundled inside the bootstrap installer and
deployed to the installation directory; a desktop shortcut is then created
pointing to it.
"""

a = Analysis(
    ['launcher.py'],
    pathex=[],
    binaries=[],
    datas=[],
    hiddenimports=['tkinter', 'tkinter.messagebox'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'torch',
        'transformers',
        'numpy',
        'scipy',
        'PIL',
        'matplotlib',
        'cv2',
        'tensorflow',
        'keras',
    ],
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='app',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    coerce_macros_file=None,
    entitlements_file=None,
    icon=None,
)
