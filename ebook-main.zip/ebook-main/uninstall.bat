@echo off
setlocal

set "INSTALL_DIR=%~dp0"
rem Remove trailing backslash so paths stay clean
if "%INSTALL_DIR:~-1%"=="\" set "INSTALL_DIR=%INSTALL_DIR:~0,-1%"

rem -------------------------------------------------------------------------
rem Copy uninstaller.py to %TEMP% before launching Python.
rem Running the script from outside the install directory means Python does
rem not hold locks on the install dir, so files can be deleted cleanly.
rem After Python exits this batch file attempts a final rd /s /q to remove
rem any remaining locked files (e.g., Python runtime DLLs).
rem -------------------------------------------------------------------------
copy /y "%INSTALL_DIR%\uninstaller.py" "%TEMP%\web_to_ebook_uninstaller.py" >nul 2>&1
if errorlevel 1 (
    echo [!] Failed to copy uninstaller to temporary directory.
    echo     Please run manually: python "%INSTALL_DIR%\uninstaller.py"
    pause
    exit /b 1
)

rem --- Find a Python interpreter (venv preferred, then python-runtime, then system) ---
set "PYTHON_EXE="
if exist "%INSTALL_DIR%\.venv\Scripts\python.exe" (
    set "PYTHON_EXE=%INSTALL_DIR%\.venv\Scripts\python.exe"
) else if exist "%INSTALL_DIR%\python-runtime\python.exe" (
    set "PYTHON_EXE=%INSTALL_DIR%\python-runtime\python.exe"
) else (
    where python >nul 2>&1
    if not errorlevel 1 set "PYTHON_EXE=python"
)

if not defined PYTHON_EXE (
    echo [!] No Python interpreter found.
    echo     Install Python from https://www.python.org/downloads/ and try again.
    pause
    exit /b 1
)

rem --- Run the uninstaller ---
echo Running uninstaller...
"%PYTHON_EXE%" "%TEMP%\web_to_ebook_uninstaller.py" --install-dir "%INSTALL_DIR%"

rem --- Clean up the temp copy ---
del /f /q "%TEMP%\web_to_ebook_uninstaller.py" >nul 2>&1

rem --- Final cleanup: remove any files that were locked while Python ran ---
if exist "%INSTALL_DIR%" (
    rd /s /q "%INSTALL_DIR%" >nul 2>&1
)

endlocal
